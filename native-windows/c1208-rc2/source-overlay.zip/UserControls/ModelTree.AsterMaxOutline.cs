﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UserControls
{
    public sealed class AsterMaxSectionState
    {
        public int State; // 0: mandatory missing, 1: information/incomplete, 2: validated configuration
        public string Message;
        public AsterMaxSectionState(int state, string message) { State=state; Message=message; }
    }
    public partial class ModelTree
    {
        private static void AxEnableDoubleBuffering(Control control)
        {
            if(control==null || control.IsDisposed) return;
            try
            {
                var p=typeof(Control).GetProperty("DoubleBuffered",
                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                if(p!=null) p.SetValue(control,true,null);
            }
            catch { }
        }
        private CodersLabTreeView _axOutline;
        private Timer _axOutlineTimer;
        private string _axOutlineStamp;
        private bool _axRefreshing;
        public event Action AsterMaxSolveRequested;
        public event Action AsterMaxAnalysisTypeRequested;
        public event Action<string> AsterMaxResultRequested;
        public event Action AsterMaxModelViewRequested;
        public event Action AsterMaxModelTreeChanged;
        public event Action<string> AsterMaxContactPairSelected;
        private string[] _axResultFields = new string[0];
        private string _axResultStatus = "Not solved";
        private bool _axResultsCurrent;
        private string _axSourceStamp;

        public void SetAsterMaxResultFields(string[] fields, string status, bool current)
        {
            fields = fields ?? new string[0];
            if (String.Join("|", fields) == String.Join("|", _axResultFields) && status == _axResultStatus && current == _axResultsCurrent) return;
            _axResultFields = (string[])fields.Clone(); _axResultStatus = status; _axResultsCurrent = current;
            _axOutlineStamp = null;
        }

        public void SelectAsterMaxResultField(string field)
        {
            RefreshAsterMaxOutline();
            TreeNode[] found = _axOutline.Nodes.Find("ax-result/" + field, true);
            if (found.Length == 0) throw new InvalidOperationException("Result missing from Outline: " + field);
            if (_axOutline.SelectedNode != found[0]) _axOutline.SelectedNode = found[0];
            found[0].EnsureVisible();
        }
        public Func<Dictionary<string,AsterMaxSectionState>> AsterMaxSectionStates;
        private ImageList _axSectionIcons;
        private Label _axWorkflowHint;
        private AxCommandMenu _axAnalysisMenu;
        private AxCommandMenu _axSolutionMenu;

        // Menus belong to the control, not to a single popup. Closed runs inside
        // ToolStrip's click dispatch: disposing there invalidates its remaining work.
        private sealed class AxCommandMenu : ContextMenuStrip
        {
            public AxCommandMenu(System.ComponentModel.IContainer owner) : base(owner) { }
            public void AuditMouseClick()
            {
                Rectangle bounds = Items[0].Bounds;
                int x = bounds.Left + bounds.Width / 2, y = bounds.Top + bounds.Height / 2;
                OnMouseMove(new MouseEventArgs(MouseButtons.None, 0, x, y, 0));
                OnMouseDown(new MouseEventArgs(MouseButtons.Left, 1, x, y, 0));
                OnMouseUp(new MouseEventArgs(MouseButtons.Left, 1, x, y, 0));
            }
        }

        private AxCommandMenu AxCreateCommandMenu(string caption, Action action)
        {
            if (components == null) components = new System.ComponentModel.Container();
            var menu = new AxCommandMenu(components);
            menu.Items.Add(caption, null, (s,e) => action());
            return menu;
        }

        public int AuditAsterMaxContextMenus()
        {
            Action solve = AsterMaxSolveRequested, analysis = AsterMaxAnalysisTypeRequested;
            int calls = 0, checks = 0;
            Action modal = () => {
                calls++;
                using (var dialog = new Form { Text="Context menu lifecycle regression", Width=320, Height=100 })
                using (var timer = new Timer { Interval=30 }) {
                    timer.Tick += (s,e) => { timer.Stop(); dialog.Close(); };
                    dialog.Shown += (s,e) => timer.Start();
                    dialog.ShowDialog(this);
                }
            };
            AsterMaxSolveRequested = modal;
            AsterMaxAnalysisTypeRequested = modal;
            try {
                foreach (var menu in new[] { _axAnalysisMenu, _axSolutionMenu }) {
                    for (int repeat=0; repeat<3; repeat++) {
                        int before = calls;
                        menu.Show(_axOutline, new Point(20,20));
                        Application.DoEvents();
                        menu.AuditMouseClick(); // Full ToolStrip mouse-up path, not PerformClick.
                        Application.DoEvents();
                        if (menu.IsDisposed || menu.Visible || calls != before+1)
                            throw new InvalidOperationException("Context menu click/modal/reopen regression failed.");
                        checks++;
                    }
                    int prior = calls;
                    menu.Show(_axOutline, new Point(20,20));
                    menu.Close(ToolStripDropDownCloseReason.Keyboard);
                    Application.DoEvents();
                    if (menu.IsDisposed || menu.Visible || calls != prior)
                        throw new InvalidOperationException("Context menu cancellation regression failed.");
                    checks++;
                }
            }
            finally {
                _axAnalysisMenu.Close(); _axSolutionMenu.Close();
                AsterMaxSolveRequested = solve; AsterMaxAnalysisTypeRequested = analysis;
            }
            return checks;
        }

        public void EnableAsterMaxOutline()
        {
            if (_axOutline != null) return;
            _axOutline = new CodersLabTreeView { Name = "asterMaxOutline", Dock = DockStyle.Fill,
                HideSelection = false, ShowLines = true, ShowRootLines = true,
                BackColor = Color.White, ForeColor = Color.FromArgb(34,42,53),
                Font = new Font("Segoe UI", 9), BorderStyle = BorderStyle.None };
            AxEnableDoubleBuffering(_axOutline);
            // Keep the original nodes and event routing alive; only their presentation is replaced.
            _axOutline.ImageList = ilIcons;
            tcGeometryModelResults.Visible = false;
            Controls.Add(_axOutline);
            _axOutline.BringToFront();
            _axWorkflowHint = new Label { Name="asterMaxWorkflowHint", Dock=DockStyle.Bottom, Height=88,
                Padding=new Padding(8), BackColor=Color.FromArgb(239,246,252),
                Text="? Pendiente   i Revisar   ✓ Completo\n\nSeleccione una sección para ver qué falta completar.",
                Font=new Font("Segoe UI",9), AutoEllipsis=true };
            Controls.Add(_axWorkflowHint);
            _axWorkflowHint.SendToBack();
            _axOutline.ShowNodeToolTips = true;
            _axSectionIcons = new ImageList { ImageSize=new Size(16,16), ColorDepth=ColorDepth.Depth32Bit };
            _axSectionIcons.Images.Add("pending", AxStatusIcon("?", Color.FromArgb(198,139,0)));
            _axSectionIcons.Images.Add("info", AxStatusIcon("i", Color.FromArgb(35,116,180)));
            _axSectionIcons.Images.Add("done", AxStatusIcon("", Color.FromArgb(30,145,70)));
            _axOutline.StateImageList = _axSectionIcons;
            Disposed += (s,e) => _axSectionIcons.Dispose();
            AxInitializeMechanical34();
            _axOutline.SelectionsChanged += (s,e) => AxMechanicalSelectionChanged();
            _axOutline.NodeMouseDoubleClick += (s,e) => AxEditMechanicalSelection();
            _axAnalysisMenu = AxCreateCommandMenu("Editar tipo de análisis…", () => AsterMaxAnalysisTypeRequested?.Invoke());
            _axSolutionMenu = AxCreateCommandMenu("Resolver con Code_Aster", () => AsterMaxSolveRequested?.Invoke());
            _axSolutionMenu.Items.Add("Ver información",null,(s,e)=>AsterMaxResultRequested?.Invoke("__information__"));
            _axAnalysisMenu.Items.Add("Resolver",null,(s,e)=>AsterMaxSolveRequested?.Invoke());
            _axOutline.NodeMouseClick += (s,e) => { if(e.Button==MouseButtons.Right) AxShowMechanicalMenu(e.Node,e.Location); };
            _axOutline.KeyDown += AxMechanicalKeyDown;
            _axOutlineTimer = new Timer { Interval = 700 };
            _axOutlineTimer.Tick += (s,e) => RefreshAsterMaxOutline();
            Disposed += (s,e) => { _axOutlineTimer.Stop(); _axOutlineTimer.Dispose(); };
            RefreshAsterMaxOutline();
            _axOutlineTimer.Start();
        }

        private bool SelectAsterMaxSource(TreeNode projected)
        {
            if (_axRefreshing || _axSyncingSelection || _disableMouse || projected == null) return false;
            var source = projected.Tag as TreeNode;
            if (source == null || source.TreeView == null) return false;
            var tree = source.TreeView as CodersLabTreeView;
            _axSyncingSelection=true;
            bool prior=_disableSelectionsChanged;
            try {
                _disableSelectionsChanged=true;
                if (tree == cltvGeometry) { SetGeometryTab(); GeometryMeshResultsEvent?.Invoke(ViewType.Geometry); }
                else if (tree == cltvModel) { SetModelTab(); GeometryMeshResultsEvent?.Invoke(ViewType.Model); }
                else if (tree == cltvResults) { SetResultsTab(); GeometryMeshResultsEvent?.Invoke(ViewType.Results); }
                else return false;
                tree.SelectedNodes.Clear();
                foreach(TreeNode selected in _axOutline.SelectedNodes) {
                    var native=selected.Tag as TreeNode;
                    if(native!=null && native.TreeView==tree) tree.SelectedNodes.Add(native);
                }
                if(tree.SelectedNodes.Count==0) tree.SelectedNodes.Add(source);
            }
            finally { _disableSelectionsChanged=prior; _axSyncingSelection=false; }
            cltv_SelectionsChanged(tree, EventArgs.Empty);
            return true;
        }

        private TreeNode AxCopy(TreeNode source, string caption = null)
        {
            var node = new TreeNode(caption ?? source.Text) {
                Name = AxStableSourceKey(source), Tag = source,
                ForeColor = source.Tag is CaeGlobals.NamedClass && !((CaeGlobals.NamedClass)source.Tag).Active ? Color.Gray : Color.FromArgb(34,42,53) };
            foreach (TreeNode child in source.Nodes) node.Nodes.Add(AxCopy(child));
            return node;
        }

        private static void AxStamp(TreeNode node, StringBuilder stamp)
        {
            var item=node.Tag as CaeGlobals.NamedClass;
            if(item!=null) stamp.Append(item.GetHashCode()).Append(item.Valid).Append(item.Active);
            stamp.Append(node.Name).Append(':').Append(node.Text).Append(':')
                .Append(System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(node)).Append(':')
                .Append(';');
            foreach (TreeNode child in node.Nodes) AxStamp(child, stamp);
        }

        public void RefreshAsterMaxOutline()
        {
            if (_axOutline == null || _disableMouse || !_screenUpdating || cmsTree.Visible || (_axMechanicalMenu != null && _axMechanicalMenu.Visible) || (_axMeshMenu != null && _axMeshMenu.Visible) || (_axAnalysisMenu != null && _axAnalysisMenu.Visible) || (_axSolutionMenu != null && _axSolutionMenu.Visible)) return;
            var stamp = new StringBuilder();
            foreach (TreeView tree in new TreeView[] { cltvGeometry, cltvModel, cltvResults })
                foreach (TreeNode node in tree.Nodes) AxStamp(node,stamp);
            string sourceStamp = stamp.ToString();
            bool sourceChanged = _axSourceStamp != sourceStamp; if (sourceChanged) _axSourceStamp=sourceStamp;
            stamp.Append(_axResultStatus).Append(_axResultsCurrent).Append(String.Join("|",_axResultFields));
            if (_axOutlineStamp == stamp.ToString()) return;
            _axOutlineStamp = stamp.ToString();
            var expanded = new HashSet<string>();
            AxRememberExpansion(_axOutline.Nodes, expanded);
            string selected = _axOutline.SelectedNode == null ? null : _axOutline.SelectedNode.Name;
            var selectedKeys=new List<string>();
            foreach(TreeNode node in _axOutline.SelectedNodes) selectedKeys.Add(node.Name);
            string topName = _axOutline.TopNode == null ? null : _axOutline.TopNode.Name;
            bool first = _axOutline.Nodes.Count == 0;
            _axRefreshing = true;
            _axOutline.BeginUpdate();
            try {
                _axOutline.SelectedNodes.Clear();
                _axOutline.Nodes.Clear();
                var project = new TreeNode("Proyecto") { Name = "ax-project" };
                var model = new TreeNode("Modelo") { Name = "ax-model", Tag = _model };
                project.Nodes.Add(model);
                model.Nodes.Add(AxCopy(_geomParts, "Geometría"));
                var materials = AxCopy(_materials, "Materiales");
                materials.Nodes.Add(AxCopy(_sections, "Asignación de materiales"));
                model.Nodes.Add(materials);
                var coordinates = new TreeNode("Sistemas de coordenadas") { Name = "ax-coordinates" };
                coordinates.Nodes.Add(new TreeNode("Global Cartesian (X, Y, Z)") { Name = "ax-global" });
                model.Nodes.Add(coordinates);
                var connections = new TreeNode("Conexiones") { Name = "ax-connections", Tag = _contacts };
                connections.Nodes.Add(AxCopy(_constraints));
                foreach (TreeNode node in _contacts.Nodes) connections.Nodes.Add(AxCopy(node));
                model.Nodes.Add(connections);
                var mesh = new TreeNode("Malla") { Name = "ax-mesh", Tag = _modelMesh };
                mesh.Nodes.Add(AxCopy(_meshingParameters, "Controles de malla"));
                mesh.Nodes.Add(AxCopy(_meshRefinements, "Refinamientos"));
                mesh.Nodes.Add(AxCopy(_modelParts, "Cuerpos de malla"));
                model.Nodes.Add(mesh);
                var selections = new TreeNode("Selecciones nombradas") { Name = "ax-selections" };
                selections.Nodes.Add(AxCopy(_modelNodeSets));
                selections.Nodes.Add(AxCopy(_modelElementSets));
                selections.Nodes.Add(AxCopy(_modelSurfaces));
                selections.Nodes.Add(AxCopy(_referencePoints));
                model.Nodes.Add(selections);
                var analysis = new TreeNode("Tipo de análisis") { Name = "ax-analysis", Tag = _steps };
                AxAddMechanicalAnalysisChildren(analysis);
                var solution = new TreeNode("Solución") { Name = "ax-solution" };
                solution.Nodes.Add(new TreeNode("Información de la solución") { Name="ax-solution-info", ToolTipText=_axResultStatus });
                foreach (string field in _axResultFields) solution.Nodes.Add(new TreeNode(field) {
                    Name="ax-result/"+field, StateImageKey=_axResultsCurrent?"done":"pending",
                    ForeColor=_axResultsCurrent?Color.FromArgb(34,42,53):Color.Firebrick,
                    ToolTipText=_axResultsCurrent?"Select to display this field in the graphics window.":"Results are out of date. Solve the current model again." });
                solution.Nodes.Add(AxCopy(_analyses, "Ejecuciones"));
                foreach (TreeNode node in cltvResults.Nodes) solution.Nodes.Add(AxCopy(node));
                analysis.Nodes.Add(solution);
                model.Nodes.Add(analysis);
                _axOutline.Nodes.Add(project);
                AxApplyMechanicalIcons(_axOutline.Nodes);
                if (AsterMaxSectionStates != null) AxApplySectionStates(_axOutline.Nodes, AsterMaxSectionStates());
                solution.StateImageKey=_axResultsCurrent?"done":_axResultFields.Length>0?"pending":"info";
                solution.ToolTipText=_axResultStatus;
                if (first && _axResultFields.Length>0) { analysis.Expand(); solution.Expand(); }
                AxRestoreExpansion(_axOutline.Nodes, expanded, null, first);
                foreach(string key in selectedKeys) {
                    var restored=_axOutline.Nodes.Find(key,true);
                    if(restored.Length>0) _axOutline.SelectedNodes.Add(restored[0]);
                }
                if(first) { project.Expand(); model.Expand(); }
                // Keep the imported-body branch discoverable after a previously empty project is filled.
                if (model.Nodes.Count>0 && model.Nodes[0].Nodes.Count>0 && !_axGeometryRevealed) { model.Nodes[0].ExpandAll(); _axGeometryRevealed=true; } else if(model.Nodes.Count>0 && model.Nodes[0].Nodes.Count==0) _axGeometryRevealed=false;
                if (first) analysis.Expand();
                TreeNode[] previousTop = topName == null ? new TreeNode[0] : _axOutline.Nodes.Find(topName, true);
                _axOutline.TopNode = previousTop.Length > 0 ? previousTop[0] : project;
            }
            finally
            {
                _axOutline.EndUpdate();
                _axRefreshing = false;
                _axOutline.Invalidate();
            }
            if (sourceChanged) AsterMaxModelTreeChanged?.Invoke();
            AxUpdateMechanicalDetails(_axOutline.SelectedNode);
        }

        private static void AxRememberExpansion(TreeNodeCollection nodes, HashSet<string> expanded)
        {
            foreach (TreeNode node in nodes) { if (node.IsExpanded) expanded.Add(node.Name); AxRememberExpansion(node.Nodes, expanded); }
        }

        private static Bitmap AxStatusIcon(string text, Color color)
        {
            var bitmap=new Bitmap(16,16);
            using(var g=Graphics.FromImage(bitmap)) {
                g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using(var brush=new SolidBrush(color)) g.FillEllipse(brush,1,1,14,14);
                if(text.Length==0) {
                    using(var pen=new Pen(Color.White,2)) g.DrawLines(pen,new Point[]{new Point(4,8),new Point(7,11),new Point(12,5)});
                } else using(var font=new Font("Segoe UI",9,FontStyle.Bold))
                    g.DrawString(text,font,Brushes.White,new RectangleF(0,0,16,16),new StringFormat{Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Center});
            }
            return bitmap;
        }

        private void AxApplySectionStates(TreeNodeCollection nodes, Dictionary<string,AsterMaxSectionState> states)
        {
            foreach(TreeNode node in nodes) AxApplySectionStatesSingle(node,states);
        }
        private void AxApplySectionStatesSingle(TreeNode node, Dictionary<string,AsterMaxSectionState> states)
        {
            // Process a subtree without moving its native/projection nodes.
            TreeNode source=node.Tag as TreeNode;
            string key=node.Name;
            if(source==_geomParts) key="geometry";
            else if(source==_materials) key="materials";
            else if(source==_sections) key="assignments";
            else if(source!=null && source.Name==_boundaryConditionsName) key="supports";
            else if(source!=null && source.Name==_loadsName) key="loads";
            AsterMaxSectionState state;
            if(states.TryGetValue(key,out state)) {
                node.StateImageKey=state.State==2?"done":state.State==0?"pending":"info";
                node.ToolTipText=state.Message;

            }
            foreach(TreeNode child in node.Nodes) if(!child.Name.StartsWith("ax-info-")) AxApplySectionStatesSingle(child,states);
        }
        private void AxRestoreExpansion(TreeNodeCollection nodes, HashSet<string> expanded, string selected, bool first)
        {
            foreach (TreeNode node in nodes) {
                if (expanded.Contains(node.Name)) node.Expand();
                if (node.Name == selected) _axOutline.SelectedNode = node;
                AxRestoreExpansion(node.Nodes,expanded,selected,first);
            }
        }

        private void AxApplyNativeIcons(TreeNodeCollection nodes)
        {
            foreach (TreeNode node in nodes) {
                TreeNode source = node.Tag as TreeNode;
                string key = source == null ? "" : source.StateImageKey;
                if (!ilIcons.Images.ContainsKey(key) && ilIcons.Images.ContainsKey(key + ".ico")) key += ".ico";
                if (!ilIcons.Images.ContainsKey(key)) {
                    switch (node.Name) {
                        case "ax-project": case "ax-model": case "ax-coordinates": case "ax-global": key="Geometry.ico"; break;
                        case "ax-connections": key="Contact.ico"; break;
                        case "ax-mesh": key="Mesh.ico"; break;
                        case "ax-selections": key="Node_set.ico"; break;
                        case "ax-analysis": key="Step.ico"; break;
                        case "ax-solution": key="Field_output.ico"; break;
                        default:
                            key = source != null && source.Parent == _geomParts ? "GeomPart.ico" : "BasePart.ico";
                            break;
                    }
                }
                node.ImageKey=key; node.SelectedImageKey=key;
                AxApplyNativeIcons(node.Nodes);
            }
        }
        public bool AsterMaxOutlineHasGeometry(string partName)
        {
            RefreshAsterMaxOutline();
            return _axOutline != null && _axOutline.Visible && _axOutline.Width > 100 &&
                _axOutline.Height > 100 && AxFindSource(_axOutline.Nodes, partName);
        }
        private bool AxFindSource(TreeNodeCollection nodes, string partName)
        {
            foreach (TreeNode node in nodes) {
                var source = node.Tag as TreeNode;
                if (source != null && source.TreeView == cltvGeometry && source.Name == partName) return true;
                if (AxFindSource(node.Nodes, partName)) return true;
            }
            return false;
        }
    }
}



