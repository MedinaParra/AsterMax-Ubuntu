using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CaeGlobals;
using CaeMesh;
using CaeModel;
using PrePoMax.Forms;

namespace PrePoMax {
    // Only NEW connections. Never interprets or rewrites a saved connection law.
    public static class AsterMaxAutoConnections {
        public const SearchContactPairType DefaultType = SearchContactPairType.Tie;
        public const string IdealLabel = "Idealmente unido (Bonded/Tie) — MPC";
        public const string ContactLabel = "Contacto unilateral — Hard sin fricción";
        public sealed class Plan {
            public readonly List<Tie> Ties = new List<Tie>();
            public readonly List<ContactPair> Contacts = new List<ContactPair>();
            public SurfaceInteraction Interaction;
            public int DuplicateCount;
        }
        public static void ValidateNewModel(FeModel model, SearchContactPairType type) {
            if(type!=SearchContactPairType.Tie && type!=SearchContactPairType.Contact) throw new InvalidDataException("Tipo de conexión no reconocido.");
            if(model==null || model.Mesh==null || model.Mesh.Elements.Count==0) throw new InvalidDataException("Genere una malla antes de buscar conexiones.");
            if(model.ContactPairs.Count>0 || model.Constraints.Values.Any(c=>c is Tie))
                throw new InvalidDataException("El modelo ya contiene contactos o uniones Tie, activos o inactivos. Se conservan sin cambios. La autogeneración no convierte ni sustituye conexiones guardadas; revise cada par explícitamente.");
            if(model.Properties.ModelSpace.IsTwoD() || model.Mesh.Elements.Values.Any(e=>!(e is LinearTetraElement)))
                throw new InvalidDataException("La autogeneración Code_Aster requiere sólidos 3D con TETRA4. No se crearán conexiones fuera de esta cobertura.");
            if(model.StepCollection.StepsList.Any(s=>s.Active && s.Nlgeom))
                throw new InvalidDataException("La ruta actual requiere pequeños desplazamientos (Nlgeom desactivado).");
        }
        public static void ValidateDistance(double distance) {
            if(Double.IsNaN(distance)||Double.IsInfinity(distance)||distance<=0)
                throw new InvalidDataException("La tolerancia debe ser positiva y finita, en unidades de longitud del modelo.");
        }
        private static string Key(int[] ids) { return String.Join(",",ids.OrderBy(x=>x)); }
        private static Selection Select(int[] geometryIds,Func<Selection,Selection> convert) {
            var s=new Selection(); s.SelectItem=vtkSelectItem.Surface;
            s.Add(new SelectionNodeIds(vtkSelectOperation.Add,false,geometryIds,true));
            return convert==null?s:convert(s);
        }
        private static int[] Faces(FeMesh mesh,int[] ids) {
            if(ids.Length==0 || ids.Any(id=>id<0 || FeMesh.GetItemTypePartIdsFromGeometryId(id)[1]!=(int)GeometryType.SolidSurface))
                throw new InvalidDataException("La interfaz debe contener caras sólidas válidas en ambos lados.");
            var all=new List<int>();
            foreach(int id in ids) {
                var resolved=mesh.GetIdsFromGeometryIds(new[]{id},vtkSelectItem.Surface);
                if(resolved.Length==0)throw new InvalidDataException("Una cara detectada ya no existe en la malla actual.");
                all.AddRange(resolved);
            }
            var faces=all.Distinct().OrderBy(x=>x).ToArray();
            if(faces.Length==0 || faces.Any(f=>!mesh.Elements.ContainsKey(f/10)))
                throw new InvalidDataException("No se pudieron recuperar las caras detectadas de la malla actual. No se creó ninguna conexión.");
            return faces;
        }
        public static Plan CreatePlan(FeModel model,IEnumerable<MasterSlaveItem> detected,double distance,
                                      SearchContactPairType type=DefaultType,Func<Selection,Selection> convert=null) {
            ValidateNewModel(model,type); ValidateDistance(distance);
            if(detected==null)throw new InvalidDataException("La búsqueda no devolvió una lista de interfaces.");
            var plan=new Plan(); var seen=new HashSet<string>();
            var names=new HashSet<string>(model.Constraints.Keys.Concat(model.ContactPairs.Keys));
            string interactionName="AsterMax_Auto_Hard";int suffix=1;
            while(model.SurfaceInteractions.ContainsKey(interactionName))interactionName="AsterMax_Auto_Hard_"+(suffix++);
            foreach(var item in detected) {
                if(item==null || item.Unresolved || item.MasterGeometryIds==null || item.SlaveGeometryIds==null)
                    throw new InvalidDataException("Hay una interfaz no resuelta. Revise sus dos superficies; no se creó ninguna conexión.");
                var master=item.MasterGeometryIds.OrderBy(x=>x).ToArray();var slave=item.SlaveGeometryIds.OrderBy(x=>x).ToArray();
                var masterFaces=Faces(model.Mesh,master);var slaveFaces=Faces(model.Mesh,slave);
                if(master.Intersect(slave).Any() || masterFaces.Intersect(slaveFaces).Any())throw new InvalidDataException("Una interfaz contiene las mismas caras en ambos lados.");
                var mk=Key(masterFaces);var sk=Key(slaveFaces);var key=String.CompareOrdinal(mk,sk)<0?mk+"|"+sk:sk+"|"+mk;
                if(!seen.Add(key)){plan.DuplicateCount++;continue;}
                string prefix=type==SearchContactPairType.Tie?"Auto_Bonded_":"Auto_Contact_";int n=1;while(names.Contains(prefix+n))n++;
                string name=prefix+n;names.Add(name);
                var ms=Select(master,convert);var ss=Select(slave,convert);
                if(ms==null||ss==null)throw new InvalidDataException("No se pudo preservar la selección de la interfaz.");
                if(type==SearchContactPairType.Tie) {
                    var tie=new Tie(name,distance,false,"",RegionTypeEnum.Selection,"",RegionTypeEnum.Selection,false);
                    tie.MasterCreationData=ms;tie.SlaveCreationData=ss;tie.MasterCreationIds=masterFaces;tie.SlaveCreationIds=slaveFaces;
                    plan.Ties.Add(tie);
                } else {
                    var cp=new ContactPair(name,interactionName,ContactPairMethod.SurfaceToSurface,false,false,distance,"",RegionTypeEnum.Selection,"",RegionTypeEnum.Selection);
                    cp.MasterCreationData=ms;cp.SlaveCreationData=ss;cp.MasterCreationIds=masterFaces;cp.SlaveCreationIds=slaveFaces;plan.Contacts.Add(cp);
                }
            }
            if(plan.Contacts.Count>0) {plan.Interaction=new SurfaceInteraction(interactionName);plan.Interaction.AddProperty(new SurfaceBehavior());}
            return plan;
        }
    }
}
