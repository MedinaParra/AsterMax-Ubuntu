using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CaeModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PrePoMax
{
    /// <summary>
    /// Native in-process Code_Aster input exporter for AsterMax.
    /// Model definition only: generates ASTER .mail/.comm files and an integrity manifest.
    /// It never executes a solver and never fabricates FEA results.
    /// </summary>
    public static class AsterMaxCodeAsterNativeExporter
    {
        public const string Version = "C12.08-bonded-mpc-v1";

        public static JObject Export(FeModel model, string outDir, string baseName)
        {
            if(model==null) throw new ArgumentNullException(nameof(model));
            var assignment = AsterMaxAssignmentQualityGate.Evaluate(model);
            if (assignment.Status != "READY")
                throw new InvalidOperationException("Asignación de material incompleta: " + String.Join("; ", assignment.Issues));
            if (model.Materials.Values.Any(m => !m.Active || !m.Valid))
                throw new InvalidOperationException("Material must be active and valid before export.");
            JObject contract=AsterMaxModelContractBridge.Build(model);
            return ExportContract(contract,outDir,baseName);
        }

        public static JObject ExportContract(JObject contract,string outDir,string baseName)
        {
            if(contract==null) throw new ArgumentNullException(nameof(contract));
            if((string)contract["schema"]!="astermax-model-contract/v0") throw new NotSupportedException("Unsupported AsterMax model contract schema.");
            if((string)contract["unit_system"]!="MM_N_S_MPA") throw new NotSupportedException("Code_Aster native exporter v0 requires MM_N_S_MPA.");
            if((string)contract["analysis"]?["type"]!="static_structural") throw new NotSupportedException("Code_Aster native exporter v0 supports static_structural only.");

            AsterMaxContactLaw.ValidateAll(contract["contacts"]);
            JObject mesh=(JObject)contract["mesh"];
            JArray nodes=(JArray)mesh["nodes"];
            JArray elements=(JArray)mesh["elements"];
            var supportedElementTypes=new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "HEXA8", "TETRA4", "TETRA10"
            };
            string[] actualElementTypes=elements.Cast<JObject>()
                .Select(x=>(string)x["type"])
                .Where(x=>!String.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x=>x,StringComparer.OrdinalIgnoreCase)
                .ToArray();
            if(actualElementTypes.Length==0)
                throw new InvalidOperationException("The FE mesh contains no exportable volume element types.");
            foreach(string t in actualElementTypes)
                if(!supportedElementTypes.Contains(t))
                    throw new NotSupportedException("C10.04 native exporter does not support element type: "+t);
            string elementType=actualElementTypes.Length==1?actualElementTypes[0]:"MIXED";
            // ASTERMAX_C1207_CONTACT_TOPOLOGY
            // Plan before creating output files. The source contract and FeModel
            // remain unchanged; every exported face/node/contact law is retained.
            // C1207_CONTACT_ARRAY_REQUIRED
            // Absence means no contacts. A present malformed/null token must not
            // silently erase the contact model from a requested solve.
            JToken contactToken=contract["contacts"];
            if(contactToken!=null && !(contactToken is JArray))
                throw new InvalidDataException("El campo contacts debe ser una lista de contactos. Revise el contrato del modelo antes de resolver.");
            JObject contactOrientationReport;
            JArray contacts=AsterMaxContactTopology.Normalize(
                contactToken as JArray,nodes,out contactOrientationReport);
            JArray mats=(JArray)contract["materials"];
            JArray supports=(JArray)contract["supports"];
            JArray loads=(JArray)contract["loads"];
            // ASTERMAX_C1208_BONDED_PLAN
            // Validate geometry, support consistency and independent MPC rank
            // before creating any output. The caller's model remains unchanged.
            AsterMaxBondedMpc.Plan bondedPlan=AsterMaxBondedMpc.Build(contract);
            if(mats.Count!=1 || supports.Count<1 || loads.Count<1 || loads.Count>2) throw new NotSupportedException("C10.39 requires one material, at least one support, one nodal force and optional gravity.");
            if(!String.Equals((string)((JObject)supports[0])["type"],"fixed",StringComparison.OrdinalIgnoreCase))
                throw new NotSupportedException("C10.38 requires the primary support to be a FixedBC; directional supports may follow it.");

            // C1208_FORCE_PLAN: validate current selection and semantics before any file is written.
            AsterMaxForceDistribution.Plan forcePlan=AsterMaxForceDistribution.Build(contract);
            Directory.CreateDirectory(outDir);
            if(String.IsNullOrWhiteSpace(baseName)) baseName="astermax-model";
            string mailPath=Path.Combine(outDir,baseName+".mail");
            string commPath=Path.Combine(outDir,baseName+".comm");
            string manifestPath=Path.Combine(outDir,baseName+".native-export.json");

            var mail=new List<string>{"TITRE","ASTERMAX C9.61 NATIVE - "+((string)contract["name"]??"AsterMax Model"),"FINSF","COOR_3D"};
            foreach(JObject n in nodes.Cast<JObject>().OrderBy(n=>(string)n["id"]))
                mail.Add(String.Format(CultureInfo.InvariantCulture,"{0}  {1}  {2}  {3}",(string)n["id"],F(n["x"]),F(n["y"]),F(n["z"])));
            mail.Add("FINSF");
            foreach(string currentType in actualElementTypes)
            {
                mail.Add(currentType);
                foreach(JObject element in elements.Cast<JObject>()
                    .Where(x=>String.Equals((string)x["type"],currentType,StringComparison.OrdinalIgnoreCase))
                    .OrderBy(x=>(string)x["id"]))
                {
                    JArray connectivity=(JArray)element["nodes"];
                    int expected=currentType=="HEXA8"?8:(currentType=="TETRA4"?4:10);
                    if(connectivity==null || connectivity.Count!=expected)
                        throw new InvalidOperationException(String.Format(CultureInfo.InvariantCulture,
                            "Element {0} has {1} nodes; {2} requires {3}.",
                            (string)element["id"],connectivity==null?0:connectivity.Count,currentType,expected));
                    if(connectivity.Select(x=>(string)x).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=expected)
                        throw new InvalidOperationException("Element has duplicate node references: "+(string)element["id"]);
                    mail.Add((string)element["id"]+" "+String.Join(" ",connectivity.Select(x=>(string)x)));
                }
                mail.Add("FINSF");
            }
            // Keep volume and skin element roles explicit for Code_Aster.
            mail.Add("GROUP_MA NOM = AM_VOL");
            string[] volumeIds=elements.Cast<JObject>().Select(x=>(string)x["id"]).ToArray();
            const int volumeIdsPerRecord=8;
            for(int start=0;start<volumeIds.Length;start+=volumeIdsPerRecord)
                mail.Add(String.Join(" ",volumeIds.Skip(start).Take(volumeIdsPerRecord)));
            mail.Add("FINSF");

            // Contact skins are explicit 2D mesh elements derived from the real
            // PrePoMax master/slave surfaces. Synthetic IDs are solver-only.
            foreach (JObject contact in contacts.Cast<JObject>())
            {
                foreach (string role in new [] { "master", "slave" })
                {
                    JObject surface=(JObject)contact[role];
                    JArray skin=(JArray)surface["elements"];
                    string group=(string)surface["group"];
                    if(skin==null || skin.Count==0 || String.IsNullOrWhiteSpace(group))
                        throw new InvalidOperationException("C10.36 contact surface contract is incomplete.");

                    foreach(string skinType in skin.Cast<JObject>().Select(x=>(string)x["type"])
                        .Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x,StringComparer.OrdinalIgnoreCase))
                    {
                        mail.Add(skinType);
                        foreach(JObject face in skin.Cast<JObject>()
                            .Where(x=>String.Equals((string)x["type"],skinType,StringComparison.OrdinalIgnoreCase))
                            .OrderBy(x=>(string)x["id"]))
                            mail.Add((string)face["id"]+" "+String.Join(" ",((JArray)face["nodes"]).Select(x=>(string)x)));
                        mail.Add("FINSF");
                    }

                    mail.Add("GROUP_MA NOM = "+group);
                    string[] faceIds=skin.Cast<JObject>().Select(x=>(string)x["id"]).ToArray();
                    const int faceIdsPerRecord=8;
                    for(int start=0;start<faceIds.Length;start+=faceIdsPerRecord)
                        mail.Add(String.Join(" ",faceIds.Skip(start).Take(faceIdsPerRecord)));
                    mail.Add("FINSF");
                }
            }            JObject groups=(JObject)mesh["node_groups"];
            var asterGroupNames=new Dictionary<string,string>(StringComparer.Ordinal);
            var usedAsterGroupNames=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(JProperty p in groups.Properties().OrderBy(p=>p.Name,StringComparer.Ordinal))
            {
                JArray ids=p.Value as JArray;
                if(ids==null || ids.Count==0) continue;
                string asterName=CreateAsterGroupName(p.Name,usedAsterGroupNames);
                asterGroupNames[p.Name]=asterName;
                mail.Add("GROUP_NO NOM = "+asterName);
                const int idsPerRecord=8;
                for(int start=0;start<ids.Count;start+=idsPerRecord)
                    mail.Add(String.Join(" ",ids.Skip(start).Take(idsPerRecord).Select(x=>(string)x)));
                mail.Add("FINSF");
            }
            bondedPlan.AppendNodeGroups(mail,usedAsterGroupNames);
            mail.Add("FIN");
            File.WriteAllLines(mailPath,WrapAsterMailRecords(mail),new System.Text.UTF8Encoding(false));

            JObject mat=(JObject)mats[0], sup=(JObject)supports[0];
            JObject load=loads.Cast<JObject>().FirstOrDefault(x =>
                String.Equals((string)x["type"],"nodal_force_per_node",StringComparison.OrdinalIgnoreCase) ||
                String.Equals((string)x["type"],"nodal_force_total",StringComparison.OrdinalIgnoreCase));
            JObject gravity=loads.Cast<JObject>().FirstOrDefault(x =>
                String.Equals((string)x["type"],"gravity_acceleration",StringComparison.OrdinalIgnoreCase));
            if(load==null) throw new NotSupportedException("C10.39 requires one nodal CLoad contract.");
            if(loads.Count != 1 + (gravity==null ? 0 : 1))
                throw new NotSupportedException("C10.39 encountered an unsupported additional load.");
            double gravityMagnitude=0.0, gravityDx=0.0, gravityDy=0.0, gravityDz=0.0;
            string supportGroup=(string)sup["group"];
            string loadGroup=(string)load["group"];
            string probeGroup=(string)contract["postprocess"]?["displacement_probe_group"] ?? loadGroup;
            JArray loadNodes=(JArray)groups[loadGroup];
            if(loadNodes==null || loadNodes.Count<1) throw new InvalidOperationException("Load group is empty or missing: "+loadGroup);
            string supportGroupAster=RequireMappedGroup(asterGroupNames,supportGroup,"support");
            string loadGroupAster=RequireMappedGroup(asterGroupNames,loadGroup,"load");
            string probeGroupAster=RequireMappedGroup(asterGroupNames,probeGroup,"result probe");
            double fx=forcePlan.Fx, fy=forcePlan.Fy, fz=forcePlan.Fz;
            string loadSemantics=forcePlan.Semantics;
            double fxTotal=forcePlan.FxTotal, fyTotal=forcePlan.FyTotal, fzTotal=forcePlan.FzTotal;

            string comm=String.Format(CultureInfo.InvariantCulture,@"DEBUT()

mesh = LIRE_MAILLAGE(FORMAT='ASTER', UNITE=20)
model = AFFE_MODELE(MAILLAGE=mesh, AFFE=_F(TOUT='OUI', PHENOMENE='MECANIQUE', MODELISATION='3D'))
steel = DEFI_MATERIAU(ELAS=_F(E={0}, NU={1}))
matfield = AFFE_MATERIAU(MAILLAGE=mesh, AFFE=_F(TOUT='OUI', MATER=steel))
fixed = AFFE_CHAR_MECA(MODELE=model, DDL_IMPO=_F(GROUP_NO='{2}', DX={3}, DY={4}, DZ={5}))
load = AFFE_CHAR_MECA(MODELE=model, FORCE_NODALE=_F(GROUP_NO='{6}', FX={7}, FY={8}, FZ={9}))
result = MECA_STATIQUE(MODELE=model, CHAM_MATER=matfield, EXCIT=(_F(CHARGE=fixed), _F(CHARGE=load)))
result = CALC_CHAMP(reuse=result, RESULTAT=result, CONTRAINTE=('SIGM_ELNO',), CRITERES=('SIEQ_ELNO',), FORCE=('REAC_NODA',))
probe = POST_RELEVE_T(ACTION=_F(OPERATION='EXTRACTION', INTITULE='LOAD_FACE_DISPLACEMENT', RESULTAT=result, NOM_CHAM='DEPL', GROUP_NO='{10}', NOM_CMP=('DX','DY','DZ'), TOUT_ORDRE='OUI'))
IMPR_TABLE(TABLE=probe, UNITE=80)
IMPR_RESU(FORMAT='MED', UNITE=81, RESU=_F(RESULTAT=result))
FIN()
",F(mat["young_modulus_mpa"]),F(mat["poisson"]),supportGroupAster,F(sup["dx"]),F(sup["dy"]),F(sup["dz"]),loadGroupAster,F(fx),F(fy),F(fz),probeGroupAster);
            if(contacts.Count>0)
            {
                var orientationLines=new List<string>();
                foreach(JObject contact in contacts.Cast<JObject>())
                {
                    orientationLines.Add("_F(GROUP_MA='"+(string)contact["master"]["group"]+"')");
                    orientationLines.Add("_F(GROUP_MA='"+(string)contact["slave"]["group"]+"')");
                }
                string orientation=String.Join(",\n        ",orientationLines);
                string oldModel="model = AFFE_MODELE(MAILLAGE=mesh, AFFE=_F(TOUT='OUI', PHENOMENE='MECANIQUE', MODELISATION='3D'))";
                string newModel="mesh = MODI_MAILLAGE(reuse=mesh, MAILLAGE=mesh, ORIE_PEAU_3D=(\n        "+orientation+",\n    ))\nmodel = AFFE_MODELE(MAILLAGE=mesh, AFFE=_F(GROUP_MA='AM_VOL', PHENOMENE='MECANIQUE', MODELISATION='3D'))";
                if(!comm.Contains(oldModel)) throw new InvalidOperationException("C10.36 modelisation anchor missing.");
                comm=comm.Replace(oldModel,newModel);
                comm=comm.Replace("matfield = AFFE_MATERIAU(MAILLAGE=mesh, AFFE=_F(TOUT='OUI', MATER=steel))",
                                  "matfield = AFFE_MATERIAU(MAILLAGE=mesh, AFFE=_F(GROUP_MA='AM_VOL', MATER=steel))");
                bool hasCoulomb=contacts.Cast<JObject>().Any(x =>
                    String.Equals((string)x["friction"],"COULOMB",StringComparison.OrdinalIgnoreCase));
                string frictionMode=hasCoulomb ? "COULOMB" : "SANS";
                var zoneLines=new List<string>();
                foreach(JObject contact in contacts.Cast<JObject>())
                {
                    JObject master=(JObject)contact["master"];
                    JObject slave=(JObject)contact["slave"];
                    string frictionClause=hasCoulomb ? ", COULOMB="+F(contact["friction_coefficient"]) : "";
                    zoneLines.Add(String.Format(CultureInfo.InvariantCulture,
                        "_F(GROUP_MA_MAIT='{0}', GROUP_MA_ESCL='{1}', CONTACT_INIT='{2}'{3})",
                        (string)master["group"],(string)slave["group"],(string)contact["contact_init"],frictionClause));
                }
                string zones=String.Join(",\n        ",zoneLines);
                string linearSolve="result = MECA_STATIQUE(MODELE=model, CHAM_MATER=matfield, EXCIT=(_F(CHARGE=fixed), _F(CHARGE=load)))";
                string nonlinear=String.Format(CultureInfo.InvariantCulture,@"times = DEFI_LIST_REEL(DEBUT=0.0, INTERVALLE=_F(JUSQU_A=1.0, NOMBRE=10))
contact = DEFI_CONTACT(
    MODELE=model,
    FORMULATION='CONTINUE',
    FROTTEMENT='{1}',
    ALGO_RESO_CONT='NEWTON',
    ZONE=(
        {0},
    ),
)
result = STAT_NON_LINE(
    MODELE=model,
    CHAM_MATER=matfield,
    EXCIT=(_F(CHARGE=fixed), _F(CHARGE=load)),
    CONTACT=contact,
    COMPORTEMENT=_F(RELATION='ELAS', DEFORMATION='PETIT', TOUT='OUI'),
    INCREMENT=_F(LIST_INST=times),
    NEWTON=_F(MATRICE='TANGENTE', REAC_ITER=1),
    CONVERGENCE=_F(ITER_GLOB_MAXI=30),
)",zones,frictionMode);
                if(!comm.Contains(linearSolve)) throw new InvalidOperationException("C10.36 linear solve anchor missing from generated command file.");
                comm=comm.Replace(linearSolve,nonlinear);
            }
            if(supports.Count>1)
            {
                var ddl=new List<string>();
                for(int i=1;i<supports.Count;i++)
                {
                    JObject bc=(JObject)supports[i];
                    string group=RequireMappedGroup(asterGroupNames,(string)bc["group"],"support");
                    var terms=new List<string>();
                    if(bc["dx"]!=null && bc["dx"].Type!=JTokenType.Null) terms.Add("DX="+F(bc["dx"]));
                    if(bc["dy"]!=null && bc["dy"].Type!=JTokenType.Null) terms.Add("DY="+F(bc["dy"]));
                    if(bc["dz"]!=null && bc["dz"].Type!=JTokenType.Null) terms.Add("DZ="+F(bc["dz"]));
                    if(terms.Count==0) throw new InvalidOperationException("Directional support has no constrained translation: "+(string)bc["name"]);
                    ddl.Add("_F(GROUP_NO='"+group+"', "+String.Join(", ",terms)+")");
                }
                string stabilizer="stabilize = AFFE_CHAR_MECA(\n    MODELE=model,\n    DDL_IMPO=(\n        "+String.Join(",\n        ",ddl)+",\n    ),\n)\n\n";
                string loadAnchor="load = AFFE_CHAR_MECA(";
                if(!comm.Contains(loadAnchor)) throw new InvalidOperationException("C10.36 load anchor missing while adding directional supports.");
                comm=comm.Replace(loadAnchor,stabilizer+loadAnchor);
                comm=comm.Replace("_F(CHARGE=fixed), _F(CHARGE=load)","_F(CHARGE=fixed), _F(CHARGE=stabilize), _F(CHARGE=load)");
            }
            if(gravity!=null)
            {
                JToken densityToken=mat["density_tonne_per_mm3"];
                if(densityToken==null || densityToken.Type==JTokenType.Null)
                    throw new InvalidDataException("C10.39 gravity requires material density.");
                double rho=densityToken.Value<double>();
                if(Double.IsNaN(rho) || Double.IsInfinity(rho) || rho<=0)
                    throw new InvalidDataException("C10.39 gravity density is invalid.");

                double gx=GetDouble(gravity,"ax_mm_s2");
                double gy=GetDouble(gravity,"ay_mm_s2");
                double gz=GetDouble(gravity,"az_mm_s2");
                gravityMagnitude=Math.Sqrt(gx*gx+gy*gy+gz*gz);
                if(Double.IsNaN(gravityMagnitude) || Double.IsInfinity(gravityMagnitude) || gravityMagnitude<=0)
                    throw new InvalidDataException("C10.39 gravity acceleration is invalid.");
                gravityDx=gx/gravityMagnitude; gravityDy=gy/gravityMagnitude; gravityDz=gz/gravityMagnitude;

                string oldMaterial="steel = DEFI_MATERIAU(ELAS=_F(E="+F(mat["young_modulus_mpa"])+", NU="+F(mat["poisson"])+"))";
                string newMaterial="steel = DEFI_MATERIAU(ELAS=_F(E="+F(mat["young_modulus_mpa"])+", NU="+F(mat["poisson"])+", RHO="+F(rho)+"))";
                if(!comm.Contains(oldMaterial)) throw new InvalidOperationException("C10.39 material anchor missing for RHO.");
                comm=comm.Replace(oldMaterial,newMaterial);

                string gravityDefinition="gravity = AFFE_CHAR_MECA(\n    MODELE=model,\n    PESANTEUR=_F(GRAVITE="+F(gravityMagnitude)+", DIRECTION=("+F(gravityDx)+", "+F(gravityDy)+", "+F(gravityDz)+")),\n)\n\n";
                string loadAnchor="load = AFFE_CHAR_MECA(";
                if(!comm.Contains(loadAnchor)) throw new InvalidOperationException("C10.39 nodal load anchor missing.");
                comm=comm.Replace(loadAnchor,gravityDefinition+loadAnchor);
                comm=comm.Replace("_F(CHARGE=load)","_F(CHARGE=load), _F(CHARGE=gravity)");
            }
            // C1041_STATIC_CONTACT_FINAL_RESULT
            if(contacts.Count>0)
            {
                string allStates="IMPR_RESU(FORMAT='MED', UNITE=81, RESU=_F(RESULTAT=result))";
                if(!comm.Contains(allStates)) throw new InvalidOperationException("C10.41 final MED output anchor missing.");
                comm=comm.Replace(allStates,"IMPR_RESU(FORMAT='MED', UNITE=81, RESU=_F(RESULTAT=result, INST=1.0))");
            }
            // C1207_STATIC_CONTACT_FINAL_TABLES
            // Solve all ten increments, then publish the one final static state
            // consumed by the production MED bridge, including table probes.
            if(contacts.Count>0)
            {
                comm=comm.Replace("TOUT_ORDRE='OUI'","INST=1.0");
                if(!comm.Contains("IMPR_RESU(FORMAT='MED', UNITE=81, RESU=_F(RESULTAT=result, INST=1.0))"))
                    throw new InvalidOperationException("C12.07 expected final contact result at INST=1.0.");
            }
            comm=bondedPlan.AddToCommand(comm);
            File.WriteAllText(commPath,comm,new System.Text.UTF8Encoding(false));
            string bondedBindingsPath=Path.Combine(outDir,baseName+".bonded-mpc.json");
            bondedPlan.WriteBindings(bondedBindingsPath);

            JObject manifest=new JObject
            {
                ["exporter"]=Version,
                ["source_schema"]=(string)contract["schema"],
                ["unit_system"]=(string)contract["unit_system"],
                ["nodes"]=nodes.Count,
                ["elements"]=elements.Count,
                ["element_type"]=elementType,
                ["element_types"]=new JArray(actualElementTypes),
                ["tetrahedral_export_enabled"]=actualElementTypes.Any(x=>x=="TETRA4" || x=="TETRA10"),
                ["load_nodes"]=loadNodes.Count,
                ["contact_pair_count"]=contacts.Count,
                ["bonded_pair_count"]=bondedPlan.TieCount,
                ["bonded_mpc_report"]=bondedPlan.Report,
                ["generated_bonded_bindings"]=bondedPlan.TieCount>0?new JValue(Path.GetFileName(bondedBindingsPath)):JValue.CreateNull(),
                ["contact_orientation_report"]=contactOrientationReport,
                ["exported_result_time"]=contacts.Count>0?new JValue(1.0):JValue.CreateNull(),
                ["contact_skin_id_scheme"]="ROLE1_CONTACT2_BASE36_FACE5_BASE36",
                ["contact_skin_id_max_length"]=8,
                ["contact_solver_path"]=contacts.Count>0?"DEFI_CONTACT_CONTINUE_STAT_NON_LINE":"MECA_STATIQUE",
                ["contact_friction"]=contacts.Count==0?"SANS":
                    (contacts.Cast<JObject>().Any(x=>String.Equals((string)x["friction"],"COULOMB",StringComparison.OrdinalIgnoreCase))?"COULOMB":"SANS"),
                ["support_count"]=supports.Count,
                ["directional_support_count"]=supports.Cast<JObject>().Count(x =>
                    String.Equals((string)x["type"],"displacement",StringComparison.OrdinalIgnoreCase)),                ["contact_coulomb_coefficients"]=new JArray(contacts.Cast<JObject>()
                    .Where(x=>String.Equals((string)x["friction"],"COULOMB",StringComparison.OrdinalIgnoreCase))
                    .Select(x=>(double?)x["friction_coefficient"] ?? 0.0)),
                ["node_group_name_map"]=JObject.FromObject(asterGroupNames),
                ["group_record_encoding"]="GROUP_NO_NOM_WRAPPED_8",
                ["load_semantics"]=loadSemantics,
                ["force_distribution_report"]=forcePlan.Report,
                ["fx_per_node_n"]=fx,
                ["fy_per_node_n"]=fy,
                ["fz_per_node_n"]=fz,
                ["fx_total_n"]=fxTotal,
                ["fy_total_n"]=fyTotal,
                ["fz_total_n"]=fzTotal,
                ["expected_external_resultant_n"]=new JArray(fxTotal,fyTotal,fzTotal),
                ["external_resultant_complete"]=gravity==null,
                ["external_resultant_independent"]=true,
                ["external_resultant_note"]="Assembled from exported live CLoad; gravity contribution not integrated.",
                ["scope_binding"]=new JObject {
                    ["mode"]="model_fingerprint_mesh_scope",
                    ["verified"]=true,
                    ["mesh_scope_membership_in_fingerprint"]=true
                },
                ["material_density_tonne_per_mm3"]=mat["density_tonne_per_mm3"],
                ["gravity_enabled"]=gravity!=null,
                ["gravity_magnitude_mm_s2"]=gravityMagnitude,
                ["gravity_direction_x"]=gravityDx,
                ["gravity_direction_y"]=gravityDy,
                ["gravity_direction_z"]=gravityDz,                ["generated_mail"]=Path.GetFileName(mailPath),
                ["generated_comm"]=Path.GetFileName(commPath),
                ["solver_execution"]="NOT_RUN",
                ["fea_results_claimed"]=false,
                ["requested_postprocess"]=new JArray("DEPL","SIGM_ELNO","SIEQ_ELNO","REAC_NODA","MED")
            };
            File.WriteAllText(manifestPath,manifest.ToString(Formatting.Indented),new System.Text.UTF8Encoding(false));
            return manifest;
        }

        private static string CreateAsterGroupName(string source,HashSet<string> used)
        {
            string raw=String.IsNullOrWhiteSpace(source)?"GROUP":source.Trim().ToUpperInvariant();
            char[] chars=raw.ToCharArray();
            for(int i=0;i<chars.Length;i++)
            {
                char c=chars[i];
                bool asciiLetter=(c>='A' && c<='Z');
                bool digit=(c>='0' && c<='9');
                if(!asciiLetter && !digit && c!='_') chars[i]='_';
            }
            string stem=new string(chars).Trim('_');
            if(String.IsNullOrWhiteSpace(stem)) stem="GROUP";
            if(stem[0]>='0' && stem[0]<='9') stem="G_"+stem;
            if(stem.Length>24) stem=stem.Substring(0,24);
            string candidate=stem;
            int suffix=2;
            while(!used.Add(candidate))
            {
                string tail="_"+suffix.ToString(CultureInfo.InvariantCulture);
                int keep=Math.Max(1,24-tail.Length);
                candidate=(stem.Length>keep?stem.Substring(0,keep):stem)+tail;
                suffix++;
            }
            return candidate;
        }

        private static string RequireMappedGroup(Dictionary<string,string> map,string original,string role)
        {
            string mapped;
            if(String.IsNullOrWhiteSpace(original) || !map.TryGetValue(original,out mapped))
                throw new InvalidOperationException("The "+role+" node group is missing or empty: "+(original??"<null>"));
            return mapped;
        }
        private static double GetDouble(JObject o,string name){ JToken t=o[name]; if(t==null) return 0.0; return t.Value<double>(); }
        // U3.01.00 / Code_Aster 16.9 liritm: columns after 80 are ignored.
        // Continue only between complete tokens; never round coordinates or split IDs.
        public static List<string> WrapAsterMailRecords(IEnumerable<string> records)
        {
            var result = new List<string>();
            foreach (string record in records)
            {
                if (record == null || record.IndexOfAny(new[] { '\r', '\n', '\t' }) >= 0)
                    throw new InvalidDataException("Invalid embedded control character in Aster mesh record.");
                string remaining = record;
                while (remaining.Length > 80)
                {
                    int split = remaining.LastIndexOf(' ', 80);
                    if (split <= 0)
                        throw new InvalidDataException("Aster mesh token exceeds 80 columns; cannot wrap without changing data.");
                    result.Add(remaining.Substring(0, split).TrimEnd());
                    remaining = remaining.Substring(split + 1).TrimStart();
                }
                if (remaining.Length > 0) result.Add(remaining);
            }
            return result;
        }

        private static string F(JToken token){ return token==null?"0":F(token.Value<double>()); }
        private static string F(double v)
        {
            string text = v.ToString("R", CultureInfo.InvariantCulture);
            int exponent = text.IndexOf('E');
            // Aster's mesh lexer requires a decimal point before an exponent.
            // Keep round-trip digits/exponent intact: 1E-16 becomes 1.0E-16.
            if (exponent > 0 && text.IndexOf('.', 0, exponent) < 0)
                text = text.Insert(exponent, ".0");
            return text;
        }
    }
}












