using System;
using System.Drawing;
using System.Windows.Forms;

namespace PrePoMax
{
    public partial class FrmMain
    {
        private static readonly Color AxWindow = Color.FromArgb(244, 246, 249);
        private static readonly Color AxSurface = Color.FromArgb(255, 255, 255);
        private static readonly Color AxRibbon = Color.FromArgb(247, 248, 250);
        private static readonly Color AxBorder = Color.FromArgb(211, 216, 223);
        private static readonly Color AxText = Color.FromArgb(34, 42, 53);
        private static readonly Color AxMuted = Color.FromArgb(100, 110, 124);
        private static readonly Color AxNavy = Color.FromArgb(30, 43, 59);
        private static readonly Color AxAccent = Color.FromArgb(39, 116, 174);
        private static readonly Color AxHover = Color.FromArgb(233, 242, 249);
        private static readonly Color AxViewportFrame = Color.FromArgb(225, 229, 234);
        private bool _asterMaxUiApplied;

        private void ApplyAsterMaxNativeUi()
        {
            if (_asterMaxUiApplied || IsDisposed) return;
            _asterMaxUiApplied = true;

            SuspendLayout();
            try
            {
                Text = "AsterMax Mechanical";
                try
                {
                    string asterMaxWork = _controller != null && _controller.Settings != null
                        ? _controller.Settings.GetWorkDirectory() : null;
                    if (String.IsNullOrWhiteSpace(asterMaxWork) || !System.IO.Directory.Exists(asterMaxWork))
                        throw new InvalidOperationException("AsterMax workspace initialization failed.");
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException("AsterMax could not initialize a writable portable workspace.", ex);
                }
                BackColor = AxWindow;
                Font = new Font("Segoe UI", 9.0f, FontStyle.Regular, GraphicsUnit.Point);
                MinimumSize = new Size(1040, 680);

                menuStripMain.Visible = false;
                tsFile.Visible = false;
                tsViews.Visible = false;
                tsModel.Visible = false;
                tsDeformationFactor.Visible = false;
                tsResults.Visible = false;

                BuildAsterMaxTopChrome();
                PolishNativeWorkspace();
                // Explicit ownership and docking: the live ModelTree must occupy the left panel.
                splitContainer1.Panel1Collapsed = false;
                splitContainer1.Panel1.Padding = new Padding(0);
                if (_modelTree.Parent != splitContainer1.Panel1)
                    splitContainer1.Panel1.Controls.Add(_modelTree);
                _modelTree.Dock = DockStyle.Fill;
                _modelTree.Visible = true;
                _modelTree.AsterMaxSectionStates = BuildAsterMaxSectionStates;
                _modelTree.AsterMaxAnalysisTypeRequested += SelectAsterMaxAnalysisType;
                InitializeAsterMaxIntegratedResults();
                _modelTree.EnableAsterMaxOutline();
                StartAsterMaxC1034OutlineAudit();
                StartAsterMaxC1041ReopenAudit();
                StartAsterMaxC1035DefaultsAudit();
                _modelTree.AsterMaxGenerateMeshRequested += () => tsmiCreateMesh_Click(null, EventArgs.Empty);
                _modelTree.AsterMaxSolveRequested += RunAsterMaxNativeSolve;
                _modelTree.BringToFront();
                var outlineHeader = splitContainer1.Panel1.Controls["asterMaxOutlineHeader"];
                if (outlineHeader != null) outlineHeader.SendToBack();
                toolStripContainer1.TopToolStripPanelVisible = false;
                // WinForms docks in reverse z-order: Fill must be processed after Top/Bottom.
                toolStripContainer1.BringToFront();
                splitContainer1.Panel1.PerformLayout();
                StartAsterMaxRuntimeSmoke();
            StartAsterMaxPortableCadSmoke();
            StartAsterMaxIntegratedAudit();
            StartAsterMaxC1020WorkflowConformanceAudit();
            ThemeRecursive(this);
            AsterMaxSpanishChile.Start(this);
            }
            finally
            {
                ResumeLayout(true);
                PerformLayout();
                BeginInvoke(new Action(() =>
                {
                    if (IsDisposed || _vtk == null) return;
                    PerformLayout();
                    UpdateVtkControlSize();
                    _vtk.Enabled = true;
                    _vtk.Visible = true;
                    _vtk.RenderingOn = true;
                    _vtk.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                    _vtk.BringToFront();
                    var badge = splitContainer1.Panel2.Controls["asterMaxGraphicsBadge"];
                    if (badge != null) badge.BringToFront();
                    splitContainer1.Panel2.PerformLayout();
                    _vtk.Invalidate();
                }));
            }
        }

        private Forms.SearchContactPairType _asterMaxAutoConnectionType = AsterMaxAutoConnections.DefaultType;
        private Control AsterMaxAutoConnectionSelector()
        {
            var choice = new ComboBox { Name="asterMaxAutoConnectionType", DropDownStyle=ComboBoxStyle.DropDownList, Width=310 };
            choice.Items.Add(AsterMaxAutoConnections.IdealLabel);
            choice.Items.Add(AsterMaxAutoConnections.ContactLabel);
            choice.SelectedIndex = _asterMaxAutoConnectionType == Forms.SearchContactPairType.Tie ? 0 : 1;
            choice.SelectedIndexChanged += (sender,args) => {
                _asterMaxAutoConnectionType = choice.SelectedIndex == 0 ? Forms.SearchContactPairType.Tie : Forms.SearchContactPairType.Contact;
            };
            return choice;
        }
        private void AsterMaxAutoGenerateContacts()
        {
            try {
                if (_controller == null) return;
                AsterMaxAutoConnections.ValidateNewModel(_controller.Model, _asterMaxAutoConnectionType);
                double maxDiagonal=0;
                foreach(var entry in _controller.Model.Mesh.Parts)
                    if(entry.Value!=null && entry.Value.BoundingBox!=null)
                        maxDiagonal=Math.Max(maxDiagonal,entry.Value.BoundingBox.GetDiagonal());
                if(!(maxDiagonal>0)) throw new System.IO.InvalidDataException("No hay geometría de malla válida para buscar interfaces.");
                // Preserve the historical search suggestion; require an explicit review before using it for a new Tie.
                double distance=Math.Max(maxDiagonal*0.001,1e-9);
                using(var dialog=new Form { Text="Revisar autogeneración de conexiones", Width=610, Height=265,
                    FormBorderStyle=FormBorderStyle.FixedDialog, StartPosition=FormStartPosition.CenterParent, MinimizeBox=false, MaximizeBox=false }) {
                    string law=_asterMaxAutoConnectionType==Forms.SearchContactPairType.Tie?AsterMaxAutoConnections.IdealLabel:AsterMaxAutoConnections.ContactLabel;
                    var info=new Label { Left=15, Top=15, Width=565, Height=105, Text=law+"\r\nSólo conexiones nuevas. No se convierten contactos guardados.\r\nRevise la tolerancia de búsqueda y unión en unidades de longitud del modelo.\r\nNo aumente el valor para unir piezas que no deban estar unidas. Ajustar geometría: No." };
                    var value=new TextBox { Left=15, Top=125, Width=230, Text=distance.ToString("R",System.Globalization.CultureInfo.InvariantCulture) };
                    var ok=new Button { Left=350, Top=170, Width=105, Text="Buscar y crear", DialogResult=DialogResult.OK };
                    var cancel=new Button { Left=465, Top=170, Width=105, Text="Cancelar", DialogResult=DialogResult.Cancel };
                    dialog.Controls.AddRange(new Control[]{info,value,ok,cancel});dialog.AcceptButton=ok;dialog.CancelButton=cancel;
                    if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                    if(!Double.TryParse(value.Text,System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out distance))
                        throw new System.IO.InvalidDataException("Introduzca una tolerancia numérica válida (punto decimal).");
                }
                AsterMaxAutoConnections.ValidateDistance(distance);
                var search=new CaeMesh.ContactSearch(_controller.Model.Mesh,_controller.Model.Geometry);
                search.GroupContactPairsBy=CaeMesh.GroupContactPairsByEnum.ByParts;
                var items=search.FindContactPairs(distance,35.0,CaeMesh.ContactSearchNamespace.GeometryFilterEnum.Solid,false);
                if(items==null || items.Count==0) {tsslState.Text="No se detectaron interfaces dentro de la tolerancia revisada.";return;}
                var plan=_controller.AsterMaxAutoCreateConnections(items,distance,_asterMaxAutoConnectionType);
                tsslState.Text="Conexiones nuevas: "+plan.Ties.Count+" Bonded/Tie, "+plan.Contacts.Count+" contactos unilaterales; duplicados omitidos: "+plan.DuplicateCount+". Revise las superficies antes de calcular.";
            } catch(Exception ex) {CaeGlobals.ExceptionTools.Show(this,ex); }
        }
        private static void AsterMaxEnableChromeBuffering(Control control)
        {
            if(control==null || control.IsDisposed) return;
            try
            {
                var p=typeof(Control).GetProperty("DoubleBuffered",
                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                if(p!=null) p.SetValue(control,true,null);
            }
            catch { }
        }
        private void BuildAsterMaxTopChrome()
        {
            var titleBar = new Panel
            {
                Name = "asterMaxTitleBar",
                Dock = DockStyle.Top,
                Height = 40,
                BackColor = AxNavy,
                Padding = new Padding(14, 0, 12, 0)
            };

            var brand = new Label
            {
                Text = "ASTERMAX  MECHANICAL",
                Dock = DockStyle.Left,
                Width = 245,
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold)
            };

            var discipline = new Label
            {
                Text = "Análisis mecánico",
                Dock = DockStyle.Left,
                Width = 165,
                ForeColor = Color.FromArgb(185, 198, 211),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 9.0f)
            };

            var units = new Label
            {
                Text = "mm   |   N   |   MPa",
                Dock = DockStyle.Right,
                Width = 155,
                ForeColor = Color.FromArgb(208, 219, 230),
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI Semibold", 8.5f)
            };

            var solver = new Label
            {
                Text = "Code_Aster | real TET solve + MED verified",
                Dock = DockStyle.Right,
                Width = 150,
                ForeColor = Color.FromArgb(158, 192, 218),
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 8.5f)
            };

            titleBar.Controls.Add(discipline);
            titleBar.Controls.Add(brand);
            titleBar.Controls.Add(units);
            titleBar.Controls.Add(solver);

            var ribbon = new TabControl
            {
                Name = "asterMaxRibbon",
                Dock = DockStyle.Top,
                Height = 132,
                Font = new Font("Segoe UI Semibold", 9.0f),
                Padding = new Point(12, 5),
                Appearance = TabAppearance.Normal
            };
            AsterMaxEnableChromeBuffering(ribbon);

            ribbon.TabPages.Add(BuildRibbonPage("Inicio", new Control[] {
                CommandTile("Nuevo", "ARCHIVO", () => tsbNew.PerformClick()),
                CommandTile("Abrir", "ARCHIVO", () => tsbOpen.PerformClick()),
                CommandTile("Importar", "GEOMETRÍA", () => tsbImport.PerformClick(), true),
                CommandTile("Guardar", "ARCHIVO", () => tsbSave.PerformClick()),
                RibbonSeparator(),
                CommandTile("Deshacer", "EDICIÓN", () => tsmiUndo.PerformClick()),
                CommandTile("Rehacer", "EDICIÓN", () => tsmiRedo.PerformClick()),
                RibbonSeparator(),
                CommandTile("Ajustar", "VISTA", AsterMaxFitView),
                CommandTile("Isométrica", "VISTA", AsterMaxIsometricView)
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Geometría", new Control[] {
                CommandTile("Importar STEP", "CAD", () => tsbImport.PerformClick(), true),
                CommandTile("Analizar", "GEOMETRÍA", () => tsmiGeometryAnalyze.PerformClick()),
                RibbonSeparator(),
                CommandTile("Ajustar", "VISTA", AsterMaxFitView),
                CommandTile("Isométrica", "VISTA", AsterMaxIsometricView),
                CommandTile("Aristas", "VISUAL", () => tsbShowModelEdges.PerformClick())
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Modelo", new Control[] {
                CommandTile("Propiedades", "MODELO", () => tsmiEditModel.PerformClick()),
                CommandTile("Material", "MODELO", () => AsterMaxC1004MaterialAction(() => tsmiCreateMaterial_Click(null, EventArgs.Empty)), true),
                CommandTile("Sección", "MODELO", () => AsterMaxC1004MaterialAction(() => tsmiCreateSection_Click(null, EventArgs.Empty))),
                RibbonSeparator(),
                InfoCard("Materiales, secciones y scoping conectados al árbol real")
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Materiales", new Control[] {
                CommandTile("Biblioteca", "MATERIALES", () => AsterMaxC1004MaterialAction(() => tsmiMaterialLibrary_Click(null, EventArgs.Empty)), true),
                CommandTile("Nuevo material", "MATERIALES", () => AsterMaxC1004MaterialAction(() => tsmiCreateMaterial_Click(null, EventArgs.Empty))),
                CommandTile("Editar material", "MATERIALES", () => AsterMaxC1004MaterialAction(() => tsmiEditMaterial_Click(null, EventArgs.Empty))),
                CommandTile("Asignar seccion", "SOLID", () => AsterMaxC1004MaterialAction(() => tsmiCreateSection_Click(null, EventArgs.Empty))),
                InfoCard("Material -> seccion solida -> malla -> BC/carga -> Solve")
            }));

            // C1208_BONDED_RIBBON
            ribbon.TabPages.Add(BuildRibbonPage("Conexiones", new Control[] {
                CommandTile("Idealmente unido (Bonded/Tie)", "MPC", () => {
                    if(MessageBox.Show(this, "Crear una unión ideal Tie/MPC impone compatibilidad de desplazamientos: la interfaz no se separa ni desliza, pero las piezas pueden deformarse. No representa una rigidez finita K/StickSlope y no convierte contactos existentes. Revise superficies y tolerancia; desactive sólo el contacto sustituido tras revisar la nueva unión. ¿Elegir esta idealización?", "Bonded ideal — elección física", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)!=DialogResult.Yes) return;
                    _frmConstraint.PreselectListViewItem(3);
                    tsmiCreateConstraint_Click(null, EventArgs.Empty);
                }, true),
                CommandTile("Editar unión", "CONEXIONES", () => tsmiEditConstraint_Click(null, EventArgs.Empty)),
                AsterMaxAutoConnectionSelector(),
                CommandTile("Generar conexiones", "TIPO SELECCIONADO", AsterMaxAutoGenerateContacts),
                InfoCard(AsterMaxContactLaw.Support)
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Malla", new Control[] {
                CommandTile("Controles", "MALLA", () => tsmiCreateMeshingParameters.PerformClick()),
                CommandTile("Refinamiento", "MALLA", () => tsmiCreateMeshRefinement.PerformClick()),
                CommandTile("Generar malla", "MALLA", () => tsmiCreateMesh.PerformClick(), true),
                RibbonSeparator(),
                InfoCard("NetGen nativo • TET4 / TET10 / HEXA8")
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Entorno", new Control[] {
                CommandTile("Paso", "ANÁLISIS", () => AsterMaxC1004MaterialAction(() => tsmiCreateStep_Click(null, EventArgs.Empty)), true),
                CommandTile("Apoyo", "CONDICIÓN", () => AsterMaxC1004MaterialAction(() => tsmiCreateBC_Click(null, EventArgs.Empty))),
                CommandTile("Carga", "CONDICIÓN", () => AsterMaxC1004MaterialAction(() => tsmiCreateLoad_Click(null, EventArgs.Empty))),
                RibbonSeparator(),
                StateCard("Análisis", "Estructural estático")
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Solución", new Control[] {
                CommandTile("Instalar motor", "CODE_ASTER_SETUP", () => StartAsterMaxCodeAsterSetup(), true),
                CommandTile("Verificar", "PREFLIGHT", () => ShowAsterMaxRuntimePreflight(), true),
                CommandTile("Contrato", "SOLVER", () => ExportAsterMaxModelContract()),
                CommandTile("Deck Aster", "CODE_ASTER", () => ExportAsterMaxCodeAsterDeck()),
                CommandTile("Ejecutar", "CODE_ASTER", () => RunAsterMaxNativeSolve(), true),
                CommandTile("Cancelar", "CODE_ASTER", () => CancelAsterMaxNativeSolve()),
                RibbonSeparator(),
                StateCard("Solver", "Code_Aster nativo")
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Resultados", new Control[] {
                CommandTile("Explorador", "RESULTADOS", () => OpenAsterMaxResultsExplorer(), true),
                CommandTile("Viewport FEA", "VTK", () => OpenAsterMaxResultsViewport(), true),
                CommandTile("Contornos", "RESULTADOS", () => tsbResultsColorContours.PerformClick()),
                CommandTile("Deformada", "RESULTADOS", () => tsbResultsDeformed.PerformClick()),
                CommandTile("Original", "RESULTADOS", () => tsbResultsUndeformed.PerformClick()),
                RibbonSeparator(),
                InfoCard("MED real • campos • min/max • probe")
            }));

            ribbon.TabPages.Add(BuildRibbonPage("Vista", new Control[] {
                CommandTile("Auditoría", "REPORTE", () => OpenAsterMaxButtonAuditReport()),
                RibbonSeparator(),
                CommandTile("Ajustar", "CÁMARA", AsterMaxFitView),
                CommandTile("Frontal", "CÁMARA", AsterMaxFrontView),
                CommandTile("Superior", "CÁMARA", AsterMaxTopView),
                CommandTile("Derecha", "CÁMARA", AsterMaxRightView),
                CommandTile("Isométrica", "CÁMARA", AsterMaxIsometricView),
                RibbonSeparator(),
                CommandTile("Aristas", "VISUAL", () => tsbShowModelEdges.PerformClick())
            }));

            Controls.Add(ribbon);
            Controls.Add(titleBar);
            ribbon.BringToFront();
            titleBar.BringToFront();
        }

        private void AsterMaxC1004MaterialAction(Action action)
        {
            try
            {
                if (_controller == null || _controller.Model == null)
                {
                    MessageBox.Show(this, "Primero crea o abre un modelo.", "Materiales",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                _controller.CurrentView = ViewGeometryModelResults.Model;
                action();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Materiales", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void PolishNativeWorkspace()
        {
            splitContainer1.BackColor = AxBorder;
            splitContainer1.SplitterWidth = 1;
            splitContainer1.Panel1.BackColor = AxSurface;
            splitContainer1.Panel2.BackColor = AxWindow;

            splitContainer1.Panel1.Padding = new Padding(0, 30, 0, 0);
            var outlineHeader = new Panel
            {
                Name = "asterMaxOutlineHeader",
                Dock = DockStyle.Top,
                Height = 30,
                BackColor = Color.FromArgb(238, 241, 245),
                Padding = new Padding(10, 0, 8, 0)
            };
            var outlineText = new Label
            {
                Text = "Árbol del modelo",
                Dock = DockStyle.Left,
                Width = 100,
                ForeColor = AxText,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI Semibold", 9.0f)
            };
            var stateText = new Label
            {
                Text = "Model",
                Dock = DockStyle.Right,
                Width = 70,
                ForeColor = AxMuted,
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 8.0f)
            };
            outlineHeader.Controls.Add(stateText);
            outlineHeader.Controls.Add(outlineText);
            splitContainer1.Panel1.Controls.Add(outlineHeader);
            outlineHeader.BringToFront();

            var graphicsBadge = new Label
            {
                Name = "asterMaxGraphicsBadge",
                Text = "  Graphics  ",
                AutoSize = true,
                BackColor = Color.FromArgb(238, 241, 245),
                ForeColor = AxMuted,
                Font = new Font("Segoe UI Semibold", 8.0f),
                Padding = new Padding(3, 3, 3, 3),
                Location = new Point(8, 8)
            };
            splitContainer1.Panel2.Controls.Add(graphicsBadge);
            graphicsBadge.BringToFront();

            if (_vtk != null)
            {
                _vtk.Enabled = true;
                _vtk.Visible = true;
                _vtk.RenderingOn = true;
                _vtk.BringToFront();
                _vtk.BackColor = Color.FromArgb(250, 250, 250);
            }
        }

        private void AsterMaxPrepareCamera()
        {
            if (_vtk == null || _vtk.IsDisposed) return;
            UpdateVtkControlSize();
            _vtk.Enabled = true;
            _vtk.Visible = true;
            _vtk.RenderingOn = true;
            _vtk.BringToFront();
        }

        private void AsterMaxFitView()
        {
            AsterMaxPrepareCamera();
            if (_vtk == null || _vtk.IsDisposed) return;
            _vtk.SetZoomToFit(false);
            _vtk.Refresh();
        }

        private void AsterMaxFrontView()
        {
            AsterMaxPrepareCamera();
            if (_vtk == null || _vtk.IsDisposed) return;
            _vtk.SetFrontBackView(false, true);
            _vtk.SetZoomToFit(false);
            _vtk.Refresh();
        }

        private void AsterMaxTopView()
        {
            AsterMaxPrepareCamera();
            if (_vtk == null || _vtk.IsDisposed) return;
            _vtk.SetTopBottomView(false, true);
            _vtk.SetZoomToFit(false);
            _vtk.Refresh();
        }

        private void AsterMaxRightView()
        {
            AsterMaxPrepareCamera();
            if (_vtk == null || _vtk.IsDisposed) return;
            _vtk.SetLeftRightView(false, false);
            _vtk.SetZoomToFit(false);
            _vtk.Refresh();
        }

        private void AsterMaxIsometricView()
        {
            AsterMaxPrepareCamera();
            if (_vtk == null || _vtk.IsDisposed) return;
            _vtk.SetIsometricView(false, true);
            _vtk.SetZoomToFit(false);
            _vtk.Refresh();
        }

        private void AsterMaxCenterImportedGeometry()
        {
            if (_controller == null || _vtk == null || _vtk.IsDisposed) return;
            _vtk.RenderingOn = true;
            _controller.Redraw();
            UpdateVtkControlSize();
            _vtk.Visible = true;
            _vtk.Enabled = true;
            _vtk.BringToFront();
            _vtk.SetIsometricView(false, true);
            _vtk.SetZoomToFit(false);
            _vtk.Refresh();
        }
        private TabPage BuildRibbonPage(string name, Control[] controls)
        {
            var page = new TabPage(name)
            {
                BackColor = AxRibbon,
                Padding = new Padding(9, 8, 9, 7),
                ForeColor = AxText
            };
            AsterMaxEnableChromeBuffering(page);
            var flow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                BackColor = AxRibbon,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };
            AsterMaxEnableChromeBuffering(flow);
            flow.Controls.AddRange(controls);
            page.Controls.Add(flow);
            return page;
        }

        private Button CommandTile(string text, string group, Action action, bool primary = false)
        {
            var b = new Button
            {
                Text = group + Environment.NewLine + text,
                Width = text.Length > 13 ? 124 : 104,
                Height = 82,
                Image = CreateAsterMaxRibbonIcon(text, group, primary),
                ImageAlign = ContentAlignment.TopCenter,
                TextImageRelation = TextImageRelation.ImageAboveText,
                Margin = new Padding(3, 1, 3, 1),
                Padding = new Padding(4, 5, 4, 3),
                FlatStyle = FlatStyle.Flat,
                BackColor = primary ? Color.FromArgb(238, 246, 252) : AxSurface,
                ForeColor = AxText,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI Semibold", 8.0f)
            };
            b.FlatAppearance.BorderColor = primary ? Color.FromArgb(136, 180, 214) : AxBorder;
            b.FlatAppearance.BorderSize = 1;
            b.FlatAppearance.MouseOverBackColor = AxHover;
            b.FlatAppearance.MouseDownBackColor = Color.FromArgb(219, 235, 247);
            ConfigureAsterMaxButton(b, text, group, action);
            b.Click += (s, e) => InvokeAsterMaxCommand(text, action);
            return b;
        }

        private Image CreateAsterMaxRibbonIcon(string text, string group, bool primary)
        {
            const int s = 32;
            var bmp = new Bitmap(s, s);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                var dark = Color.FromArgb(58, 64, 72);
                var muted = Color.FromArgb(112, 121, 132);
                var amber = Color.FromArgb(242, 181, 30);
                var fill = primary ? Color.FromArgb(255, 246, 218) : Color.FromArgb(247, 248, 250);

                using (var bg = new SolidBrush(fill))
                    g.FillEllipse(bg, 1, 1, 30, 30);
                using (var ring = new Pen(primary ? amber : Color.FromArgb(205, 211, 218), 1.2f))
                    g.DrawEllipse(ring, 1.5f, 1.5f, 29, 29);

                using (var p = new Pen(dark, 1.8f))
                using (var p2 = new Pen(amber, 2.2f))
                using (var pm = new Pen(muted, 1.3f))
                {
                    p.StartCap = p.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    p2.StartCap = p2.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    pm.StartCap = pm.EndCap = System.Drawing.Drawing2D.LineCap.Round;

                    string k = ((group ?? "") + "|" + (text ?? "")).ToLowerInvariant();

                    if (k.Contains("nuevo"))
                    {
                        g.DrawRectangle(p, 9, 7, 12, 17);
                        g.DrawLine(pm, 12, 11, 18, 11);
                        g.DrawLine(p2, 22, 18, 29, 18);
                        g.DrawLine(p2, 25.5f, 14.5f, 25.5f, 21.5f);
                    }
                    else if (k.Contains("abrir"))
                    {
                        g.DrawRectangle(p, 6, 10, 20, 13);
                        g.DrawLine(p, 6, 10, 12, 10);
                        g.DrawLine(p, 9, 7, 16, 7);
                        g.DrawLine(p, 16, 7, 19, 10);
                        g.DrawLine(p2, 13, 18, 23, 18);
                        g.DrawLine(p2, 20, 15, 23, 18);
                        g.DrawLine(p2, 20, 21, 23, 18);
                    }
                    else if (k.Contains("guardar"))
                    {
                        g.DrawRectangle(p, 7, 6, 18, 20);
                        g.DrawRectangle(pm, 11, 7, 9, 6);
                        g.DrawRectangle(p, 11, 17, 10, 7);
                        g.DrawLine(p2, 13, 20, 19, 20);
                    }
                    else if (k.Contains("importar"))
                    {
                        g.DrawRectangle(p, 6, 9, 17, 15);
                        g.DrawLine(p2, 17, 5, 17, 17);
                        g.DrawLine(p2, 13, 13, 17, 17);
                        g.DrawLine(p2, 21, 13, 17, 17);
                    }
                    else if (k.Contains("deshacer") || k.Contains("rehacer"))
                    {
                        bool redo = k.Contains("rehacer");
                        var r = new RectangleF(7, 8, 18, 15);
                        g.DrawArc(p, r, redo ? 205 : -25, 245);
                        if (redo)
                        {
                            g.DrawLine(p2, 23, 8, 27, 11);
                            g.DrawLine(p2, 23, 8, 20, 12);
                        }
                        else
                        {
                            g.DrawLine(p2, 9, 8, 5, 11);
                            g.DrawLine(p2, 9, 8, 12, 12);
                        }
                    }
                    else if (k.Contains("ajustar"))
                    {
                        g.DrawRectangle(p, 9, 9, 14, 14);
                        g.DrawLine(p2, 5, 10, 10, 10); g.DrawLine(p2, 6, 8, 5, 10); g.DrawLine(p2, 6, 12, 5, 10);
                        g.DrawLine(p2, 27, 22, 22, 22); g.DrawLine(p2, 26, 20, 27, 22); g.DrawLine(p2, 26, 24, 27, 22);
                        g.DrawLine(pm, 10, 5, 10, 10); g.DrawLine(pm, 8, 6, 10, 5); g.DrawLine(pm, 12, 6, 10, 5);
                        g.DrawLine(pm, 22, 27, 22, 22); g.DrawLine(pm, 20, 26, 22, 27); g.DrawLine(pm, 24, 26, 22, 27);
                    }
                    else if (k.Contains("isométr"))
                    {
                        AsterMaxDrawCube(g, p, p2, 16, 16, 9);
                    }
                    else if (k.Contains("analizar"))
                    {
                        g.DrawEllipse(p, 7, 7, 12, 12);
                        g.DrawLine(p2, 17, 17, 25, 25);
                        g.DrawLine(pm, 10, 13, 16, 13);
                    }
                    else if (k.Contains("material"))
                    {
                        g.DrawEllipse(p, 7, 7, 18, 18);
                        g.DrawArc(p2, 10, 10, 12, 12, 35, 150);
                        g.DrawLine(pm, 11, 20, 21, 12);
                    }
                    else if (k.Contains("sección"))
                    {
                        g.DrawLine(p, 9, 7, 23, 7);
                        g.DrawLine(p, 16, 7, 16, 25);
                        g.DrawLine(p, 9, 25, 23, 25);
                        g.DrawLine(p2, 12, 11, 20, 11);
                    }
                    else if (k.Contains("refinamiento"))
                    {
                        AsterMaxDrawMeshIcon(g, p, pm, 7, 7, 18, 18);
                        g.DrawRectangle(p2, 15, 15, 9, 9);
                        g.DrawLine(p2, 19.5f, 15, 19.5f, 24);
                        g.DrawLine(p2, 15, 19.5f, 24, 19.5f);
                    }
                    else if (k.Contains("malla") || k.Contains("controles"))
                    {
                        AsterMaxDrawMeshIcon(g, p, p2, 7, 7, 18, 18);
                    }
                    else if (k.Contains("paso"))
                    {
                        g.DrawEllipse(p, 7, 7, 18, 18);
                        g.DrawLine(p, 16, 16, 16, 10);
                        g.DrawLine(p2, 16, 16, 21, 19);
                    }
                    else if (k.Contains("apoyo"))
                    {
                        g.DrawLine(p, 7, 23, 25, 23);
                        g.DrawLine(pm, 9, 26, 13, 23); g.DrawLine(pm, 15, 26, 19, 23); g.DrawLine(pm, 21, 26, 25, 23);
                        g.DrawPolygon(p, new PointF[] { new PointF(16,8), new PointF(9,22), new PointF(23,22) });
                        g.DrawLine(p2, 16, 6, 16, 12);
                    }
                    else if (k.Contains("carga"))
                    {
                        g.DrawLine(p2, 16, 5, 16, 22);
                        g.DrawLine(p2, 11, 17, 16, 22);
                        g.DrawLine(p2, 21, 17, 16, 22);
                        g.DrawLine(p, 8, 25, 24, 25);
                    }
                    else if (k.Contains("verificar"))
                    {
                        g.DrawEllipse(p, 6, 6, 20, 20);
                        g.DrawLine(p2, 10, 16, 14, 20);
                        g.DrawLine(p2, 14, 20, 23, 11);
                    }
                    else if (k.Contains("ejecutar"))
                    {
                        g.DrawEllipse(p, 6, 6, 20, 20);
                        using (var b = new SolidBrush(amber))
                            g.FillPolygon(b, new PointF[] { new PointF(14,11), new PointF(22,16), new PointF(14,21) });
                    }
                    else if (k.Contains("monitor"))
                    {
                        g.DrawRectangle(p, 6, 7, 20, 16);
                        g.DrawLine(pm, 10, 26, 22, 26);
                        g.DrawLines(p2, new PointF[] { new PointF(9,18), new PointF(13,14), new PointF(16,17), new PointF(21,11), new PointF(24,14) });
                    }
                    else if (k.Contains("análisis"))
                    {
                        g.DrawEllipse(p, 7, 7, 18, 18);
                        g.DrawLine(pm, 16, 5, 16, 9);
                        g.DrawLine(pm, 16, 23, 16, 27);
                        g.DrawLine(pm, 5, 16, 9, 16);
                        g.DrawLine(pm, 23, 16, 27, 16);
                        g.DrawEllipse(p2, 12, 12, 8, 8);
                    }
                    else if (k.Contains("contornos"))
                    {
                        g.DrawRectangle(p, 7, 7, 18, 18);
                        g.DrawArc(pm, 9, 9, 14, 14, 20, 130);
                        g.DrawArc(p2, 11, 11, 10, 10, 200, 140);
                        g.DrawArc(p, 13, 13, 6, 6, 20, 180);
                    }
                    else if (k.Contains("deformada"))
                    {
                        g.DrawLine(pm, 6, 22, 26, 22);
                        g.DrawBezier(p2, new PointF(7,20), new PointF(11,6), new PointF(21,28), new PointF(25,10));
                    }
                    else if (k.Contains("original"))
                    {
                        g.DrawRectangle(p, 8, 8, 16, 16);
                        g.DrawRectangle(p2, 11, 11, 10, 10);
                    }
                    else if (k.Contains("frontal"))
                    {
                        AsterMaxDrawViewFace(g, p, p2, "F");
                    }
                    else if (k.Contains("superior"))
                    {
                        AsterMaxDrawViewFace(g, p, p2, "T");
                    }
                    else if (k.Contains("derecha"))
                    {
                        AsterMaxDrawViewFace(g, p, p2, "R");
                    }
                    else if (k.Contains("alámbrico"))
                    {
                        AsterMaxDrawCube(g, p, pm, 16, 16, 9);
                        g.DrawLine(p2, 10, 11, 22, 21);
                    }
                    else if (k.Contains("sin aristas"))
                    {
                        using (var b = new SolidBrush(Color.FromArgb(90, amber)))
                            g.FillRectangle(b, 9, 9, 14, 14);
                        g.DrawRectangle(p, 9, 9, 14, 14);
                    }
                    else if (k.Contains("aristas"))
                    {
                        AsterMaxDrawCube(g, p, p2, 16, 16, 9);
                    }
                    else if (k.Contains("resultados") || k.Contains("abrir"))
                    {
                        g.DrawRectangle(p, 7, 7, 18, 18);
                        g.DrawLine(pm, 10, 11, 22, 11);
                        g.DrawLine(p2, 10, 16, 22, 16);
                        g.DrawLine(pm, 10, 21, 22, 21);
                    }
                    else
                    {
                        AsterMaxDrawCube(g, p, p2, 16, 16, 8);
                    }
                }
            }
            return bmp;
        }

        private void AsterMaxDrawMeshIcon(Graphics g, Pen p, Pen accent, int x, int y, int w, int h)
        {
            g.DrawRectangle(p, x, y, w, h);
            for (int i = 1; i < 3; i++)
            {
                float xx = x + w * i / 3f;
                float yy = y + h * i / 3f;
                g.DrawLine(i == 2 ? accent : p, xx, y, xx, y + h);
                g.DrawLine(i == 2 ? accent : p, x, yy, x + w, yy);
            }
        }

        private void AsterMaxDrawCube(Graphics g, Pen p, Pen accent, float cx, float cy, float r)
        {
            var top = new PointF(cx, cy - r);
            var left = new PointF(cx - r * 0.82f, cy - r * 0.45f);
            var right = new PointF(cx + r * 0.82f, cy - r * 0.45f);
            var bottom = new PointF(cx, cy);
            var leftBottom = new PointF(left.X, left.Y + r);
            var rightBottom = new PointF(right.X, right.Y + r);
            g.DrawLine(p, top, left);
            g.DrawLine(p, top, right);
            g.DrawLine(accent, left, bottom);
            g.DrawLine(p, right, bottom);
            g.DrawLine(p, left, leftBottom);
            g.DrawLine(p, right, rightBottom);
            g.DrawLine(p, bottom, new PointF(bottom.X, bottom.Y + r));
            g.DrawLine(p, leftBottom, new PointF(bottom.X, bottom.Y + r));
            g.DrawLine(accent, rightBottom, new PointF(bottom.X, bottom.Y + r));
        }

        private void AsterMaxDrawViewFace(Graphics g, Pen p, Pen accent, string label)
        {
            g.DrawRectangle(p, 8, 8, 16, 16);
            g.DrawLine(accent, 8, 8, 24, 24);
            using (var f = new Font("Segoe UI Semibold", 7.5f, FontStyle.Bold))
            using (var b = new SolidBrush(Color.FromArgb(58, 64, 72)))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                g.DrawString(label, f, b, new RectangleF(8, 8, 16, 16), sf);
        }
        private Label InfoCard(string text)
        {
            return new Label
            {
                Text = text,
                AutoSize = false,
                Width = 285,
                Height = 74,
                Margin = new Padding(3, 1, 3, 1),
                Padding = new Padding(9, 5, 9, 5),
                BackColor = AxSurface,
                ForeColor = AxMuted,
                TextAlign = ContentAlignment.MiddleLeft,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 8.5f)
            };
        }

        private Label StateCard(string caption, string value)
        {
            return new Label
            {
                Text = caption.ToUpperInvariant() + Environment.NewLine + value,
                AutoSize = false,
                Width = 190,
                Height = 74,
                Margin = new Padding(3, 1, 3, 1),
                Padding = new Padding(9, 5, 9, 5),
                BackColor = Color.FromArgb(240, 246, 250),
                ForeColor = AxText,
                TextAlign = ContentAlignment.MiddleLeft,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 8.5f)
            };
        }

        private Control RibbonSeparator()
        {
            return new Panel
            {
                Width = 1,
                Height = 54,
                BackColor = AxBorder,
                Margin = new Padding(8, 5, 8, 3)
            };
        }

        // Automation-only runtime proof. It uses the same native command-line import path as the desktop app.
        // No synthetic CAE result is created: PASS requires geometry objects produced by the real importer.
        private void StartAsterMaxRuntimeSmoke()
        {
            string reportPath = AsterMaxSmokeTrace.GetReportPath(_args);
            if (String.IsNullOrWhiteSpace(reportPath)) return;
            AsterMaxSmokeTrace.Stage(_args, "astermax_ui_applied");
            int ticks = 0;
            var smokeTimer = new System.Windows.Forms.Timer { Interval = 250 };
            smokeTimer.Tick += (sender, eventArgs) =>
            {
                ticks++;
                try
                {
                    if (_controller != null && _controller.Model != null && _controller.Model.Geometry != null)
                    {
                        var geometry = _controller.Model.Geometry;
                        int parts = geometry.Parts == null ? 0 : geometry.Parts.Count;
                        int nodes = geometry.Nodes == null ? 0 : geometry.Nodes.Count;
                        int elements = geometry.Elements == null ? 0 : geometry.Elements.Count;
                        if (parts > 0 && nodes > 0)
                        {
                            smokeTimer.Stop();
                            AuditAsterMaxButtons(reportPath);
                            string outlinePart = null;
                            foreach (var entry in geometry.Parts) { outlinePart = entry.Key; break; }
                            if (!_modelTree.AsterMaxOutlineHasGeometry(outlinePart))
                                throw new InvalidOperationException("Visible Outline does not contain the imported CAD body.");
                            var ribbon = Controls["asterMaxRibbon"];
                            if (ribbon == null || !ribbon.Visible || ribbon.Height < 70 ||
                                toolStripContainer1.Top < ribbon.Bottom)
                                throw new InvalidOperationException("Workspace overlaps the command ribbon.");
                            using (var bitmap = new Bitmap(Width, Height))
                            {
                                DrawToBitmap(bitmap, new Rectangle(0, 0, Width, Height));
                                bitmap.Save(reportPath + ".outline.png", System.Drawing.Imaging.ImageFormat.Png);
                            }
                            smokeTimer.Stop();
                            AsterMaxSmokeTrace.Stage(_args, "geometry_detected");
                            string unitSystem = _controller.Model.UnitSystem == null ? "null" : _controller.Model.UnitSystem.UnitSystemType.ToString();
                            string currentView = _controller.CurrentView.ToString();
                            string json = "{" +
                                "\"pass\":true," + "\"visible_outline_contains_cad_body\":true," +
                                "\"native_exe\":\"AsterMax Mechanical.exe\"," +
                                "\"geometry_parts\":" + parts + "," +
                                "\"geometry_nodes\":" + nodes + "," +
                                "\"geometry_elements\":" + elements + "," +
                                "\"unit_system\":\"" + unitSystem + "\"," +
                                "\"current_view\":\"" + currentView + "\"," +
                                "\"vtk_control_initialized\":" + (_vtk != null ? "true" : "false") +
                                "}";
                            System.IO.File.WriteAllText(reportPath, json);
                            System.Environment.Exit(0);
                        }
                    }
                }
                catch (Exception ex)
                {
                    smokeTimer.Stop();
                    AsterMaxSmokeTrace.Stage(_args, "smoke_exception_" + ex.GetType().Name);
                    string msg = ex.GetType().Name + ": " + ex.Message;
                    msg = msg.Replace("\\", "\\\\").Replace("\"", "\\\"");
                    System.IO.File.WriteAllText(reportPath, "{\"pass\":false,\"reason\":\"" + msg + "\"}");
                    System.Environment.Exit(2);
                }
                if (ticks >= 240)
                {
                    smokeTimer.Stop();
                    AsterMaxSmokeTrace.Stage(_args, "smoke_timer_timeout");
                    System.IO.File.WriteAllText(reportPath, "{\"pass\":false,\"reason\":\"timeout_waiting_for_imported_geometry\"}");
                    System.Environment.Exit(3);
                }
            };
            AsterMaxSmokeTrace.Stage(_args, "smoke_timer_started");
            smokeTimer.Start();
        }
        private void StartAsterMaxPortableCadSmoke()
        {
            string reportPath = AsterMaxPortableCadSmokeTrace.GetReportPath(_args);
            if (String.IsNullOrWhiteSpace(reportPath)) return;

            AsterMaxPortableCadSmokeTrace.Stage(_args, "smoke_started");
            int ticks = 0;
            System.Threading.Tasks.Task<bool> meshTask = null;
            var smokeTimer = new System.Windows.Forms.Timer { Interval = 250 };
            smokeTimer.Tick += (sender, eventArgs) =>
            {
                ticks++;
                try
                {
                    if (_controller != null && _controller.Model != null && _controller.Model.Geometry != null)
                    {
                        var geometry = _controller.Model.Geometry;
                        int geometryParts = geometry.Parts == null ? 0 : geometry.Parts.Count;
                        int geometryNodes = geometry.Nodes == null ? 0 : geometry.Nodes.Count;
                        int geometryElements = geometry.Elements == null ? 0 : geometry.Elements.Count;
                        if (geometryParts > 0 && geometryNodes > 0)
                        {
                            if (meshTask == null)
                            {
                                string partName = null;
                                foreach (var entry in geometry.Parts) { partName = entry.Key; break; }
                                if (String.IsNullOrWhiteSpace(partName))
                                    throw new InvalidOperationException("Imported geometry has no meshable part name.");
                                AsterMaxPortableCadSmokeTrace.Stage(_args, "real_geometry_detected");
                                AsterMaxPortableCadSmokeTrace.Stage(_args, "netgen_volume_mesh_started");
                                meshTask = System.Threading.Tasks.Task.Run(() => _controller.CreateMesh(partName));
                                return;
                            }

                            if (!meshTask.IsCompleted) return;
                            if (!meshTask.GetAwaiter().GetResult())
                                throw new InvalidOperationException("NetGen volume mesh command returned false.");
                            if (_controller.Model.Mesh == null || _controller.Model.Mesh.Nodes == null ||
                                _controller.Model.Mesh.Elements == null || _controller.Model.Mesh.Nodes.Count < 1 ||
                                _controller.Model.Mesh.Elements.Count < 1)
                                throw new InvalidOperationException("NetGen returned no real volume mesh.");

                            string meshProofPath = reportPath + ".mesh.json";
                            string meshProof = "{" +
                                "\"pass\":true," + "\"visible_outline_contains_cad_body\":true," +
                                "\"mesh_nodes\":" + _controller.Model.Mesh.Nodes.Count + "," +
                                "\"mesh_elements\":" + _controller.Model.Mesh.Elements.Count + "," +
                                "\"source\":\"real_native_generate_mesh\"," +
                                "\"fallback_allowed\":true," +
                                "\"fea_values_invented\":false" +
                                "}";
                            System.IO.File.WriteAllText(meshProofPath, meshProof, new System.Text.UTF8Encoding(false));

                            smokeTimer.Stop();
                            AuditAsterMaxButtons(reportPath);
                            string outlinePart = null;
                            foreach (var entry in geometry.Parts) { outlinePart = entry.Key; break; }
                            if (!_modelTree.AsterMaxOutlineHasGeometry(outlinePart))
                                throw new InvalidOperationException("Visible Outline does not contain the imported CAD body.");
                            var ribbon = Controls["asterMaxRibbon"];
                            if (ribbon == null || !ribbon.Visible || ribbon.Height < 70 ||
                                toolStripContainer1.Top < ribbon.Bottom)
                                throw new InvalidOperationException("Workspace overlaps the command ribbon.");
                            using (var bitmap = new Bitmap(Width, Height))
                            {
                                DrawToBitmap(bitmap, new Rectangle(0, 0, Width, Height));
                                bitmap.Save(reportPath + ".outline.png", System.Drawing.Imaging.ImageFormat.Png);
                            }
                            smokeTimer.Stop();
                            AsterMaxPortableCadSmokeTrace.Stage(_args, "netgen_volume_mesh_completed");
                            string unitSystem = _controller.Model.UnitSystem == null
                                ? "null" : _controller.Model.UnitSystem.UnitSystemType.ToString();
                            string json = "{" +
                                "\"pass\":true," + "\"visible_outline_contains_cad_body\":true," +
                                "\"native_exe\":\"AsterMax Mechanical.exe\"," +
                                "\"cad_importer\":\"NetGen/NetGenMesher.exe\"," +
                                "\"geometry_parts\":" + geometryParts + "," +
                                "\"geometry_nodes\":" + geometryNodes + "," +
                                "\"geometry_elements\":" + geometryElements + "," +
                                "\"mesh_nodes\":" + _controller.Model.Mesh.Nodes.Count + "," +
                                "\"mesh_elements\":" + _controller.Model.Mesh.Elements.Count + "," +
                                "\"unit_system\":\"" + unitSystem + "\"," +
                                "\"fea_values_invented\":false" +
                                "}";
                            System.IO.File.WriteAllText(reportPath, json, new System.Text.UTF8Encoding(false));
                            System.Environment.Exit(0);
                        }
                    }
                }
                catch (Exception ex)
                {
                    smokeTimer.Stop();
                    AsterMaxPortableCadSmokeTrace.Stage(_args, "smoke_failed_" + ex.GetType().Name);
                    string reason=(ex.GetType().Name + ": " + ex.Message)
                        .Replace("\\", "\\\\").Replace("\"", "\\\"");
                    System.IO.File.WriteAllText(reportPath,
                        "{\"pass\":false,\"reason\":\"" + reason + "\",\"fea_values_invented\":false}",
                        new System.Text.UTF8Encoding(false));
                    System.Environment.Exit(2);
                }

                if (ticks >= 960)
                {
                    smokeTimer.Stop();
                    AsterMaxPortableCadSmokeTrace.Stage(_args, "smoke_timeout");
                    System.IO.File.WriteAllText(reportPath,
                        "{\"pass\":false,\"reason\":\"timeout_waiting_for_real_STEP_and_NetGen_mesh\",\"fea_values_invented\":false}",
                        new System.Text.UTF8Encoding(false));
                    System.Environment.Exit(3);
                }
            };
            smokeTimer.Start();
        }
        private void ThemeRecursive(Control root)
        {
            foreach (Control c in root.Controls)
            {
                if (c.Name != null && c.Name.StartsWith("asterMax", StringComparison.OrdinalIgnoreCase))
                {
                    ThemeRecursive(c);
                    continue;
                }

                if (c is TreeView)
                {
                    c.BackColor = AxSurface;
                    c.ForeColor = AxText;
                    c.Font = new Font("Segoe UI", 9.0f);
                }
                else if (c is PropertyGrid)
                {
                    c.BackColor = AxSurface;
                    c.ForeColor = AxText;
                    c.Font = new Font("Segoe UI", 8.5f);
                }
                else if (c is SplitContainer)
                {
                    c.BackColor = AxBorder;
                }
                else if (c is StatusStrip)
                {
                    c.BackColor = Color.FromArgb(237, 240, 244);
                    c.ForeColor = AxMuted;
                }
                else if (c is TextBox)
                {
                    c.Font = new Font("Consolas", 8.5f);
                }

                ThemeRecursive(c);
            }
        }
    }

    internal static class AsterMaxSmokeTrace
    {
        public static string GetReportPath(string[] args)
        {
            if (args == null) return null;
            foreach (string arg in args)
            {
                if (arg != null && arg.StartsWith("--ASTERMAX-SMOKE=", StringComparison.OrdinalIgnoreCase))
                    return arg.Substring("--ASTERMAX-SMOKE=".Length).Trim('"');
            }
            return null;
        }
        public static void Stage(string[] args, string stage)
        {
            try
            {
                string report = GetReportPath(args);
                if (String.IsNullOrWhiteSpace(report)) return;
                System.IO.File.AppendAllText(report + ".stages.log", DateTime.UtcNow.ToString("O") + " " + stage + Environment.NewLine);
            }
            catch { }
        }
    }
    internal static class AsterMaxPortableCadSmokeTrace
    {
        public static string GetReportPath(string[] args)
        {
            if (args == null) return null;
            foreach (string arg in args)
                if (arg != null && arg.StartsWith("--ASTERMAX-SMOKE=", StringComparison.OrdinalIgnoreCase))
                    return arg.Substring("--ASTERMAX-SMOKE=".Length).Trim('"');
            return null;
        }

        public static void Stage(string[] args, string stage)
        {
            try
            {
                string report = GetReportPath(args);
                if (String.IsNullOrWhiteSpace(report)) return;
                System.IO.File.AppendAllText(report + ".stages.log",
                    DateTime.UtcNow.ToString("O") + " " + stage + Environment.NewLine);
            }
            catch { }
        }
    }}



































