using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using CaeGlobals;
using DynamicTypeDescriptor;


namespace PrePoMax
{
    [Serializable]
    public class ViewCLoad : ViewLoad
    {
        // Variables                                                                                                                
        private CaeModel.CLoad _cLoad;


        // Properties                                                                                                               
        [CategoryAttribute("Fuerza")]
        [DisplayName("Interpretación de las componentes")]
        [DescriptionAttribute("PorNodo: cada nodo recibe F1/F2/F3. TotalUniformePorNodo: F1/F2/F3 son la resultante total, repartida entre nodos únicos. Cambiar el modo conserva los números y cambia su interpretación; revise la resultante antes de resolver. Sólo estática Code_Aster; no es presión por área.")]
        [RefreshProperties(RefreshProperties.All)]
        public CaeModel.NodalForceDistribution ForceDistribution
        {
            get { return _cLoad.ForceDistribution; }
            set
            {
                _cLoad = _cLoad.WithForceDistribution(value);
                SetBase(_cLoad, new Dictionary<RegionTypeEnum,string> {
                    { RegionTypeEnum.Selection, nameof(SelectionHidden) },
                    { RegionTypeEnum.NodeSetName, nameof(NodeSetName) },
                    { RegionTypeEnum.ReferencePointName, nameof(ReferencePointName) }
                });
            }
        }

        public override string Name { get { return _cLoad.Name; } set { _cLoad.Name = value; } }
        //       
        [CategoryAttribute("Region")]
        [OrderedDisplayName(2, 10, "Node set")]
        [DescriptionAttribute("Select the node set for the creation of the load.")]
        [Id(3, 2)]
        public string NodeSetName { get { return _cLoad.RegionName; } set { _cLoad.RegionName = value; } }
        //
        [CategoryAttribute("Region")]
        [OrderedDisplayName(3, 10, "Reference point")]
        [DescriptionAttribute("Select the reference point for the creation of the load.")]
        [Id(4, 2)]
        public string ReferencePointName { get { return _cLoad.RegionName; } set { _cLoad.RegionName = value; } }
        //
        [CategoryAttribute("Fuerza")]
        [OrderedDisplayName(0, 10, "F1 según modo")]
        [DescriptionAttribute("Componente X: por nodo o total según el modo seleccionado. El resumen previo al cálculo muestra ambas cantidades.")]
        [TypeConverter(typeof(StringForceConverter))]
        [Id(1, 3)]
        public double F1 { get { return _cLoad.F1; } set { _cLoad.F1 = value; } }
        //
        [CategoryAttribute("Fuerza")]
        [OrderedDisplayName(1, 10, "F2 según modo")]
        [DescriptionAttribute("Componente Y: por nodo o total según el modo seleccionado. El resumen previo al cálculo muestra ambas cantidades.")]
        [TypeConverter(typeof(StringForceConverter))]
        [Id(2, 3)]
        public double F2 { get { return _cLoad.F2; } set { _cLoad.F2 = value; } }
        //
        [CategoryAttribute("Fuerza")]
        [OrderedDisplayName(2, 10, "F3 según modo")]
        [DescriptionAttribute("Componente Z: por nodo o total según el modo seleccionado. El resumen previo al cálculo muestra ambas cantidades.")]
        [TypeConverter(typeof(StringForceConverter))]
        [Id(3, 3)]
        public double F3 { get { return _cLoad.F3; } set { _cLoad.F3 = value; } }
        //
        [CategoryAttribute("Magnitud según modo")]
        [OrderedDisplayName(3, 10, "Magnitud según modo")]
        [DescriptionAttribute("Magnitud de las componentes según la interpretación elegida.")]
        [TypeConverter(typeof(StringForceConverter))]
        [Id(1, 4)]        
        public double Magnitude
        {
            get { return Math.Sqrt(_cLoad.F1 * _cLoad.F1 + _cLoad.F2 * _cLoad.F2 + _cLoad.F3 * _cLoad.F3); }
            set
            {
                if (value <= 0)
                    throw new Exception("Value of the force load magnitude must be greater than 0.");
                //
                double len = Math.Sqrt(_cLoad.F1 * _cLoad.F1 + _cLoad.F2 * _cLoad.F2 + _cLoad.F3 * _cLoad.F3);
                double r;
                if (len == 0) r = 0;
                else r = value / len;
                _cLoad.F1 *= r;
                _cLoad.F2 *= r;
                _cLoad.F3 *= r;
            }
        }
        //
        [CategoryAttribute("Force phase")]
        [OrderedDisplayName(0, 10, "Phase")]
        [DescriptionAttribute("Value of the force phase.")]
        [TypeConverter(typeof(StringAngleDegConverter))]
        [Id(1, 5)]
        public double Phase { get { return _cLoad.PhaseDeg; } set { _cLoad.PhaseDeg = value; } }
        //
        public override string AmplitudeName { get { return _cLoad.AmplitudeName; } set { _cLoad.AmplitudeName = value; } }
        public override System.Drawing.Color Color { get { return _cLoad.Color; } set { _cLoad.Color = value; } }


        // Constructors                                                                                                             
        public ViewCLoad(CaeModel.CLoad cLoad)
        {
            // The order is important
            _cLoad = cLoad;
            //
            Dictionary<RegionTypeEnum, string> regionTypePropertyNamePairs = new Dictionary<RegionTypeEnum, string>();
            regionTypePropertyNamePairs.Add(RegionTypeEnum.Selection, nameof(SelectionHidden));
            regionTypePropertyNamePairs.Add(RegionTypeEnum.NodeSetName, nameof(NodeSetName));
            regionTypePropertyNamePairs.Add(RegionTypeEnum.ReferencePointName, nameof(ReferencePointName));
            SetBase(_cLoad, regionTypePropertyNamePairs);
            //
            DynamicCustomTypeDescriptor = ProviderInstaller.Install(this);
            // 2D
            DynamicCustomTypeDescriptor.GetProperty(nameof(F3)).SetIsBrowsable(!cLoad.TwoD);
            // Phase
            DynamicCustomTypeDescriptor.GetProperty(nameof(Phase)).SetIsBrowsable(_cLoad.Complex);
        }


        // Methods                                                                                                                  
        public override CaeModel.Load GetBase()
        {
            return _cLoad;
        }
        public void PopulateDropDownLists(string[] nodeSetNames, string[] referencePointNames, string[] amplitudeNames)
        {
            Dictionary<RegionTypeEnum, string[]> regionTypeListItemsPairs = new Dictionary<RegionTypeEnum, string[]>();
            regionTypeListItemsPairs.Add(RegionTypeEnum.Selection, new string[] { "Hidden" });
            regionTypeListItemsPairs.Add(RegionTypeEnum.NodeSetName, nodeSetNames);
            regionTypeListItemsPairs.Add(RegionTypeEnum.ReferencePointName, referencePointNames);
            PopulateDropDownLists(regionTypeListItemsPairs);
            //
            PopulateAmplitudeNames(amplitudeNames);
        }
        
    }

}
