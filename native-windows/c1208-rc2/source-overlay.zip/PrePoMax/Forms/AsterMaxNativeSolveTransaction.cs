﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PrePoMax
{
    internal enum AsterMaxSolveState { Idle, Preparing, ReadyToRun, Running, Postprocessing, Cancelling, Cancelled, SolutionCurrent, SolutionStale, Failed }

    internal sealed class AsterMaxNativeSolveTransaction
    {
        public const string Schema = "astermax-native-solve-transaction/v0";
        public string Workspace { get; private set; }
        public string BaseName { get; private set; }
        public string FrozenFingerprint { get; private set; }
        public AsterMaxSolveState State { get; private set; }
        public string Message { get; private set; }
        public string ExportFile { get; private set; }
        public string MessFile { get; private set; }
        public string MedFile { get; private set; }
        public string RawResultBundleFile { get; private set; }
        public string ResultBundleFile { get; private set; }
        public string ResultVtuFile { get; private set; }
        public string PostprocessorExecutable { get; private set; }
        public int? PostprocessorExitCode { get; private set; }
        public string RunnerExecutable { get; private set; }
        public int? RunnerExitCode { get; private set; }
        private readonly object _activeProcessSync=new object();
        private readonly object _stateTransitionSync=new object();
        private readonly object _stateFileSync=new object();
        private long _stateRevision;
        private Process _activeProcess;
        private volatile bool _cancelRequested;
        public bool CancelRequested { get { return _cancelRequested; } }

        private readonly object _consoleSync = new object();
        private readonly System.Collections.Generic.Queue<string> _consoleChunks = new System.Collections.Generic.Queue<string>();
        private int _consoleCharacters;
        private bool _consoleTruncated;
        internal string DrainConsole(int maximumCharacters = 8192)
        {
            lock (_consoleSync)
            {
                var text = new StringBuilder();
                if (_consoleTruncated)
                {
                    text.AppendLine("[Vista limitada: la salida completa se conserva en los archivos de log.]");
                    _consoleTruncated = false;
                }
                while (_consoleChunks.Count > 0 && text.Length < maximumCharacters)
                {
                    string chunk = _consoleChunks.Dequeue();
                    _consoleCharacters -= chunk.Length;
                    text.Append(chunk);
                }
                return text.ToString();
            }
        }
        private void QueueConsole(string text, string channel)
        {
            lock (_consoleSync)
            {
                string chunk = "[" + channel + "] " + text;
                _consoleChunks.Enqueue(chunk);
                _consoleCharacters += chunk.Length;
                while (_consoleCharacters > 131072 && _consoleChunks.Count > 0)
                {
                    _consoleCharacters -= _consoleChunks.Dequeue().Length;
                    _consoleTruncated = true;
                }
            }
        }
        private async Task CopyConsoleAsync(StreamReader reader, string path, string channel)
        {
            using (var log = new StreamWriter(path, false, new UTF8Encoding(false)))
            {
                log.AutoFlush = true;
                var buffer = new char[2048];
                int count;
                while ((count = await reader.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false)) > 0)
                {
                    string chunk = new string(buffer, 0, count).Replace("\0", "");
                    await log.WriteAsync(chunk).ConfigureAwait(false);
                    QueueConsole(chunk, channel);
                }
            }
        }

        private AsterMaxNativeSolveTransaction() { State=AsterMaxSolveState.Idle; }

        public static AsterMaxNativeSolveTransaction Prepare(CaeModel.FeModel model, string rootWorkspace, string baseName)
        {
            if(model==null) throw new ArgumentNullException("model");
            var readiness=AsterMaxPreSolveReadiness.Evaluate(model);
            if(readiness.Status!="READY")
                throw new InvalidOperationException("Solve blocked by engineering readiness gate: "+readiness.AuditSummary()+" | "+String.Join("; ",readiness.Issues));

            var fp=AsterMaxModelFingerprint.Extract(model);
            if(String.IsNullOrWhiteSpace(rootWorkspace)) throw new InvalidOperationException("A writable AsterMax workspace is required.");
            Directory.CreateDirectory(rootWorkspace);
            string safe=String.IsNullOrWhiteSpace(baseName)?"analysis":baseName;
            string txDir=Path.Combine(rootWorkspace,"Solve-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fffffff",CultureInfo.InvariantCulture)+"-"+Guid.NewGuid().ToString("N").Substring(0,8));
            Directory.CreateDirectory(txDir);

            var tx=new AsterMaxNativeSolveTransaction();
            tx.State=AsterMaxSolveState.Preparing;
            tx.Workspace=txDir;
            tx.BaseName=safe;
            tx.FrozenFingerprint=fp.Sha256;

            JObject exportManifest=AsterMaxCodeAsterNativeExporter.Export(model,txDir,safe);
            tx.ExportFile=Path.Combine(txDir,safe+".export");
            tx.MessFile=Path.Combine(txDir,safe+".mess");
            tx.MedFile=Path.Combine(txDir,safe+".rmed");
            tx.RawResultBundleFile=Path.Combine(txDir,safe+".astermax-results.raw.json");
            tx.ResultBundleFile=Path.Combine(txDir,safe+".astermax-results.json");
            tx.ResultVtuFile=Path.Combine(txDir,safe+".astermax-results.vtu");
            WriteExport(tx.ExportFile,safe);

            JObject manifest=new JObject
            {
                ["schema"]=Schema,
                ["release"]="C10.06",
                ["state"]="READY_TO_RUN",
                ["model_fingerprint_sha256"]=tx.FrozenFingerprint,
                ["unit_contract"]="mm/N/MPa",
                ["solver_backend"]="Code_Aster",
                ["solver_runtime_bundled"]=false,
                ["runner_contract"]="ASTERMAX_CODE_ASTER_RUNNER <export-file> <workspace>",
                ["mail_file"]=safe+".mail",
                ["comm_file"]=safe+".comm",
                ["export_file"]=safe+".export",
                ["expected_med_file"]=safe+".rmed",
                ["expected_results_bundle"]=safe+".astermax-results.json",
                ["expected_results_vtu"]=safe+".astermax-results.vtu",
                ["postprocessor_contract"]="ASTERMAX_PYTHON <bridge-c964-med-results.py> production + bind-c998-results-fingerprint.py",
                ["fea_values_invented"]=false,
                ["native_exporter_manifest"]=exportManifest
            };
            File.WriteAllText(Path.Combine(txDir,"ASTERMAX_SOLVE_TRANSACTION.json"),manifest.ToString(Formatting.Indented),new UTF8Encoding(false));
            tx.State=AsterMaxSolveState.ReadyToRun;
            tx.Message="Code_Aster transaction prepared and fingerprint frozen.";
            return tx;
        }

        public void RequestCancel()
        {
            Process active=null;
            lock(_stateTransitionSync)
            {
                if(_cancelRequested) return;
                _cancelRequested=true;
                if(State==AsterMaxSolveState.ReadyToRun ||
                   State==AsterMaxSolveState.Running ||
                   State==AsterMaxSolveState.Postprocessing)
                {
                    State=AsterMaxSolveState.Cancelling;
                    Message="CANCELLING: termination requested for the active native Solve.";
                    WriteFinalState();
                }
            }
            lock(_activeProcessSync) active=_activeProcess;
            if(active!=null) Task.Run(() => TryTerminateProcessTree(active));
        }

        private void ThrowIfCancellationRequested()
        {
            if(!_cancelRequested) return;
            string message;
            lock(_stateTransitionSync)
            {
                State=AsterMaxSolveState.Cancelled;
                Message="CANCELLED: native Solve was cancelled by the user.";
                WriteFinalState();
                message=Message;
            }
            throw new OperationCanceledException(message);
        }

        private void TransitionOrCancel(AsterMaxSolveState next,string message)
        {
            lock(_stateTransitionSync)
            {
                if(_cancelRequested)
                {
                    State=AsterMaxSolveState.Cancelled;
                    Message="CANCELLED: native Solve was cancelled by the user.";
                    WriteFinalState();
                    throw new OperationCanceledException(Message);
                }
                State=next;
                Message=message;
                WriteFinalState();
            }
        }

        private static void TryTerminateProcessTree(Process process)
        {
            if(process==null) return;
            try { if(process.HasExited) return; } catch { }
            try
            {
                string taskkill=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"taskkill.exe");
                if(File.Exists(taskkill))
                {
                    var psi=new ProcessStartInfo {
                        FileName=taskkill,
                        Arguments="/PID "+process.Id.ToString(CultureInfo.InvariantCulture)+" /T /F",
                        UseShellExecute=false,
                        CreateNoWindow=true
                    };
                    using(var killer=Process.Start(psi))
                    {
                        if(killer!=null) killer.WaitForExit(10000);
                    }
                }
            }
            catch { }
            try { if(!process.HasExited) process.Kill(); } catch { }
        }

        private int RunTrackedProcess(ProcessStartInfo psi,string stdoutFile,string stderrFile)
        {
            ThrowIfCancellationRequested();
            using(var process=Process.Start(psi))
            {
                if(process==null) throw new InvalidOperationException("External process could not be started.");
                lock(_activeProcessSync) _activeProcess=process;
                try
                {
                    var stdoutTask=CopyConsoleAsync(process.StandardOutput, Path.Combine(Workspace,stdoutFile), "stdout");
                    var stderrTask=CopyConsoleAsync(process.StandardError, Path.Combine(Workspace,stderrFile), "stderr");
                    // A log I/O failure must not leave the child blocked on a full pipe.
                    stdoutTask.ContinueWith(t => TryTerminateProcessTree(process), TaskContinuationOptions.OnlyOnFaulted);
                    stderrTask.ContinueWith(t => TryTerminateProcessTree(process), TaskContinuationOptions.OnlyOnFaulted);
                    if(_cancelRequested) TryTerminateProcessTree(process);
                    process.WaitForExit();
                    var drains = Task.WhenAll(stdoutTask, stderrTask);
                    if (!drains.Wait(5000))
                    {
                        // A descendant can inherit the pipes after its parent has exited.
                        // Never keep the interface locked indefinitely awaiting its EOF.
                        process.StandardOutput.Close();
                        process.StandardError.Close();
                        ThrowIfCancellationRequested();
                        throw new IOException("El proceso terminó, pero un descendiente mantiene la consola abierta. Drenado interrumpido tras 5 segundos; revise los procesos y logs antes de reintentar.");
                    }
                    drains.GetAwaiter().GetResult();
                    ThrowIfCancellationRequested();
                    return process.ExitCode;
                }
                finally
                {
                    lock(_activeProcessSync)
                    {
                        if(Object.ReferenceEquals(_activeProcess,process)) _activeProcess=null;
                    }
                }
            }
        }
        public void ExecuteConfiguredRunner(CaeModel.FeModel liveModel)
        {
            if(State!=AsterMaxSolveState.ReadyToRun) throw new InvalidOperationException("Solve transaction is not ready to run.");
            ThrowIfCancellationRequested();
            RunnerExecutable=ResolveCodeAsterRunner();
            if(String.IsNullOrWhiteSpace(RunnerExecutable) || !File.Exists(RunnerExecutable))
            {
                Fail("No se encuentra el adaptador de Code_Aster o el paquete está incompleto.\n\nExtraiga todo el ZIP de AsterMax en una carpeta nueva, incluidos AsterMaxRuntime y AsterMaxTools.\nDespués use Solución > Instalar motor si falta Code_Aster, o Solución > Verificar para seleccionar una instalación existente.");
            }

            TransitionOrCancel(AsterMaxSolveState.Running,"RUNNING: native Code_Aster runner started.");
            var psi=CreateRunnerProcess(RunnerExecutable,Quote(ExportFile)+" "+Quote(Workspace),Workspace);
            RunnerExitCode=RunTrackedProcess(psi,"CODE_ASTER_RUNNER_STDOUT.log","CODE_ASTER_RUNNER_STDERR.log");

            if(RunnerExitCode!=0)
            {
                string details=BuildRunnerFailureDiagnostic(Workspace,RunnerExitCode.Value);
                Fail("Code_Aster no pudo completar el cálculo (código del adaptador "+RunnerExitCode+")."+
                    (String.IsNullOrWhiteSpace(details)?"":"\n\n"+details));
            }
            if(!File.Exists(MessFile) || new FileInfo(MessFile).Length==0) Fail("Code_Aster .mess evidence is missing or empty.");
            if(!File.Exists(MedFile) || new FileInfo(MedFile).Length==0) Fail("Code_Aster MED result is missing or empty.");
            string mess=File.ReadAllText(MessFile);
            string codeAsterFailure=GetCodeAsterFailure(mess);
            if(!String.IsNullOrWhiteSpace(codeAsterFailure))
                Fail("Code_Aster reported a failed solve.\n\n"+codeAsterFailure);

            bool explicitNormalStop=HasCodeAsterNormalStop(mess);
            string solveEvidence=explicitNormalStop?"NORMAL_STOP_OR_EXIT0_MARKER":"RUNNER_EXIT_0_FRESH_MESS_RMED";

            ThrowIfCancellationRequested();
            RequireUnchangedModel(liveModel);
            TransitionOrCancel(AsterMaxSolveState.Postprocessing,
                "Code_Aster evidence accepted; waiting for verified MED postprocess handoff.");
        }

        public AsterMaxResultsBundle CompleteVerifiedResultsHandoff(CaeModel.FeModel liveModel)
        {
            if(State!=AsterMaxSolveState.Postprocessing)
                throw new InvalidOperationException("Solve transaction is not ready for postprocess handoff.");

            ThrowIfCancellationRequested();
            RequireUnchangedModel(liveModel);
            PostprocessorExecutable=ResolvePythonRuntime();
            JObject pythonProbe=ProbePythonRuntime(PostprocessorExecutable);
            if(PostprocessorExecutable==null || (bool)pythonProbe["ready"]==false)
                Fail("Python MED postprocess runtime is not ready. AsterMax requires a real Python runtime with numpy+h5py. "+pythonProbe.ToString(Formatting.None));

            string tools=Path.Combine(Application.StartupPath,"AsterMaxTools");
            string bridge=Path.Combine(tools,"bridge-c964-med-results.py");
            string binder=Path.Combine(tools,"bind-c998-results-fingerprint.py");
            if(!File.Exists(bridge) || !File.Exists(binder))
                Fail("AsterMax MED bridge tools are missing from the application package.");

            var bridgePsi=CreatePythonProcess(PostprocessorExecutable,
                Quote(bridge)+" "+Quote(MedFile)+" "+Quote(RawResultBundleFile)+" "+Quote(ResultVtuFile));
            bridgePsi.EnvironmentVariables["ASTERMAX_MED_BRIDGE_MODE"]="production";
            int bridgeExit=RunCaptured(bridgePsi,"ASTERMAX_MED_BRIDGE");

            if(bridgeExit!=0) Fail("MED bridge returned non-zero exit code: "+bridgeExit);
            if(!File.Exists(RawResultBundleFile) || new FileInfo(RawResultBundleFile).Length==0)
                Fail("Raw AsterMax results bundle is missing or empty.");
            if(!File.Exists(ResultVtuFile) || new FileInfo(ResultVtuFile).Length==0)
                Fail("AsterMax VTU evidence is missing or empty.");

            var bindPsi=CreatePythonProcess(PostprocessorExecutable,
                Quote(binder)+" "+Quote(RawResultBundleFile)+" "+Quote(FrozenFingerprint)+" "+Quote(ResultBundleFile));
            PostprocessorExitCode=RunCaptured(bindPsi,"ASTERMAX_RESULT_BINDER");
            if(PostprocessorExitCode!=0) Fail("Result fingerprint binder returned non-zero exit code: "+PostprocessorExitCode);
            if(!File.Exists(ResultBundleFile) || new FileInfo(ResultBundleFile).Length==0)
                Fail("Bound AsterMax results bundle is missing or empty.");

            RequireUnchangedModel(liveModel);
            var bundle=AsterMaxResultsBundle.Load(ResultBundleFile);
            bundle.RequireCurrentModel(liveModel);
            ThrowIfCancellationRequested();

            string qualifier=Path.Combine(tools,"qualify-mechanical-analysis.py");
            string qualificationFile=Path.Combine(Workspace,"mechanical-qualification.json");
            string analysisManifest=Path.Combine(Workspace,BaseName+".native-export.json");
            if(!File.Exists(qualifier))
                Fail("AsterMax Mechanical Qualification tool is missing from the application package.");
            string qualifierArgs=Quote(qualifier)+" --bundle "+Quote(ResultBundleFile)+
                                 " --out "+Quote(qualificationFile);
            if(File.Exists(analysisManifest))
                qualifierArgs+=" --analysis "+Quote(analysisManifest);
            if(File.Exists(MessFile))
                qualifierArgs+=" --mess "+Quote(MessFile);
            var qualificationPsi=CreatePythonProcess(PostprocessorExecutable,qualifierArgs);
            int qualificationExit=RunCaptured(qualificationPsi,"ASTERMAX_MECHANICAL_QUALIFICATION");
            if(qualificationExit==2)
                Fail("Mechanical Qualification blocked this result. See mechanical-qualification.json.");
            if(qualificationExit!=0)
                Fail("Mechanical Qualification failed with exit code: "+qualificationExit);
            if(!File.Exists(qualificationFile) || new FileInfo(qualificationFile).Length==0)
                Fail("Mechanical Qualification did not produce its evidence report.");
            var qualification=AsterMaxMechanicalQualification.Evaluate(bundle);
            if(qualification.Status=="BLOCKED") Fail(qualification.Describe());
            RequireUnchangedModel(liveModel);
            ThrowIfCancellationRequested();

            ThrowIfCancellationRequested();
            TransitionOrCancel(AsterMaxSolveState.SolutionCurrent,
                "SOLUTION_CURRENT: solver, MED bridge, fingerprint binding and VTK-ready result bundle all verified.");
            return bundle;
        }

        private static ProcessStartInfo CreateRunnerProcess(string runner,string arguments,string workingDirectory)
        {
            if(String.IsNullOrWhiteSpace(runner)) throw new ArgumentNullException("runner");
            string ext=Path.GetExtension(runner).ToLowerInvariant();
            ProcessStartInfo psi=new ProcessStartInfo();
            if(ext==".cmd" || ext==".bat")
            {
                psi.FileName=Environment.GetEnvironmentVariable("COMSPEC") ?? "cmd.exe";
                psi.Arguments="/d /s /c \"call "+Quote(runner)+" "+arguments+"\"";
            }
            else if(ext==".ps1")
            {
                string host=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),
                                         "WindowsPowerShell","v1.0","powershell.exe");
                psi.FileName=File.Exists(host)?host:"powershell.exe";
                psi.Arguments="-NoLogo -NoProfile -ExecutionPolicy Bypass -File "+Quote(runner)+" "+arguments;
            }
            else
            {
                psi.FileName=runner;
                psi.Arguments=arguments;
            }
            psi.WorkingDirectory=String.IsNullOrWhiteSpace(workingDirectory)?Application.StartupPath:workingDirectory;
            psi.UseShellExecute=false;
            psi.CreateNoWindow=true;
            psi.RedirectStandardOutput=true;
            psi.RedirectStandardError=true;
            // The packaged adapter declares UTF-8 on its own process streams.
            // Leave third-party configured adapters at their existing encoding.
            string runnerName=Path.GetFileNameWithoutExtension(runner);
            if(String.Equals(runnerName,"astermax-codeaster-runner",StringComparison.OrdinalIgnoreCase))
            {
                psi.StandardOutputEncoding=new UTF8Encoding(false);
                psi.StandardErrorEncoding=new UTF8Encoding(false);
            }
            return psi;
        }

        private static JObject ProbePythonRuntime(string python)
        {
            JObject p=new JObject
            {
                ["schema"]="astermax-python-med-probe/v1",
                ["ready"]=false,
                ["python"]=python,
                ["exit_code"]=JValue.CreateNull(),
                ["stdout"]="",
                ["stderr"]="",
                ["required_modules"]=new JArray("numpy","h5py")
            };
            if(String.IsNullOrWhiteSpace(python) || !File.Exists(python)) return p;
            try
            {
                string code="import sys,numpy,h5py; print('ASTERMAX_PYTHON_MED_OK|'+sys.version.split()[0]+'|numpy='+numpy.__version__+'|h5py='+h5py.__version__)";
                ProcessStartInfo psi=new ProcessStartInfo
                {
                    FileName=python,
                    Arguments="-c "+Quote(code),
                    WorkingDirectory=Application.StartupPath,
                    UseShellExecute=false,
                    CreateNoWindow=true,
                    RedirectStandardOutput=true,
                    RedirectStandardError=true
                };
                using(Process process=Process.Start(psi))
                {
                    var stdoutTask=process.StandardOutput.ReadToEndAsync();
                    var stderrTask=process.StandardError.ReadToEndAsync();
                    if(!process.WaitForExit(120000))
                    {
                        try { process.Kill(); } catch { }
                        p["stderr"]="Python capability probe timed out after 15 seconds.";
                        return p;
                    }
                    string stdout=stdoutTask.GetAwaiter().GetResult();
                    string stderr=stderrTask.GetAwaiter().GetResult();
                    p["exit_code"]=process.ExitCode;
                    p["stdout"]=stdoutTask.Result.Replace("\0", "").Trim();
                    p["stderr"]=stderrTask.Result.Replace("\0", "").Trim();
                    p["ready"]=process.ExitCode==0 &&
                               stdout!=null &&
                               stdout.IndexOf("ASTERMAX_PYTHON_MED_OK|",StringComparison.Ordinal)>=0;
                }
            }
            catch(Exception ex)
            {
                p["stderr"]=ex.GetType().Name+": "+ex.Message;
            }
            return p;
        }
        private static JObject ProbeCodeAsterRunner(string runner)
        {
            JObject p=new JObject
            {
                ["schema"]="astermax-codeaster-runner-probe/v1",
                ["ready"]=false,
                ["runner"]=runner,
                ["exit_code"]=JValue.CreateNull(),
                ["stdout"]="",
                ["stderr"]=""
            };
            if(String.IsNullOrWhiteSpace(runner) || !File.Exists(runner)) return p;
            try
            {
                using(Process process=Process.Start(CreateRunnerProcess(runner,"probe",Application.StartupPath)))
                {
                    var stdoutTask=process.StandardOutput.ReadToEndAsync();
                    var stderrTask=process.StandardError.ReadToEndAsync();
                    if(!process.WaitForExit(120000))
                    {
                        try { process.Kill(); } catch { }
                        p["stderr"]="Native Windows Code_Aster probe timed out after 120 seconds.";
                        return p;
                    }
                    string stdout=stdoutTask.GetAwaiter().GetResult();
                    string stderr=stderrTask.GetAwaiter().GetResult();
                    p["exit_code"]=process.ExitCode;
                    p["stdout"]=stdoutTask.Result.Replace("\0", "").Trim();
                    p["stderr"]=stderrTask.Result.Replace("\0", "").Trim();
                    p["ready"]=process.ExitCode==0;
                }
            }
            catch(Exception ex)
            {
                p["stderr"]=ex.GetType().Name+": "+ex.Message;
            }
            return p;
        }
        private static string ResolvePythonRuntime()
        {
            string packaged=Path.Combine(Application.StartupPath,"AsterMaxRuntime","Python","python.exe");
            if(File.Exists(packaged)) return packaged;
            string configured=Environment.GetEnvironmentVariable("ASTERMAX_PYTHON");
            if(!String.IsNullOrWhiteSpace(configured) && File.Exists(configured)) return configured;
            string path=Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach(string raw in path.Split(Path.PathSeparator))
            {
                string dir=(raw??"").Trim().Trim('"');
                if(String.IsNullOrWhiteSpace(dir)) continue;
                try
                {
                    string candidate=Path.Combine(dir,"python.exe");
                    if(File.Exists(candidate)) return candidate;
                }
                catch { }
            }
            return null;
        }

        // ASTERMAX_C1206_RUNNER_DISCOVERY
        private static string ResolveCodeAsterRunner()
        {
            return ResolveCodeAsterRunnerFrom(Application.StartupPath,
                Environment.GetEnvironmentVariable("ASTERMAX_CODE_ASTER_RUNNER"));
        }

        // C1206_DISCOVERY_CORE_BEGIN
        private static bool IsUsableCodeAsterRunner(string candidate)
        {
            if(String.IsNullOrWhiteSpace(candidate) || !File.Exists(candidate)) return false;
            string extension=Path.GetExtension(candidate).ToLowerInvariant();
            if(extension!=".exe" && extension!=".cmd" && extension!=".bat" && extension!=".ps1") return false;
            if(String.Equals(Path.GetFileName(candidate),"astermax-codeaster-runner.cmd",StringComparison.OrdinalIgnoreCase))
                return File.Exists(Path.Combine(Path.GetDirectoryName(candidate),"astermax-codeaster-runner.ps1"));
            return true;
        }

        private static string ResolveCodeAsterRunnerFrom(string startupPath,string configured)
        {
            if(!String.IsNullOrWhiteSpace(startupPath))
            {
                // The first location is the distribution contract. The second
                // accepts previously distributed adapter folders without an env var.
                string[] relatives=new[] {
                    Path.Combine("AsterMaxRuntime","CodeAster","astermax-codeaster-runner.cmd"),
                    Path.Combine("CodeAster","astermax-codeaster-runner.cmd")
                };
                foreach(string relative in relatives)
                {
                    try
                    {
                        string candidate=Path.GetFullPath(Path.Combine(startupPath,relative));
                        if(IsUsableCodeAsterRunner(candidate)) return candidate;
                    }
                    catch(ArgumentException) { }
                    catch(NotSupportedException) { }
                    catch(PathTooLongException) { }
                }
            }
            if(String.IsNullOrWhiteSpace(configured)) return null;
            try
            {
                string candidate=Path.GetFullPath(configured.Trim().Trim('"'));
                if(IsUsableCodeAsterRunner(candidate)) return candidate;
            }
            catch(ArgumentException) { }
            catch(NotSupportedException) { }
            catch(PathTooLongException) { }
            return null;
        }
        private static bool HasCodeAsterPostprocessTools(string startupPath)
        {
            if(String.IsNullOrWhiteSpace(startupPath)) return false;
            string tools=Path.Combine(startupPath,"AsterMaxTools");
            return File.Exists(Path.Combine(tools,"bridge-c964-med-results.py")) &&
                   File.Exists(Path.Combine(tools,"bind-c998-results-fingerprint.py")) &&
                   File.Exists(Path.Combine(tools,"qualify-mechanical-analysis.py"));
        }
        // C1206_DISCOVERY_CORE_END

        public static JObject RuntimeDiagnostic()
        {
            string python=ResolvePythonRuntime();
            string runner=ResolveCodeAsterRunner();
            JObject pythonProbe=ProbePythonRuntime(python);
            JObject runnerProbe=ProbeCodeAsterRunner(runner);
            string tools=Path.Combine(Application.StartupPath,"AsterMaxTools");
            return new JObject
            {
                ["runtime_contract"]="ASTERMAX_C1206_COMPLETE_RUNTIME_PROBE_V1",
                ["bridge_ready"]=File.Exists(Path.Combine(tools,"bridge-c964-med-results.py")),
                ["binder_ready"]=File.Exists(Path.Combine(tools,"bind-c998-results-fingerprint.py")),
                ["qualifier_ready"]=File.Exists(Path.Combine(tools,"qualify-mechanical-analysis.py")),
                ["runtime_ready"]=(bool)pythonProbe["ready"] && (bool)runnerProbe["ready"] &&
                                  HasCodeAsterPostprocessTools(Application.StartupPath),
                ["python_executable_found"]=!String.IsNullOrWhiteSpace(python),
                ["python_ready"]=(bool)pythonProbe["ready"],
                ["python_source"]=String.IsNullOrWhiteSpace(python)?"missing":(python.IndexOf("AsterMaxRuntime",StringComparison.OrdinalIgnoreCase)>=0?"packaged":(!String.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("ASTERMAX_PYTHON"))?"environment":"path")),
                ["python_probe"]=pythonProbe,
                ["code_aster_runner_ready"]=!String.IsNullOrWhiteSpace(runner),
                ["code_aster_runner_source"]=String.IsNullOrWhiteSpace(runner)?"missing":(runner.IndexOf("AsterMaxRuntime",StringComparison.OrdinalIgnoreCase)>=0?"packaged":"environment"),
                ["code_aster_transport"]="WINDOWS_NATIVE",
                ["wsl_required"]=false,
                ["code_aster_backend_ready"]=(bool)runnerProbe["ready"],
                ["code_aster_runner_probe"]=runnerProbe,
                ["unit_contract"]="MM_N_S_MPA",
                ["synthetic_results_allowed"]=false
            };
        }
        public static string RuntimeSummary(JObject d)
        {
            string directory=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"AsterMax","Diagnostics");
            Directory.CreateDirectory(directory);
            string log=Path.Combine(directory,"runtime-preflight.json");
            File.WriteAllText(log,d.ToString(Formatting.Indented));
            JObject backend=null;
            try { backend=JObject.Parse((string)d["code_aster_runner_probe"]?["stdout"]??"{}"); } catch { }
            string transport=(string)backend?["transport"]??"No detectado";
            string path=(string)backend?["backend"]??"No detectado";
            string detail=(string)backend?["message"]??"";
            if(detail.Length>400) detail=detail.Substring(0,400)+"...";
            return "Adaptador de AsterMax: "+((bool?)d["code_aster_runner_ready"]==true?"Disponible":"Falta o está incompleto; extraiga nuevamente el ZIP completo")+
                "\nCode_Aster: "+((bool?)d["code_aster_backend_ready"]==true?"DISPONIBLE":"NO DISPONIBLE")+
                "\nModo: "+transport+"\nLanzador: "+path+
                "\nPython de resultados: "+((bool?)d["python_ready"]==true?"Disponible":"No disponible")+
                "\nHerramientas de resultados: "+((bool?)d["bridge_ready"]==true && (bool?)d["binder_ready"]==true && (bool?)d["qualifier_ready"]==true?"Completas":"Faltan archivos; extraiga nuevamente el ZIP completo")+
                "\n"+detail+"\n\nDetección nativa: %LOCALAPPDATA%\\code_aster.\nUse Solución > Verificar para seleccionar una instalación existente.\nSi no tiene Code_Aster, use Solución > Instalar motor y vuelva a Verificar cuando termine.\n\nRegistro: "+log;
        }
        public static JObject RequireRuntimeReady()
        {
            JObject d=RuntimeDiagnostic();
            d["solver_backend"]="Code_Aster";
            d["postprocess_backend"]="MED -> AsterMax bundle -> VTK";
            d["fea_values_invented"]=false;

            if((bool)d["runtime_ready"]==false)
                throw new InvalidOperationException(
                    "No se puede iniciar el cálculo.\n"+RuntimeSummary(d));
            return d;
        }
        private ProcessStartInfo CreatePythonProcess(string python,string arguments)
        {
            return new ProcessStartInfo
            {
                FileName=python,
                Arguments=arguments,
                WorkingDirectory=Workspace,
                UseShellExecute=false,
                CreateNoWindow=true,
                RedirectStandardOutput=true,
                RedirectStandardError=true
            };
        }

        private int RunCaptured(ProcessStartInfo psi,string stem)
        {
            return RunTrackedProcess(psi,stem+"_STDOUT.log",stem+"_STDERR.log");
        }

        public void RequireUnchangedModel(CaeModel.FeModel liveModel)
        {
            var now=AsterMaxModelFingerprint.Extract(liveModel);
            if(!String.Equals(FrozenFingerprint,now.Sha256,StringComparison.OrdinalIgnoreCase))
            {
                State=AsterMaxSolveState.SolutionStale;
                Message="SOLUTION_STALE: active FeModel changed after the solve transaction was frozen.";
                WriteFinalState();
                throw new InvalidOperationException(Message);
            }
        }

        // C1208_BONDED_AND_LOAD_INFO
        public static string DescribeBondedAndLoads(string workspace)
        {
            try
            {
                string path=Path.Combine(workspace,"ASTERMAX_SOLVE_TRANSACTION.json");
                if(!File.Exists(path)) return "";
                JObject manifest=JObject.Parse(File.ReadAllText(path))["native_exporter_manifest"] as JObject;
                if(manifest==null) return "";
                var b=new StringBuilder();
                int pairs=(int?)manifest["bonded_pair_count"] ?? 0;
                JObject report=manifest["bonded_mpc_report"] as JObject;
                if(pairs>0 && report!=null)
                {
                    b.AppendLine("Uniones soldadas (bonded) exportadas: "+pairs+".");
                    b.AppendLine("Acoplamiento permanente de las superficies seleccionadas; coordenadas de la malla conservadas.");
                    b.AppendLine("Separación máxima incluida: "+BondedInfoNumber((double?)report["maximum_gap_mm"])+" mm.");
                    b.AppendLine("Ecuaciones independientes: "+((int?)report["retained_rows"] ?? 0)+
                        "; redundantes eliminadas: "+((int?)report["redundant_rows"] ?? 0)+".");
                    int unmatched=(int?)report["unmatched_slave_node_count"] ?? 0;
                    if(unmatched>0)
                        b.AppendLine("Nodos seleccionados fuera de la tolerancia y sin unión: "+unmatched+
                            ". Revise el informe .bonded-mpc.json antes de interpretar el resultado.");
                    b.AppendLine("Esta idealización no calcula la resistencia local de un cordón de soldadura.");
                    b.AppendLine();
                }
                if(manifest["load_nodes"]!=null && manifest["fx_total_n"]!=null)
                {
                    b.AppendLine("Fuerza nodal exportada: "+manifest["load_nodes"]+" nodos.");
                    b.AppendLine("Componentes por nodo [N]: Fx="+BondedInfoNumber((double?)manifest["fx_per_node_n"])+
                        "; Fy="+BondedInfoNumber((double?)manifest["fy_per_node_n"])+
                        "; Fz="+BondedInfoNumber((double?)manifest["fz_per_node_n"])+".");
                    b.AppendLine("Resultante de esa fuerza [N]: Fx="+BondedInfoNumber((double?)manifest["fx_total_n"])+
                        "; Fy="+BondedInfoNumber((double?)manifest["fy_total_n"])+
                        "; Fz="+BondedInfoNumber((double?)manifest["fz_total_n"])+".");
                    if((bool?)manifest["gravity_enabled"]==true)
                        b.AppendLine("La resultante anterior corresponde a la fuerza nodal; la gravedad se aplica adicionalmente.");
                }
                return b.ToString().Trim();
            }
            catch { return "El resumen de uniones y cargas exportadas no está disponible. Revise el manifiesto del cálculo."; }
        }

        private static string BondedInfoNumber(double? value)
        {
            return value.HasValue?value.Value.ToString("#,0.########",CultureInfo.GetCultureInfo("es-CL")):"n/d";
        }
        // C1208_BONDED_AND_LOAD_INFO_END
        // C1207_SOLVER_DIAGNOSTICS_BEGIN
        // Keep full logs on disk; the dialog explains the root cause and names
        // the affected exported contact zones instead of overflowing the screen.
        private static string BuildRunnerFailureDiagnostic(string workspace,int exitCode)
        {
            try
            {
                JObject diagnostic=ReadRunnerDiagnostic(workspace);
                string stderr=ReadDiagnosticText(Path.Combine(workspace,"CODE_ASTER_RUNNER_STDERR.log"));
                string messPath=FindLatestDiagnosticFile(workspace,"*.mess");
                string mess=ReadDiagnosticText(messPath);
                string evidence=stderr+"\n"+mess;
                string marker=(string)diagnostic?["marker"] ?? "";
                if(String.IsNullOrWhiteSpace(marker))
                {
                    var code=System.Text.RegularExpressions.Regex.Match(evidence,
                        @"(?:ASTERMAX_CODE_ASTER_FAILURE=|<(?:EXCEPTION|F)>\s*<)([A-Z][A-Z0-9]*_\d+)",
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    if(code.Success) marker=code.Groups[1].Value.ToUpperInvariant();
                }
                var b=new StringBuilder();
                if(String.Equals(marker,"CONTACT2_16",StringComparison.OrdinalIgnoreCase))
                {
                    int first=0,second=0,count=0;
                    JArray zones=diagnostic?["contact_zones"] as JArray;
                    if(zones!=null && zones.Count>=2)
                    {
                        Int32.TryParse(zones[0].ToString(),out first);
                        Int32.TryParse(zones[1].ToString(),out second);
                    }
                    Int32.TryParse((string)diagnostic?["shared_slave_nodes"],out count);
                    var stable=System.Text.RegularExpressions.Regex.Match(evidence,
                        @"contact_zones=(\d+),(\d+);shared_slave_nodes=(\d+)");
                    if(stable.Success)
                    {
                        first=Int32.Parse(stable.Groups[1].Value,CultureInfo.InvariantCulture);
                        second=Int32.Parse(stable.Groups[2].Value,CultureInfo.InvariantCulture);
                        count=Int32.Parse(stable.Groups[3].Value,CultureInfo.InvariantCulture);
                    }
                    if(first==0 || second==0)
                    {
                        var legacy=System.Text.RegularExpressions.Regex.Match(evidence,
                            @"zones? de contact[^\r\n]*?(\d+)[^\r\n]*?\bet\b[^\r\n]*?(\d+)[^\r\n]*?\bont\b\s+(\d+)",
                            System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                        if(legacy.Success)
                        {
                            first=Int32.Parse(legacy.Groups[1].Value,CultureInfo.InvariantCulture);
                            second=Int32.Parse(legacy.Groups[2].Value,CultureInfo.InvariantCulture);
                            count=Int32.Parse(legacy.Groups[3].Value,CultureInfo.InvariantCulture);
                        }
                    }
                    b.AppendLine("CONTACT2_16: dos zonas de contacto comparten nodos esclavos.");
                    if(first>0 && second>0)
                        b.AppendLine("Zonas: "+ContactZoneLabel(workspace,first)+" y "+ContactZoneLabel(workspace,second)+".");
                    if(count>0) b.AppendLine("Nodos esclavos compartidos: "+count.ToString(CultureInfo.InvariantCulture)+".");
                    b.AppendLine("Esta formulación exige superficies esclavas sin nodos comunes entre zonas.");
                    b.AppendLine("Revise esos pares en Conexiones: sus regiones y la combinación maestro/esclavo deben ser compatibles.");
                }
                else
                {
                    if(!String.IsNullOrWhiteSpace(marker)) b.AppendLine("Code_Aster detuvo el cálculo: "+marker+".");
                    else if(exitCode==30) b.AppendLine("Code_Aster no produjo todos los archivos de resultado necesarios.");
                    else b.AppendLine("El proceso de cálculo terminó sin resultados aceptables.");
                    string detail=(string)diagnostic?["message"];
                    if(String.IsNullOrWhiteSpace(detail)) detail=FirstSolverFailureLine(evidence);
                    if(!String.IsNullOrWhiteSpace(detail)) b.AppendLine(ShortDiagnostic(detail,500));
                }
                b.AppendLine("No se han aceptado resultados de este intento.");
                b.AppendLine();
                b.AppendLine("Registros completos: "+workspace);
                return b.ToString().Trim();
            }
            catch(Exception ex)
            {
                return "El cálculo falló y no se pudo resumir su diagnóstico: "+ShortDiagnostic(ex.Message,250)+
                    "\nRegistros completos: "+workspace;
            }
        }

        private static string ShortDiagnostic(string text,int limit)
        {
            if(String.IsNullOrWhiteSpace(text)) return "";
            string cleaned=text.Replace("\0","").Trim();
            return cleaned.Length<=limit?cleaned:cleaned.Substring(0,limit)+"...";
        }

        private static string FirstSolverFailureLine(string text)
        {
            foreach(string raw in (text??"").Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries))
            {
                string line=raw.Trim();
                if(line.IndexOf("<EXCEPTION>",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("<F>",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("FATAL ERROR",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("ERREUR FATALE",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.StartsWith("ASTERMAX_CODE_ASTER_RUNNER:",StringComparison.Ordinal))
                    return ShortDiagnostic(line,500);
            }
            return "";
        }

        private static JObject ReadRunnerDiagnostic(string workspace)
        {
            string path=FindLatestDiagnosticFile(workspace,"astermax-runner-diagnostic.json");
            if(String.IsNullOrWhiteSpace(path)) return null;
            try
            {
                JObject result=JObject.Parse(File.ReadAllText(path));
                return (string)result["schema"]=="astermax-codeaster-runner-diagnostic/v1" &&
                       (string)result["status"]=="failed"?result:null;
            }
            catch { return null; }
        }

        private static string FindLatestDiagnosticFile(string workspace,string pattern)
        {
            if(String.IsNullOrWhiteSpace(workspace) || !Directory.Exists(workspace)) return null;
            var directories=new System.Collections.Generic.List<string>();
            directories.Add(workspace);
            directories.AddRange(Directory.GetDirectories(workspace,"failed-*",SearchOption.TopDirectoryOnly));
            string latest=null;
            DateTime modified=DateTime.MinValue;
            foreach(string directory in directories)
            {
                foreach(string file in Directory.GetFiles(directory,pattern,SearchOption.TopDirectoryOnly))
                {
                    DateTime time=File.GetLastWriteTimeUtc(file);
                    if(latest==null || time>modified) { latest=file;modified=time; }
                }
            }
            return latest;
        }

        private static string ReadDiagnosticText(string path)
        {
            if(String.IsNullOrWhiteSpace(path) || !File.Exists(path)) return "";
            // Very long traces remain on disk. Retain the beginning and tail for
            // summaries so a failed calculation cannot flood the dialog memory.
            using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite))
            {
                const int half=131072;
                if(stream.Length<=half*2)
                    using(var reader=new StreamReader(stream,Encoding.UTF8,true)) return reader.ReadToEnd();
                byte[] head=new byte[half];
                int headRead=stream.Read(head,0,head.Length);
                stream.Seek(-half,SeekOrigin.End);
                byte[] tail=new byte[half];
                int tailRead=stream.Read(tail,0,tail.Length);
                return Encoding.UTF8.GetString(head,0,headRead)+"\n[registro intermedio omitido en el resumen]\n"+
                       Encoding.UTF8.GetString(tail,0,tailRead);
            }
        }

        private static string ContactZoneLabel(string workspace,int index)
        {
            string label=index.ToString(CultureInfo.InvariantCulture);
            try
            {
                string path=Path.Combine(workspace,"ASTERMAX_SOLVE_TRANSACTION.json");
                if(!File.Exists(path)) return label;
                JObject transaction=JObject.Parse(File.ReadAllText(path));
                JArray zones=transaction["native_exporter_manifest"]?["contact_orientation_report"]?["zones"] as JArray;
                if(zones==null) return label;
                foreach(JObject zone in zones)
                {
                    if((int?)zone["zone_index"]!=index) continue;
                    string name=(string)zone["contact_name"];
                    if(!String.IsNullOrWhiteSpace(name)) label+=" ("+ShortDiagnostic(name,100).Replace("\r"," ").Replace("\n"," ")+")";
                    break;
                }
            }
            catch { }
            return label;
        }
        // C1207_CONTACT_ORIENTATION_INFO
        public static string DescribeContactOrientation(string workspace)
        {
            try
            {
                string path=Path.Combine(workspace,"ASTERMAX_SOLVE_TRANSACTION.json");
                if(!File.Exists(path)) return "";
                JObject transaction=JObject.Parse(File.ReadAllText(path));
                JObject report=transaction["native_exporter_manifest"]?["contact_orientation_report"] as JObject;
                int count=(int?)report?["swapped_count"] ?? 0;
                if(count<=0) return "";
                var names=new System.Collections.Generic.List<string>();
                JArray zones=report["zones"] as JArray;
                if(zones!=null)
                    foreach(JObject zone in zones)
                        if((bool?)zone["swapped"]==true)
                            names.Add(ShortDiagnostic((string)zone["contact_name"],100).Replace("\r"," ").Replace("\n"," "));
                return "Orientación de contactos: "+count.ToString(CultureInfo.InvariantCulture)+(count==1?" par reorientado":" pares reorientados")+" al exportar para evitar nodos esclavos repetidos.\r\n"+
                    "Pares: "+ShortDiagnostic(String.Join(", ",names),700)+".\r\n"+
                    "Se conservan las superficies y leyes; la orientación numérica maestro/esclavo cambió. Revise la convergencia y la calificación del resultado.";
            }
            catch { return "La auditoría de orientación de contactos no está disponible."; }
        }
        // C1207_SOLVER_DIAGNOSTICS_END
        private static string TailText(string text,int maxLines)
        {
            if(String.IsNullOrWhiteSpace(text)) return "";
            string[] lines=text.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries);
            var b=new StringBuilder();
            for(int i=Math.Max(0,lines.Length-maxLines);i<lines.Length;i++)
            {
                string line=(lines[i]??"").Trim();
                if(line.Length>320) line=line.Substring(0,320)+"...";
                if(line.Length>0) b.AppendLine(line);
            }
            return b.ToString().Trim();
        }
        private static bool TryReadCodeAsterExitCode(string line, out int code)
        {
            code=0;
            if(String.IsNullOrWhiteSpace(line)) return false;
            string value=line.Trim();
            bool marker=value.StartsWith("EXECUTION_CODE_ASTER_EXIT_",StringComparison.OrdinalIgnoreCase) ||
                        value.StartsWith("EXIT_CODE=",StringComparison.OrdinalIgnoreCase);
            if(!marker) return false;
            int equals=value.LastIndexOf('=');
            if(equals<0 || equals>=value.Length-1) return false;
            return Int32.TryParse(value.Substring(equals+1).Trim(),NumberStyles.Integer,CultureInfo.InvariantCulture,out code);
        }

        private static bool HasCodeAsterNormalStop(string mess)
        {
            if(String.IsNullOrWhiteSpace(mess)) return false;
            if(mess.IndexOf("ARRET NORMAL",StringComparison.OrdinalIgnoreCase)>=0) return true;
            string[] lines=mess.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries);
            foreach(string raw in lines)
            {
                int code;
                if(TryReadCodeAsterExitCode(raw,out code) && code==0) return true;
            }
            return false;
        }

        private static string GetCodeAsterFailure(string mess)
        {
            if(String.IsNullOrWhiteSpace(mess)) return "The .mess file is empty.";
            string[] lines=mess.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries);
            foreach(string raw in lines)
            {
                string line=(raw??"").Trim();
                int code;
                if(TryReadCodeAsterExitCode(line,out code) && code!=0)
                    return "Code_Aster exit marker: "+line+"\n\nLast .mess lines:\n"+BuildCodeAsterDiagnostic(mess);
                if(line.StartsWith("<F>",StringComparison.OrdinalIgnoreCase) ||
                   line.StartsWith("<F>_",StringComparison.OrdinalIgnoreCase) ||
                   line.IndexOf("<F> <",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("<EXCEPTION>",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("_ABNORMAL_ABORT",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("FATAL ERROR",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("ERREUR FATALE",StringComparison.OrdinalIgnoreCase)>=0 ||
                   line.IndexOf("Traceback (most recent call last)",StringComparison.OrdinalIgnoreCase)>=0)
                    return "Code_Aster fatal marker: "+line+"\n\nLast .mess lines:\n"+BuildCodeAsterDiagnostic(mess);
            }
            return null;
        }

        private static string BuildCodeAsterDiagnostic(string mess)
        {
            if(String.IsNullOrWhiteSpace(mess)) return "No .mess diagnostic text is available.";
            string[] lines=mess.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries);
            var tail=new StringBuilder();
            int first=Math.Max(0,lines.Length-14);
            for(int i=first;i<lines.Length;i++)
            {
                string line=(lines[i]??"").Trim();
                if(line.Length==0) continue;
                if(line.Length>260) line=line.Substring(0,260)+"...";
                tail.AppendLine(line);
            }
            return tail.ToString().Trim();
        }
        private void Fail(string message)
        {
            lock(_stateTransitionSync)
            {
                if(_cancelRequested)
                {
                    State=AsterMaxSolveState.Cancelled;
                    Message="CANCELLED: native Solve was cancelled by the user.";
                    WriteFinalState();
                    throw new OperationCanceledException(Message);
                }
                State=AsterMaxSolveState.Failed;
                Message=message;
                WriteFinalState();
            }
            throw new InvalidOperationException(message);
        }

        private void WriteFinalState()
        {
            lock(_stateFileSync)
            {
                long revision=System.Threading.Interlocked.Increment(ref _stateRevision);
                if(String.IsNullOrWhiteSpace(Workspace) || !Directory.Exists(Workspace)) return;
                JObject state=new JObject
                {
                    ["schema"]=Schema,
                    ["release"]="C10.06",
                    ["state"]=State.ToString().ToUpperInvariant(),
                    ["message"]=Message,
                    ["model_fingerprint_sha256"]=FrozenFingerprint,
                    ["runner"]=RunnerExecutable,
                    ["runner_exit_code"]=RunnerExitCode.HasValue?(JToken)RunnerExitCode.Value:JValue.CreateNull(),
                    ["mess_exists"]=File.Exists(MessFile),
                    ["med_exists"]=File.Exists(MedFile),
                    ["result_bundle_exists"]=!String.IsNullOrWhiteSpace(ResultBundleFile) && File.Exists(ResultBundleFile),
                    ["result_vtu_exists"]=!String.IsNullOrWhiteSpace(ResultVtuFile) && File.Exists(ResultVtuFile),
                    ["postprocessor_python"]=PostprocessorExecutable,
                    ["postprocessor_exit_code"]=PostprocessorExitCode.HasValue?(JToken)PostprocessorExitCode.Value:JValue.CreateNull(),
                    ["cancel_requested"]=_cancelRequested,
                    ["state_revision"]=revision,
                    ["fea_values_invented"]=false
                };
                string finalPath=Path.Combine(Workspace,"ASTERMAX_SOLVE_STATE.json");
                string tempPath=finalPath+"."+Guid.NewGuid().ToString("N")+".tmp";
                File.WriteAllText(tempPath,state.ToString(Formatting.Indented),new UTF8Encoding(false));
                try
                {
                    if(File.Exists(finalPath)) File.Replace(tempPath,finalPath,null);
                    else File.Move(tempPath,finalPath);
                }
                finally
                {
                    if(File.Exists(tempPath)) File.Delete(tempPath);
                }
            }
        }

        private static void WriteExport(string path,string n)
        {
            string text="A tpmax 900\nA memjeveux 512\nP ncpus 1\nP mpi_nbcpu 1\nP mpi_nbnoeud 1\nP version stable\nP actions make_etude\n\n"+
                "F comm ./"+n+".comm D 1\n"+
                "F mail ./"+n+".mail D 20\n"+
                "F mess ./"+n+".mess R 6\n"+
                "F resu ./"+n+".resu R 80\n"+
                "F rmed ./"+n+".rmed R 81\n";
            File.WriteAllText(path,text,new UTF8Encoding(false));
        }
        private static string Quote(string s){ return "\""+(s??"").Replace("\"","\\\"")+"\""; }
    }

    public partial class FrmMain
    {
        private AsterMaxNativeSolveTransaction _asterMaxSolveTransaction;

        private void StartAsterMaxCodeAsterSetup()
        {
            try
            {
                string directory=Path.Combine(Application.StartupPath,"AsterMaxRuntime","CodeAster");
                string setup=Path.Combine(directory,"setup-codeaster-windows.cmd");
                if(!File.Exists(setup) || !File.Exists(Path.Combine(directory,"setup-codeaster-windows.ps1")))
                    throw new FileNotFoundException("El instalador de Code_Aster no está en el paquete. Extraiga todo el ZIP de AsterMax en una carpeta nueva.");
                // Only the explicit ribbon click opens setup. The setup process
                // owns installation/probing; do not block the WinForms UI thread.
                Process.Start(new ProcessStartInfo {
                    FileName=setup,
                    WorkingDirectory=directory,
                    UseShellExecute=true
                });
                tsslState.Text="Instalador Code_Aster abierto. Cuando termine, use Solución > Verificar.";
            }
            catch(Exception ex)
            {
                CaeGlobals.MessageBoxes.ShowError("No se pudo abrir el instalador de Code_Aster: "+ex.Message);
            }
        }
        private void ShowAsterMaxRuntimePreflight()
        {
            try
            {
                JObject d=AsterMaxNativeSolveTransaction.RuntimeDiagnostic();

                                if ((bool?)d["code_aster_backend_ready"]!=true && MessageBox.Show(this,
                    AsterMaxNativeSolveTransaction.RuntimeSummary(d)+"\n\n¿Seleccionar carpeta de Code_Aster para Windows?",
                    "Configurar Code_Aster",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes) {
                    using(var folder=new FolderBrowserDialog { Description="Seleccione code_aster, su versión, o la carpeta que contiene install\\bin\\as_run.bat" }) {
                        if(folder.ShowDialog(this)==DialogResult.OK) {
                            string configDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"AsterMax");
                            Directory.CreateDirectory(configDir);
                            File.WriteAllText(Path.Combine(configDir,"code-aster-windows.json"),new JObject{["installation"]=folder.SelectedPath}.ToString());
                            d=AsterMaxNativeSolveTransaction.RuntimeDiagnostic();
                        }
                    }
                }
                MessageBox.Show(this,AsterMaxNativeSolveTransaction.RuntimeSummary(d),
                    "AsterMax Runtime Preflight",MessageBoxButtons.OK,
                    ((bool?)d["runtime_ready"]==true)?MessageBoxIcon.Information:MessageBoxIcon.Warning);
            }
            catch(Exception ex)
            {
                CaeGlobals.MessageBoxes.ShowError("Runtime preflight failed: "+ex.Message);
            }
        }
        private bool _asterMaxSolveInProgress;
        private Exception _asterMaxSolveLastError;
        private int _asterMaxSolveUiHeartbeatCount;
        private int _asterMaxSolveUiThreadId;
        private int _asterMaxSolveWorkerThreadId;
        private int _asterMaxSolveDuplicateRequestsRejected;
        private CaeModel.FeModel _asterMaxSolveFrozenModelInstance;
        private long _asterMaxSolveFrozenSessionRevision;
        private bool _asterMaxSolveModelSessionPreserved;
        private bool _asterMaxSolveRibbonWasEnabled;
        private bool _asterMaxSolveTreeWasEnabled;
        private bool _asterMaxSolveMenuWasEnabled;

        private void SetAsterMaxSolveUiBusy(bool busy)
        {
            TabControl ribbon=Controls["asterMaxRibbon"] as TabControl;
            if(busy)
            {
                if(ribbon!=null) _asterMaxSolveRibbonWasEnabled=ribbon.Enabled;
                if(_modelTree!=null) { _asterMaxSolveTreeWasEnabled=_modelTree.Enabled; _modelTree.Enabled=false; }
                if(MainMenuStrip!=null) { _asterMaxSolveMenuWasEnabled=MainMenuStrip.Enabled; MainMenuStrip.Enabled=false; }
            }
            else
            {
                if(ribbon!=null) ribbon.Enabled=_asterMaxSolveRibbonWasEnabled;
                if(_modelTree!=null) _modelTree.Enabled=_asterMaxSolveTreeWasEnabled;
                if(MainMenuStrip!=null) MainMenuStrip.Enabled=_asterMaxSolveMenuWasEnabled;
            }
        }

        private void CancelAsterMaxNativeSolve()
        {
            if(!_asterMaxSolveInProgress || _asterMaxSolveTransaction==null)
            {
                tsslState.Text="AsterMax Solve: no active solve to cancel";
                return;
            }
            tsslState.Text="AsterMax Solve: CANCELLING";
            _asterMaxSolveTransaction.RequestCancel();
        }
        private async void RunAsterMaxNativeSolve()
        {
            if(_asterMaxSolveInProgress || _asterMaxProgress != null || IsStateWorking())
            {
                _asterMaxSolveDuplicateRequestsRejected++;
                tsslState.Text="AsterMax Solve: already running";
                return;
            }

            System.Windows.Forms.Timer heartbeat=null;
            bool uiBusySet=false;
            AsterMaxNativeSolveTransaction transaction=null;
            CaeModel.FeModel solveModel=null;
            AsterMaxResultsBundle previousResults=_asterMaxLoadedResults;
            try
            {
                if(_controller==null || _controller.Model==null)
                    throw new InvalidOperationException("No active FeModel is available.");

                _asterMaxSolveInProgress=true;
                _asterMaxSolveTransaction=null;
                _asterMaxSolveLastError=null;
                SetAsterMaxSolveUiBusy(true);
                uiBusySet=true;
                BeginAsterMaxProgress("[Astermax] Resolución", "Revisando fuerzas y conexiones…");
                _asterMaxProgress.EnableConsole();
                solveModel=_controller.Model;
                // C1208_FORCE_PREVIEW: current model contents, not the EXE release label.
                JObject forcePreviewContract=await Task.Run(() => AsterMaxModelContractBridge.Build(solveModel));
                var forcePreview=AsterMaxForceDistribution.Build(forcePreviewContract);
                _asterMaxProgress.Hide();
                if(!_asterMaxUiAuditMode && MessageBox.Show(this,
                    AsterMaxForceDistribution.Describe(forcePreviewContract,forcePreview)+"\n\n¿Continuar con esta definición?",
                    "[Astermax] Revisar fuerza y conexiones",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2)!=DialogResult.Yes) return;
                _asterMaxProgress.Show(this);
                _asterMaxProgress.UpdateStage("Preparando malla, restricciones y archivos de cálculo…");
                _asterMaxSolveFrozenModelInstance=solveModel;
                _asterMaxSolveFrozenSessionRevision=_asterMaxModelSessionRevision;
                _asterMaxSolveModelSessionPreserved=false;
                string work=_controller.Settings.GetWorkDirectory();
                transaction=await Task.Run(() => AsterMaxNativeSolveTransaction.Prepare(solveModel,work,"astermax-analysis"));
                _asterMaxSolveTransaction=transaction;
                _asterMaxSolveLastError=null;
                _asterMaxSolveUiThreadId=System.Threading.Thread.CurrentThread.ManagedThreadId;
                _asterMaxSolveWorkerThreadId=0;
                _asterMaxSolveUiHeartbeatCount=0;
                _asterMaxPreviousResultsRetained=previousResults!=null;
                ShowAsterMaxModelWorkspace();
                RefreshAsterMaxResultAvailability();

                heartbeat=new System.Windows.Forms.Timer { Interval=25 };
                heartbeat.Tick += (sender,args) => {
                    _asterMaxSolveUiHeartbeatCount++;
                    if(transaction!=null)
                    {
                        tsslState.Text="AsterMax Solve: "+transaction.State.ToString().ToUpperInvariant()+" (background)";
                        if(_asterMaxProgress!=null)
                        {
                            _asterMaxProgress.AppendConsole(transaction.DrainConsole());
                            _asterMaxProgress.UpdateStage(AsterMaxSolveStage(transaction.State),
                                transaction.State==AsterMaxSolveState.ReadyToRun || transaction.State==AsterMaxSolveState.Running || transaction.State==AsterMaxSolveState.Postprocessing
                                    ? (Action)CancelAsterMaxNativeSolve : null);
                        }
                    }
                };
                heartbeat.Start();
                tsslState.Text="AsterMax Solve: READY_TO_RUN (background)";

                AsterMaxResultsBundle completedBundle=await Task.Run(() => {
                    _asterMaxSolveWorkerThreadId=System.Threading.Thread.CurrentThread.ManagedThreadId;
                    transaction.ExecuteConfiguredRunner(solveModel);
                    return transaction.CompleteVerifiedResultsHandoff(solveModel);
                });

                if(!Object.ReferenceEquals(_asterMaxSolveTransaction,transaction))
                    throw new InvalidOperationException("Active solve transaction changed while the background solve was running.");
                if(_controller==null || !Object.ReferenceEquals(_controller.Model,solveModel))
                    throw new InvalidOperationException("Active model instance changed while the background solve was running; results were not published.");
                if(_asterMaxModelSessionRevision!=_asterMaxSolveFrozenSessionRevision)
                    throw new InvalidOperationException("Active model session changed while the background solve was running; results were not published.");

                _asterMaxSolveModelSessionPreserved=true;
                _asterMaxLoadedResults=completedBundle;
                _asterMaxPreviousResultsRetained=false;
                tsslState.Text="AsterMax Solve: SOLUTION_CURRENT";
                EndAsterMaxProgress();
                ShowAsterMaxIntegratedResult(null);
            }
            catch(OperationCanceledException ex)
            {
                _asterMaxSolveLastError=ex;
                tsslState.Text="AsterMax Solve: CANCELLED";
            }
            catch(Exception ex)
            {
                _asterMaxSolveLastError=ex;
                tsslState.Text="AsterMax Solve: BLOCKED / FAILED";
                EndAsterMaxProgress();
                if(!_asterMaxUiAuditMode)
                    CaeGlobals.MessageBoxes.ShowError("Error de cálculo de AsterMax:\n\n"+ex.Message);
            }
            finally
            {
                if(heartbeat!=null)
                {
                    heartbeat.Stop();
                    heartbeat.Dispose();
                }
                bool closeAfterSolveCancel=_asterMaxCloseAfterSolveCancel;
                _asterMaxCloseAfterSolveCancel=false;
                _asterMaxSolveInProgress=false;
                EndAsterMaxProgress();
                if(uiBusySet && !IsDisposed && !Disposing) SetAsterMaxSolveUiBusy(false);
                if(!IsDisposed && !Disposing) RefreshAsterMaxResultAvailability();
                if(closeAfterSolveCancel && !IsDisposed && !Disposing)
                    BeginInvoke(new Action(Close));
            }
        }
    }
}

















