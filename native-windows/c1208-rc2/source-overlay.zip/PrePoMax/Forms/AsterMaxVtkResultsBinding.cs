using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CaeGlobals;
using vtkControl;

namespace PrePoMax
{
    internal sealed class AsterMaxResultsColorContract
    {
        public string Field { get; private set; }
        public string Unit { get; private set; }
        public double Minimum { get; private set; }
        public double Maximum { get; private set; }
        public double SpectrumMinimum { get; private set; }
        public double SpectrumMaximum { get; private set; }
        public bool FeaValuesInvented { get; private set; }

        private AsterMaxResultsColorContract() { }

        public static AsterMaxResultsColorContract FromScene(AsterMaxResultsScene scene)
        {
            if (scene == null) throw new ArgumentNullException("scene");
            if (scene.FeaValuesInvented) throw new InvalidOperationException("Synthetic FEA scene rejected by renderer contract.");
            if (Double.IsNaN(scene.Minimum) || Double.IsInfinity(scene.Minimum) ||
                Double.IsNaN(scene.Maximum) || Double.IsInfinity(scene.Maximum))
                throw new InvalidOperationException("Non-finite result range rejected.");
            double lo=scene.Minimum, hi=scene.Maximum;
            if (hi < lo) throw new InvalidOperationException("Invalid result range.");
            double span=Math.Abs(hi-lo);
            double eps=Math.Max(1e-12,Math.Max(Math.Abs(lo),Math.Abs(hi))*1e-12);
            double slo=lo, shi=hi;
            if (span <= eps) { slo=lo-eps; shi=hi+eps; }
            return new AsterMaxResultsColorContract {
                Field=scene.Field, Unit=scene.Unit, Minimum=lo, Maximum=hi,
                SpectrumMinimum=slo, SpectrumMaximum=shi, FeaValuesInvented=false
            };
        }

        public vtkControl.vtkMaxColorSpectrum CreateVtkSpectrum()
        {
            var spectrum=new vtkControl.vtkMaxColorSpectrum();
            spectrum.Type=vtkControl.vtkColorSpectrumType.Rainbow;
            spectrum.MinMaxType=vtkControl.vtkColorSpectrumMinMaxType.Manual;
            spectrum.NumberOfColors=12;
            // vtkMaxColorSpectrum setters enforce min<max. Sequence is selected so arbitrary
            // positive, negative and mixed result ranges remain valid.
            if (SpectrumMaximum <= 0)
            {
                spectrum.MinUserValue=SpectrumMinimum;
                spectrum.MaxUserValue=SpectrumMaximum;
            }
            else
            {
                spectrum.MaxUserValue=SpectrumMaximum;
                spectrum.MinUserValue=SpectrumMinimum;
            }
            return spectrum;
        }

        public string Describe()
        {
            return String.Format(System.Globalization.CultureInfo.InvariantCulture,
                "{0}|{1}|min={2:R}|max={3:R}|vtkMin={4:R}|vtkMax={5:R}|invented=false",
                Field,Unit,Minimum,Maximum,SpectrumMinimum,SpectrumMaximum);
        }
    }
    internal static class AsterMaxVtkResultsBinding
    {
        public const int VtkTriangle = 5;
        public const int VtkQuad = 9;
        public const int VtkTetra = 10;
        public const int VtkHexahedron = 12;
        public const int VtkQuadraticTriangle = 22;
        public const int VtkQuadraticTetra = 24;

        private sealed class SurfaceFace { public int Type; public int[] Nodes; public int Count; }
        private sealed class SurfaceMesh { public int[][] Connectivity; public int[] Types; }

        private static string SurfaceFaceKey(int[] nodes,int cornerCount)
        {
            return cornerCount.ToString()+":"+String.Join(",",nodes.Take(cornerCount).OrderBy(x=>x));
        }
        private static void AddSurfaceFace(System.Collections.Generic.Dictionary<string,SurfaceFace> faces,int type,int[] nodes,int cornerCount)
        {
            string key=SurfaceFaceKey(nodes,cornerCount); SurfaceFace face;
            if(faces.TryGetValue(key,out face)){face.Count++;return;}
            faces.Add(key,new SurfaceFace{Type=type,Nodes=nodes,Count=1});
        }
        private static SurfaceMesh BuildExteriorSurface(AsterMaxResultsBundle bundle)
        {
            var faces=new System.Collections.Generic.Dictionary<string,SurfaceFace>(StringComparer.Ordinal);
            for(int i=0;i<bundle.Connectivity.Length;i++)
            {
                int[] c=bundle.Connectivity[i].Select(id=>id-1).ToArray();
                int type=bundle.CellTypes[i];
                if(type==VtkTetra)
                {
                    AddSurfaceFace(faces,VtkTriangle,new[]{c[0],c[2],c[1]},3);
                    AddSurfaceFace(faces,VtkTriangle,new[]{c[0],c[1],c[3]},3);
                    AddSurfaceFace(faces,VtkTriangle,new[]{c[1],c[2],c[3]},3);
                    AddSurfaceFace(faces,VtkTriangle,new[]{c[2],c[0],c[3]},3);
                }
                else if(type==VtkQuadraticTetra)
                {
                    // VTK quadratic tetra: corners 0..3; midside nodes 01,12,20,03,13,23.
                    AddSurfaceFace(faces,VtkQuadraticTriangle,new[]{c[0],c[2],c[1],c[6],c[5],c[4]},3);
                    AddSurfaceFace(faces,VtkQuadraticTriangle,new[]{c[0],c[1],c[3],c[4],c[8],c[7]},3);
                    AddSurfaceFace(faces,VtkQuadraticTriangle,new[]{c[1],c[2],c[3],c[5],c[9],c[8]},3);
                    AddSurfaceFace(faces,VtkQuadraticTriangle,new[]{c[2],c[0],c[3],c[6],c[7],c[9]},3);
                }
                else if(type==VtkHexahedron)
                {
                    AddSurfaceFace(faces,VtkQuad,new[]{c[0],c[3],c[2],c[1]},4);
                    AddSurfaceFace(faces,VtkQuad,new[]{c[4],c[5],c[6],c[7]},4);
                    AddSurfaceFace(faces,VtkQuad,new[]{c[0],c[1],c[5],c[4]},4);
                    AddSurfaceFace(faces,VtkQuad,new[]{c[1],c[2],c[6],c[5]},4);
                    AddSurfaceFace(faces,VtkQuad,new[]{c[2],c[3],c[7],c[6]},4);
                    AddSurfaceFace(faces,VtkQuad,new[]{c[3],c[0],c[4],c[7]},4);
                }
                else throw new NotSupportedException("Unsupported volume VTK result cell type: "+type);
            }
            if(faces.Values.Any(x=>x.Count>2)) throw new InvalidOperationException("Result mesh contains a non-manifold face shared by more than two volume cells.");
            SurfaceFace[] exterior=faces.Values.Where(x=>x.Count==1).ToArray();
            if(exterior.Length==0) throw new InvalidOperationException("Result mesh exterior surface is empty.");
            return new SurfaceMesh{Connectivity=exterior.Select(x=>x.Nodes).ToArray(),Types=exterior.Select(x=>x.Type).ToArray()};
        }
        public static vtkMaxActorData BuildActorData(AsterMaxResultsBundle bundle, AsterMaxResultsScene scene)
        {
            if (bundle == null) throw new ArgumentNullException("bundle");
            if (scene == null) throw new ArgumentNullException("scene");
            if (scene.FeaValuesInvented) throw new InvalidOperationException("Synthetic FEA scene rejected.");
            if (bundle.Connectivity == null || bundle.Connectivity.Length != bundle.ElementCount)
                throw new InvalidOperationException("Result mesh connectivity is unavailable.");
            if (bundle.CellTypes == null || bundle.CellTypes.Length != bundle.ElementCount)
                throw new InvalidOperationException("Result mesh cell types are unavailable.");
            if (scene.Scalars.Length != bundle.NodeCount || scene.DeformedCoordinates.Length != bundle.NodeCount)
                throw new InvalidOperationException("Scene array/node count mismatch.");

            var data = new vtkMaxActorData();
            data.Name = "AsterMax::" + scene.Field;
            data.Pickable = true;
            data.ColorContours = true;
            data.CanHaveElementEdges = true;
            data.ActorRepresentation = vtkMaxActorRepresentation.Solid;
            data.BackfaceCulling = false;
            data.Ambient = 0.25;
            data.Diffuse = 0.75;
            data.Color = Color.LightGray;

            data.Geometry.Nodes.Ids = Enumerable.Range(1, bundle.NodeCount).ToArray();
            data.Geometry.Nodes.Coor = scene.DeformedCoordinates.Select(p => new[] { p[0], p[1], p[2] }).ToArray();
            data.Geometry.Nodes.Values = scene.Scalars.Select(x => (float)x).ToArray();

            // Required by vtkControl.UpdateScalarFormatting(): actors without MinNode/MaxNode
            // are treated as if no scalar field exists, even when PointData scalars are present.
            int minScalarIndex=0, maxScalarIndex=0;
            for(int si=1;si<scene.Scalars.Length;si++)
            {
                if(scene.Scalars[si] < scene.Scalars[minScalarIndex]) minScalarIndex=si;
                if(scene.Scalars[si] > scene.Scalars[maxScalarIndex]) maxScalarIndex=si;
            }
            data.Geometry.ExtremeNodes.Ids = new[]{minScalarIndex+1,maxScalarIndex+1};
            data.Geometry.ExtremeNodes.Coor = new[]{
                new[]{scene.DeformedCoordinates[minScalarIndex][0],scene.DeformedCoordinates[minScalarIndex][1],scene.DeformedCoordinates[minScalarIndex][2]},
                new[]{scene.DeformedCoordinates[maxScalarIndex][0],scene.DeformedCoordinates[maxScalarIndex][1],scene.DeformedCoordinates[maxScalarIndex][2]}
            };
            data.Geometry.ExtremeNodes.Values = new[]{(float)scene.Scalars[minScalarIndex],(float)scene.Scalars[maxScalarIndex]};
            SurfaceMesh surface=BuildExteriorSurface(bundle);
            data.Geometry.Cells.Ids = Enumerable.Range(1, surface.Connectivity.Length).ToArray();
            data.Geometry.Cells.CellNodeIds = surface.Connectivity;
            data.Geometry.Cells.Types = surface.Types;
            data.Geometry.Cells.Values = null;
            return data;
        }
    }

    internal sealed class AsterMaxNativeProbeResult
    {
        public int NodeIndex { get; private set; }
        public double Value { get; private set; }
        public string Field { get; private set; }
        public string Unit { get; private set; }
        public double[] PickedPoint { get; private set; }
        public bool RendererDerived { get; private set; }
        public bool FeaValuesInvented { get; private set; }

        private AsterMaxNativeProbeResult() { }

        public static AsterMaxNativeProbeResult FromRendererPoint(AsterMaxResultsBundle bundle, AsterMaxResultsScene scene, double[] pickedPoint)
        {
            if(bundle==null) throw new ArgumentNullException("bundle");
            if(scene==null) throw new ArgumentNullException("scene");
            if(scene.FeaValuesInvented) throw new InvalidOperationException("Synthetic FEA scene rejected by probe.");
            if(pickedPoint==null || pickedPoint.Length<3) throw new ArgumentException("VTK picked point is required.","pickedPoint");
            if(scene.DeformedCoordinates==null || scene.DeformedCoordinates.Length!=bundle.NodeCount)
                throw new InvalidOperationException("Deformed render coordinates are unavailable.");

            double xmin=Double.PositiveInfinity,xmax=Double.NegativeInfinity;
            double ymin=Double.PositiveInfinity,ymax=Double.NegativeInfinity;
            double zmin=Double.PositiveInfinity,zmax=Double.NegativeInfinity;
            foreach(var q in scene.DeformedCoordinates){xmin=Math.Min(xmin,q[0]);xmax=Math.Max(xmax,q[0]);ymin=Math.Min(ymin,q[1]);ymax=Math.Max(ymax,q[1]);zmin=Math.Min(zmin,q[2]);zmax=Math.Max(zmax,q[2]);}
            double diag=Math.Sqrt((xmax-xmin)*(xmax-xmin)+(ymax-ymin)*(ymax-ymin)+(zmax-zmin)*(zmax-zmin));
            double tol=Math.Max(1e-9,diag*1e-7); // mm; matching tolerance only, never used to alter FEA values.
            double tol2=tol*tol;
            int match=-1;
            for(int i=0;i<scene.DeformedCoordinates.Length;i++)
            {
                var q=scene.DeformedCoordinates[i]; double dx=q[0]-pickedPoint[0],dy=q[1]-pickedPoint[1],dz=q[2]-pickedPoint[2];
                if(dx*dx+dy*dy+dz*dz<=tol2)
                {
                    if(match>=0) throw new InvalidOperationException("Ambiguous VTK node pick rejected.");
                    match=i;
                }
            }
            if(match<0) throw new InvalidOperationException("VTK pick did not resolve to an exact rendered node; no nearest-node fallback is permitted.");
            return new AsterMaxNativeProbeResult {
                NodeIndex=match,
                Value=bundle.ProbeNode(match,scene.Field),
                Field=scene.Field,
                Unit=scene.Unit,
                PickedPoint=new[]{pickedPoint[0],pickedPoint[1],pickedPoint[2]},
                RendererDerived=true,
                FeaValuesInvented=false
            };
        }

        public string Describe()
        {
            return String.Format(System.Globalization.CultureInfo.InvariantCulture,
                "renderer=true|field={0}|unit={1}|node={2}|value={3:R}|x={4:R}|y={5:R}|z={6:R}|invented=false",
                Field,Unit,NodeIndex+1,Value,PickedPoint[0],PickedPoint[1],PickedPoint[2]);
        }
    }
    internal sealed partial class AsterMaxResultsViewportForm : Form
    {
        private readonly AsterMaxResultsBundle _bundle;
        private readonly Panel _host;
        private vtkControl.vtkControl _view;
        private readonly ComboBox _field;
        private readonly ComboBox _displayUnit;
        private readonly ComboBox _numberFormat;
        private readonly NumericUpDown _legendBands;
        private double _displayScalarFactor = 1.0;
        private readonly NumericUpDown _scale;
        private readonly CheckBox _showContours;
        private readonly CheckBox _showEdges;
        private readonly CheckBox _showDeformed;
        private readonly CheckBox _autoRange;
        private readonly NumericUpDown _rangeMin;
        private readonly NumericUpDown _rangeMax;
        private readonly NumericUpDown _probeNode;
        private readonly Label _status;
        private readonly Label _minLabel;
        private readonly Label _maxLabel;
        private readonly Label _probeLabel;
        private readonly Label _integrityLabel;
        private readonly AsterMaxLegendPanel _legend;
        private AsterMaxResultsScene _scene;

        public AsterMaxResultsViewportForm(AsterMaxResultsBundle bundle)
        {
            _bundle=bundle ?? throw new ArgumentNullException("bundle");
            Text="AsterMax Mechanical — Results Workspace";
            Width=1280; Height=800; StartPosition=FormStartPosition.CenterParent;
            BackColor=Color.FromArgb(245,247,250);

            var top=new FlowLayoutPanel { Dock=DockStyle.Top, Height=82, Padding=new Padding(10,8,10,6), BackColor=Color.White, AutoScroll=true, WrapContents=true };
            _field=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList, Width=210 };
            _field.Items.AddRange(bundle.AvailableFields()); _field.SelectedIndex=Math.Min(1,_field.Items.Count-1);
            _displayUnit=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList, Width=76 };
            _numberFormat=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList, Width=92 };
            _numberFormat.Items.AddRange(new object[]{"Auto","Decimal","Científico"}); _numberFormat.SelectedIndex=0;
            _legendBands=new NumericUpDown { Minimum=5, Maximum=16, Value=9, Width=50 };
            UpdateAsterMaxDisplayUnits();
            _scale=new NumericUpDown { DecimalPlaces=3, Minimum=0, Maximum=100000, Width=105 };
            _scale.Value=(decimal)Math.Min(100000,AsterMaxResultsScene.RecommendDeformationScale(bundle,0.10));
            _showDeformed=new CheckBox { Text="Deformed", Checked=true, AutoSize=true, Padding=new Padding(8,5,0,0) };
            _showContours=new CheckBox { Text="Contours", Checked=true, AutoSize=true, Padding=new Padding(8,5,0,0) };
            _showEdges=new CheckBox { Text="Mesh edges", Checked=true, AutoSize=true, Padding=new Padding(8,5,0,0) };
            _autoRange=new CheckBox { Text="Auto range", Checked=true, AutoSize=true, Padding=new Padding(8,5,0,0) };
            _rangeMin=new NumericUpDown { DecimalPlaces=4, Minimum=-1000000000M, Maximum=1000000000M, Width=92, Enabled=false };
            _rangeMax=new NumericUpDown { DecimalPlaces=4, Minimum=-1000000000M, Maximum=1000000000M, Width=92, Enabled=false };
            var render=new Button { Text="Update result", AutoSize=true };
            var capture=new Button { Text="Capture evidence PNG", AutoSize=true };
            _status=new Label { AutoSize=true, Padding=new Padding(10,7,0,0), ForeColor=Color.FromArgb(45,55,72) };
            top.Controls.Add(new Label {Text="Result",AutoSize=true,Padding=new Padding(0,7,0,0)}); top.Controls.Add(_field);
            top.Controls.Add(new Label {Text="Unidades",AutoSize=true,Padding=new Padding(8,7,0,0)}); top.Controls.Add(_displayUnit);
            top.Controls.Add(new Label {Text="Formato",AutoSize=true,Padding=new Padding(8,7,0,0)}); top.Controls.Add(_numberFormat);
            top.Controls.Add(new Label {Text="Bandas",AutoSize=true,Padding=new Padding(8,7,0,0)}); top.Controls.Add(_legendBands);
            top.Controls.Add(new Label {Text="Deformación x",AutoSize=true,Padding=new Padding(12,7,0,0)}); top.Controls.Add(_scale);
            top.Controls.Add(_showDeformed); top.Controls.Add(_showContours); top.Controls.Add(_showEdges); top.Controls.Add(_autoRange);
            top.Controls.Add(new Label {Text="Min",AutoSize=true,Padding=new Padding(8,7,0,0)}); top.Controls.Add(_rangeMin);
            top.Controls.Add(new Label {Text="Max",AutoSize=true,Padding=new Padding(4,7,0,0)}); top.Controls.Add(_rangeMax);
            top.Controls.Add(render); top.Controls.Add(capture); top.Controls.Add(_status);

            var right=new Panel { Dock=DockStyle.Right, Width=270, Padding=new Padding(14), BackColor=Color.White };
            var title=new Label { Text="RESULT DETAILS", Dock=DockStyle.Top, Height=30, Font=new Font("Segoe UI Semibold",10F), ForeColor=Color.FromArgb(22,42,70) };
            var fieldTitle=new Label { Text="Code_Aster field", Dock=DockStyle.Top, Height=28, Font=new Font("Segoe UI",9F,FontStyle.Bold) };
            _legend=new AsterMaxLegendPanel { Dock=DockStyle.Top, Height=260, Margin=new Padding(0,6,0,10) };
            _maxLabel=new Label { Dock=DockStyle.Top, Height=42, Font=new Font("Consolas",9F), AutoEllipsis=true };
            _minLabel=new Label { Dock=DockStyle.Top, Height=42, Font=new Font("Consolas",9F), AutoEllipsis=true };
            var probeTitle=new Label { Text="Nodal probe", Dock=DockStyle.Top, Height=26, Font=new Font("Segoe UI",9F,FontStyle.Bold) };
            _probeNode=new NumericUpDown { Dock=DockStyle.Top, Minimum=1, Maximum=Math.Max(1,bundle.NodeCount), Value=Math.Max(1,bundle.NodeCount) };
            _probeLabel=new Label { Dock=DockStyle.Top, Height=52, Font=new Font("Consolas",9F), Padding=new Padding(0,8,0,0) };
            _integrityLabel=new Label { Dock=DockStyle.Bottom, Height=58, Text="SOURCE: "+bundle.SourceKind+"\r\nSHA256: "+bundle.BundleSha256.Substring(0,12)+"…", ForeColor=Color.FromArgb(34,105,65), Font=new Font("Segoe UI",8.5F,FontStyle.Bold) };
            right.Controls.Add(_integrityLabel); right.Controls.Add(_probeLabel); right.Controls.Add(_probeNode); right.Controls.Add(probeTitle); right.Controls.Add(_minLabel); right.Controls.Add(_maxLabel); right.Controls.Add(_legend); right.Controls.Add(fieldTitle); right.Controls.Add(title);

            _host=new Panel { Dock=DockStyle.Fill, BackColor=Color.FromArgb(232,236,241) };
            Controls.Add(_host); Controls.Add(right); Controls.Add(top);
            render.Click+=delegate { RenderScene(); };
            capture.Click+=delegate { using(var dlg=new SaveFileDialog { Filter="PNG image (*.png)|*.png", FileName="AsterMax-C9.68-results-evidence.png" }) if(dlg.ShowDialog(this)==DialogResult.OK) CaptureEvidencePng(dlg.FileName); };
            _field.SelectedIndexChanged+=delegate { UpdateAsterMaxDisplayUnits(); RenderScene(); ResultFieldChanged?.Invoke(SelectedResultField); };
            _displayUnit.SelectedIndexChanged+=delegate { RenderScene(); };
            _numberFormat.SelectedIndexChanged+=delegate { RenderScene(); };
            _legendBands.ValueChanged+=delegate { RenderScene(); };
            _scale.ValueChanged+=delegate { RenderScene(); };
            _probeNode.ValueChanged+=delegate { RefreshMetadata(); };
            _showDeformed.CheckedChanged+=delegate { _scale.Enabled=_showDeformed.Checked; RenderScene(); };
            _showContours.CheckedChanged+=delegate { RenderScene(); };
            _showEdges.CheckedChanged+=delegate { RenderScene(); };
            _autoRange.CheckedChanged+=delegate {
                _rangeMin.Enabled=!_autoRange.Checked; _rangeMax.Enabled=!_autoRange.Checked;
                RenderScene();
            };
            _rangeMin.ValueChanged+=delegate { if(!_autoRange.Checked) RenderScene(); };
            _rangeMax.ValueChanged+=delegate { if(!_autoRange.Checked) RenderScene(); };
            // First render is explicit in ShowAsterMaxIntegratedResult -> SelectResultField.
            RefreshMetadata();
        }

        private static void SetNumericResultValue(NumericUpDown control,double value)
        {
            if(control==null || Double.IsNaN(value) || Double.IsInfinity(value)) return;
            decimal v;
            try { v=(decimal)value; } catch { v=value<0 ? control.Minimum : control.Maximum; }
            if(v<control.Minimum) v=control.Minimum;
            if(v>control.Maximum) v=control.Maximum;
            control.Value=v;
        }

        private vtkControl.vtkMaxColorSpectrum CreateDisplaySpectrum(AsterMaxResultsColorContract contract)
        {
            if(contract==null) throw new ArgumentNullException("contract");
            if(_autoRange.Checked)
            {
                var autoSpectrum=contract.CreateVtkSpectrum();
                autoSpectrum.NumberOfColors=(int)_legendBands.Value;
                return autoSpectrum;
            }
            double lo=(double)_rangeMin.Value, hi=(double)_rangeMax.Value;
            if(!(hi>lo)) throw new InvalidOperationException("Manual contour range requires Max > Min.");
            var spectrum=new vtkControl.vtkMaxColorSpectrum();
            spectrum.Type=vtkControl.vtkColorSpectrumType.Rainbow;
            spectrum.MinMaxType=vtkControl.vtkColorSpectrumMinMaxType.Manual;
            spectrum.NumberOfColors=(int)_legendBands.Value;
            if(hi<=0){spectrum.MinUserValue=lo;spectrum.MaxUserValue=hi;}
            else{spectrum.MaxUserValue=hi;spectrum.MinUserValue=lo;}
            return spectrum;
        }
        private void UpdateAsterMaxDisplayUnits()
        {
            if (_displayUnit == null || _field == null || _field.SelectedItem == null) return;
            string previous = _displayUnit.SelectedItem as string;
            string source = String.Equals((string)_field.SelectedItem, "Equivalent Stress", StringComparison.Ordinal)
                ? _bundle.StressUnit : _bundle.LengthUnit;
            string[] items;
            if (AsterMaxIsStressUnit(source)) items = new[]{"Pa","kPa","MPa","GPa"};
            else items = new[]{"µm","mm","cm","m"};
            _displayUnit.BeginUpdate();
            try
            {
                _displayUnit.Items.Clear();
                _displayUnit.Items.AddRange(items);
                int index = Array.IndexOf(items, previous);
                if (index < 0) index = Array.IndexOf(items, source);
                _displayUnit.SelectedIndex = index >= 0 ? index : 0;
            }
            finally { _displayUnit.EndUpdate(); }
        }

        private static bool AsterMaxIsStressUnit(string unit)
        {
            return unit=="Pa" || unit=="kPa" || unit=="MPa" || unit=="GPa";
        }

        private static double AsterMaxUnitToSi(string unit)
        {
            switch (unit)
            {
                case "Pa": return 1.0;
                case "kPa": return 1e3;
                case "MPa": return 1e6;
                case "GPa": return 1e9;
                case "µm": case "um": return 1e-6;
                case "mm": return 1e-3;
                case "cm": return 1e-2;
                case "m": return 1.0;
                default: throw new NotSupportedException("Unidad de resultados no soportada: " + unit);
            }
        }

        private static double AsterMaxDisplayFactor(string source, string target)
        {
            bool sourceStress=AsterMaxIsStressUnit(source), targetStress=AsterMaxIsStressUnit(target);
            if(sourceStress != targetStress) throw new InvalidOperationException("Conversión incompatible: "+source+" → "+target);
            return AsterMaxUnitToSi(source) / AsterMaxUnitToSi(target);
        }

        private string AsterMaxScalarBarFormat()
        {
            string mode = _numberFormat == null ? "Auto" : _numberFormat.SelectedItem as string;
            if (mode == "Decimal") return "F3";
            if (mode == "Científico") return "E3";
            return "G4";
        }
        private void RefreshMetadata()
        {
            if(_field.SelectedItem==null) return;
            double deformationScale=_showDeformed.Checked ? (double)_scale.Value : 0.0;
            var rawScene=AsterMaxResultsScene.Build(_bundle,(string)_field.SelectedItem,deformationScale);
            string displayUnit=_displayUnit.SelectedItem as string;
            if(String.IsNullOrEmpty(displayUnit)) displayUnit=rawScene.Unit;
            _displayScalarFactor=AsterMaxDisplayFactor(rawScene.Unit,displayUnit);
            _scene=rawScene.ConvertScalarDisplay(_displayScalarFactor,displayUnit);
            if(_autoRange.Checked)
            {
                SetNumericResultValue(_rangeMin,_scene.Minimum);
                SetNumericResultValue(_rangeMax,_scene.Maximum);
            }
            var displayContract=AsterMaxResultsColorContract.FromScene(_scene);
            _legend.SetDisplayRange(_autoRange.Checked ? _scene.Minimum : (double)_rangeMin.Value,
                                    _autoRange.Checked ? _scene.Maximum : (double)_rangeMax.Value,
                                    _scene.Unit,_scene.Field);
            _maxLabel.Text=String.Format(System.Globalization.CultureInfo.InvariantCulture,"MAX  {0:G9} {1}\r\nNode {2}",_scene.Maximum,_scene.Unit,_scene.MaximumNodeIndex+1);
            _minLabel.Text=String.Format(System.Globalization.CultureInfo.InvariantCulture,"MIN  {0:G9} {1}\r\nNode {2}",_scene.Minimum,_scene.Unit,_scene.MinimumNodeIndex+1);
            int node=(int)_probeNode.Value-1;
            double value=_bundle.ProbeNode(node,_scene.Field) * _displayScalarFactor;
            var xyz=_bundle.Coordinates[node];
            _probeLabel.Text=String.Format(System.Globalization.CultureInfo.InvariantCulture,"N{0}: {1:G9} {2}\r\n({3:G6}, {4:G6}, {5:G6}) mm",node+1,value,_scene.Unit,xyz[0],xyz[1],xyz[2]);
            _status.Text=_scene.Field+" ["+_scene.Unit+"] • "+_bundle.NodeCount+" nodes / "+_bundle.ElementCount+" "+_bundle.ElementType+" • verified provenance";
        }

        private void RenderScene()
        {
            string renderStage="preflight";
            if(_axRendering) {
                // The active render owns completion status; nested UI events must not overwrite it.
                return;
            }
            if(!IsHandleCreated || !Visible) {
                LastRenderError=null;
                LastRenderSkipped=true;
                LastRenderSkipReason=!IsHandleCreated?"window handle is not created":"viewport is not visible";
                return;
            }
            _axRendering=true;
            LastRenderError=null;
            LastRenderSkipped=false;
            LastRenderSkipReason=null;
            try
            {
                renderStage="validate-model";
                ValidateModel?.Invoke();
                renderStage="refresh-metadata";
                RefreshMetadata();
                renderStage="build-actor-data";
                var data=AsterMaxVtkResultsBinding.BuildActorData(_bundle,_scene);
                data.ColorContours=_showContours.Checked;
                bool firstRender=_view==null;
                if(firstRender) {
                    renderStage="vtk-create";
                    bool vtkLoadCompleted=false;
                    _view=new vtkControl.vtkControl { Dock=DockStyle.Fill };
                    _view.Load+=delegate { vtkLoadCompleted=true; };
                    _host.Controls.Add(_view);
                    renderStage="vtk-load";
                    _view.Show();
                    _view.CreateControl();
                    Application.DoEvents();
                    if(!_view.IsHandleCreated || !vtkLoadCompleted)
                        throw new InvalidOperationException("vtkControl did not complete its WinForms Load lifecycle before renderer access.");
                } else {
                    renderStage="vtk-clear";
                    _view.OnMouseLeftButtonUpSelection-=OnNativeVtkSelection;
                    _view.Clear();
                }
                var colorContract=AsterMaxResultsColorContract.FromScene(_scene);
                renderStage="scalar-spectrum";
                _view.SetScalarBarColorSpectrum(CreateDisplaySpectrum(colorContract));
                renderStage="scalar-bar-text";
                _view.SetScalarBarNumberFormat(AsterMaxScalarBarFormat());
                _view.SetScalarBarText(colorContract.Field,"",colorContract.Unit,"","");
                renderStage="annotation-bind";
                _view.Controller_GetAnnotationText=NativeProbeAnnotation;
                // vtkMaxActor poly rendering receives only exterior TRI/QUADRATIC_TRI/QUAD faces.
                renderStage="add-cells";
                _view.AddCells(data);
                renderStage="edge-visibility";
                _view.EdgesVisibility=_showEdges.Checked ? vtkControl.vtkEdgesVisibility.ElementEdges : vtkControl.vtkEdgesVisibility.NoEdges;
                // Critical C10.13 fix: AddCells creates the actor after the spectrum was configured.
                // Re-run scalar formatting now so the actor mapper receives the real nodal scalar LUT/range.
                renderStage="scalar-format-redraw";
                _view.UpdateScalarsAndCameraAndRedraw();
                renderStage="selection-mode";
                _view.SetSelectBy(CaeGlobals.vtkSelectBy.Node);
                renderStage="selection-event";
                _view.OnMouseLeftButtonUpSelection+=OnNativeVtkSelection;
                renderStage="camera-fit";
                if(firstRender) _view.AdjustCameraDistanceAndClipping();
                renderStage="complete";
                LastRenderError=null; LastRenderSkipped=false; LastRenderSkipReason=null;
                RenderRevision++;
                _status.Text=_scene.Field+" ["+_scene.Unit+"] • "+_bundle.NodeCount+" nodes / "+_bundle.ElementCount+" volume elements • scalar contours "+(_showContours.Checked?"BOUND":"OFF")+" • edges "+(_showEdges.Checked?"ON":"OFF")+" • deformed "+(_showDeformed.Checked?"ON":"OFF");
            }
            catch(Exception ex)
            {
                if(_view!=null)
                {
                    try{_view.OnMouseLeftButtonUpSelection-=OnNativeVtkSelection;}catch{}
                    _host.Controls.Remove(_view); _view.Dispose(); _view=null;
                }
                LastRenderError="stage="+renderStage+"; "+ex.ToString();
                LastRenderSkipped=false;
                LastRenderSkipReason=null;
                try { System.IO.File.WriteAllText(System.IO.Path.Combine(System.IO.Path.GetTempPath(),"AsterMax-render-error.log"),LastRenderError); } catch {}
                _status.Text="Render blocked @ "+renderStage+": "+ex.GetType().Name;
                if(AuditMode) throw;
                MessageBox.Show(this,"AsterMax results renderer blocked safely.\n\nStage: "+renderStage+"\n"+ex.GetType().Name+": "+ex.Message,
                    "AsterMax Results",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally { _axRendering=false; }
        }

        private string NativeProbeAnnotation(string globalPointId)
        {
            if(_scene==null) return "No active FEA result";
            if(_scene.FeaValuesInvented) throw new InvalidOperationException("Synthetic FEA scene rejected by native callout.");
            int oneBased;
            if(!Int32.TryParse(globalPointId,System.Globalization.NumberStyles.Integer,System.Globalization.CultureInfo.InvariantCulture,out oneBased))
                throw new InvalidOperationException("VTK probe did not provide a numeric node id.");
            int i=oneBased-1;
            if(i<0 || i>=_bundle.NodeCount) throw new InvalidOperationException("VTK probe node id is outside the results bundle.");
            double value=_bundle.ProbeNode(i,_scene.Field);
            var xyz=_bundle.Coordinates[i];
            return String.Format(System.Globalization.CultureInfo.InvariantCulture,
                "N{0}  {1}: {2:G9} {3}\nX {4:G6}  Y {5:G6}  Z {6:G6} mm",
                oneBased,_scene.Field,value,_scene.Unit,xyz[0],xyz[1],xyz[2]);
        }

        // Deterministic harness surface: verifies the exact text consumed by vtkControl's own
        // probe widget without pretending that CI injected a physical mouse click.
        public string NativeProbeAnnotationSummary(int oneBasedNodeId)
        {
            RefreshMetadata();
            return NativeProbeAnnotation(oneBasedNodeId.ToString(System.Globalization.CultureInfo.InvariantCulture));
        }

        public bool NativeProbeAnnotationRejectsInvalidNode()
        {
            RefreshMetadata();
            try { NativeProbeAnnotation((_bundle.NodeCount+1).ToString(System.Globalization.CultureInfo.InvariantCulture)); return false; }
            catch(InvalidOperationException) { return true; }
        }
        private void OnNativeVtkSelection(double[] pickedPoint, double[] direction, double[][] plane, CaeGlobals.vtkSelectOperation operation, string[] actorNames)
        {
            if(pickedPoint==null || _scene==null) return;
            try
            {
                var probe=AsterMaxNativeProbeResult.FromRendererPoint(_bundle,_scene,pickedPoint);
                _probeNode.Value=Math.Max(_probeNode.Minimum,Math.Min(_probeNode.Maximum,probe.NodeIndex+1));
                var xyz=_bundle.Coordinates[probe.NodeIndex];
                _probeLabel.Text=String.Format(System.Globalization.CultureInfo.InvariantCulture,
                    "VTK PICK N{0}: {1:G9} {2}\r\n({3:G6}, {4:G6}, {5:G6}) mm",
                    probe.NodeIndex+1,probe.Value,probe.Unit,xyz[0],xyz[1],xyz[2]);
                _status.Text=_scene.Field+" ["+_scene.Unit+"] • VTK node probe N"+(probe.NodeIndex+1);
            }
            catch(InvalidOperationException ex)
            {
                _status.Text="Probe rejected: "+ex.Message;
            }
        }

        public string NativeProbeContractSummary(int zeroBasedNodeIndex)
        {
            RefreshMetadata();
            if(zeroBasedNodeIndex<0 || zeroBasedNodeIndex>=_bundle.NodeCount) throw new ArgumentOutOfRangeException("zeroBasedNodeIndex");
            var q=_scene.DeformedCoordinates[zeroBasedNodeIndex];
            return AsterMaxNativeProbeResult.FromRendererPoint(_bundle,_scene,new[]{q[0],q[1],q[2]}).Describe();
        }

        public bool NativeProbeRejectsNonNodePoint()
        {
            RefreshMetadata();
            var q=_scene.DeformedCoordinates[0];
            try
            {
                AsterMaxNativeProbeResult.FromRendererPoint(_bundle,_scene,new[]{q[0]+0.123456789,q[1]+0.234567891,q[2]+0.345678912});
                return false;
            }
            catch(InvalidOperationException){return true;}
        }
        public void CaptureNativeFramebuffer(string fileName)
        {
            if(_scene==null) RefreshMetadata();
            if(_scene.FeaValuesInvented) throw new InvalidOperationException("Synthetic FEA scene rejected by framebuffer evidence capture.");
            if(_view==null) throw new InvalidOperationException("VTK results viewport is not initialized.");
            _view.SaveNativeFramebufferPng(fileName);
        }

        public string NativeFramebufferEvidenceContract()
        {
            RefreshMetadata();
            return String.Format(System.Globalization.CultureInfo.InvariantCulture,
                "source=vtkRenderWindow|field={0}|unit={1}|min={2:R}|max={3:R}|invented=false",
                _scene.Field,_scene.Unit,_scene.Minimum,_scene.Maximum);
        }
        public string RendererContractSummary()
        {
            RefreshMetadata();
            return AsterMaxResultsColorContract.FromScene(_scene).Describe();
        }

        public string EvidenceSummary()
        {
            RefreshMetadata();
            return String.Format(System.Globalization.CultureInfo.InvariantCulture,
                "{0}|{1}|min={2:R}|minNode={3}|max={4:R}|maxNode={5}|probeNode={6}|probe={7:R}|invented=false",
                _scene.Field,_scene.Unit,_scene.Minimum,_scene.MinimumNodeIndex+1,_scene.Maximum,_scene.MaximumNodeIndex+1,(int)_probeNode.Value,
                _bundle.ProbeNode((int)_probeNode.Value-1,_scene.Field)*_displayScalarFactor);
        }

        public void CaptureEvidencePng(string path)
        {
            if(String.IsNullOrWhiteSpace(path)) throw new ArgumentException("Evidence path is required.","path");
            RefreshMetadata();
            using(var bmp=new Bitmap(Math.Max(1,Width),Math.Max(1,Height)))
            {
                DrawToBitmap(bmp,new Rectangle(0,0,bmp.Width,bmp.Height));
                bmp.Save(path,System.Drawing.Imaging.ImageFormat.Png);
            }
        }

        private static string AsterMaxFormatLegendValue(double value)
        {
            double a=Math.Abs(value);
            if(a==0) return "0";
            if(a>=0.001 && a<1000000) return value.ToString("0.###",System.Globalization.CultureInfo.InvariantCulture);
            return value.ToString("0.###E+00",System.Globalization.CultureInfo.InvariantCulture);
        }
        private sealed class AsterMaxLegendPanel : Control
        {
            private double _min,_max; private string _unit="",_field="";
            public AsterMaxLegendPanel(){DoubleBuffered=true;BackColor=Color.White;}
            public void SetContract(AsterMaxResultsColorContract c)
            {
                if(c==null || c.FeaValuesInvented) throw new InvalidOperationException("Invalid renderer color contract.");
                SetDisplayRange(c.Minimum,c.Maximum,c.Unit,c.Field);
            }
            public void SetDisplayRange(double min,double max,string unit,string field)
            {
                _min=min; _max=max; _unit=unit??""; _field=field??""; Invalidate();
            }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e); var g=e.Graphics; g.Clear(Color.White);
                using(var f=new Font("Segoe UI Semibold",9F)) g.DrawString(_field+" ["+_unit+"]",f,Brushes.Black,2,2);
                int x=18,y=30,w=42,h=Math.Max(80,Height-52);
                Color[] c={Color.FromArgb(180,0,0),Color.OrangeRed,Color.Gold,Color.LimeGreen,Color.Cyan,Color.RoyalBlue};
                for(int i=0;i<h;i++)
                {
                    double t=(double)i/Math.Max(1,h-1);
                    int seg=Math.Min(c.Length-2,(int)(t*(c.Length-1)));
                    double u=t*(c.Length-1)-seg; Color a=c[seg],b=c[seg+1];
                    Color q=Color.FromArgb((int)(a.R+(b.R-a.R)*u),(int)(a.G+(b.G-a.G)*u),(int)(a.B+(b.B-a.B)*u));
                    using(var pen=new Pen(q)) g.DrawLine(pen,x,y+i,x+w,y+i);
                }
                using(var p=new Pen(Color.DimGray))g.DrawRectangle(p,x,y,w,h);
                using(var f=new Font("Consolas",8.5F))
                {
                    for(int k=0;k<=5;k++){double t=(double)k/5;double v=_max-( _max-_min)*t;int yy=y+(int)(h*t);g.DrawString(AsterMaxFormatLegendValue(v),f,Brushes.Black,x+w+8,yy-7);}
                }
            }
        }
    }
    public partial class FrmMain
    {
        private void OpenAsterMaxResultsViewport()
        {
            try
            {
                if (_asterMaxLoadedResults == null)
                {
                    using(var dlg=new OpenFileDialog())
                    {
                        dlg.Title="Load real Code_Aster results bundle";
                        dlg.Filter="AsterMax Results Bundle (*.json)|*.json|All files (*.*)|*.*";
                        if(dlg.ShowDialog(this)!=DialogResult.OK) return;
                        _asterMaxLoadedResults=AsterMaxResultsBundle.Load(dlg.FileName);
                    }
                }
                ShowAsterMaxIntegratedResult(null);
            }
            catch(Exception ex)
            {
                CaeGlobals.MessageBoxes.ShowError("AsterMax VTK results binding rejected: "+ex.Message);
            }
        }
    }
}













