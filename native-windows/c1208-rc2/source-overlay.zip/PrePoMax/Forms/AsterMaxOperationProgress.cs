using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace PrePoMax
{
    // UI-thread owned, modeless: background operations keep the message loop alive.
    internal sealed class AsterMaxOperationProgress : Form
    {
        private readonly Label stage = new Label();
        private readonly Label elapsed = new Label();
        private readonly Button cancel = new Button();
        private readonly Button consoleToggle = new Button();
        private readonly TextBox consoleOutput = new TextBox();
        private bool consoleEnabled, consoleExpanded;
        private const int ConsoleLimit = 65536;
        private readonly Timer timer = new Timer { Interval = 250 };
        private readonly Stopwatch watch = Stopwatch.StartNew();
        private Action cancelAction;
        private bool finished, cancellationRequested;
        private bool resourcesReleased;
        internal string CancellationError { get; private set; }

        internal AsterMaxOperationProgress(string title)
        {
            Text = title;
            ClientSize = new Size(500, 190);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MaximizeBox = false; MinimizeBox = false; ControlBox = false;
            ShowInTaskbar = false;
            Font = new Font("Segoe UI", 10);
            stage.SetBounds(22, 20, 456, 48);
            var bar = new ProgressBar { Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 30 };
            bar.SetBounds(22, 78, 456, 22);
            elapsed.SetBounds(22, 119, 290, 48);
            cancel.Text = "Cancelar cálculo";
            cancel.SetBounds(320, 125, 158, 34);
            cancel.Enabled = false; cancel.Visible = false;
            stage.AutoEllipsis = true;
            stage.AccessibleName = "Etapa de la operación";
            elapsed.AccessibleName = "Tiempo transcurrido";
            cancel.AccessibleDescription = "Solicita cancelar el cálculo; espera a que el backend confirme su finalización.";
            cancel.Click += OnCancelClick;
            Controls.AddRange(new Control[] { stage, bar, elapsed, cancel });
            consoleToggle.Text = "▸ Consola del solver";
            consoleToggle.SetBounds(22, 180, 456, 32);
            consoleToggle.Visible = false;
            consoleToggle.AccessibleName = "Mostrar u ocultar la consola del solver";
            consoleToggle.Click += OnConsoleToggle;
            consoleOutput.Multiline = true;
            consoleOutput.ReadOnly = true;
            consoleOutput.ScrollBars = ScrollBars.Both;
            consoleOutput.WordWrap = false;
            consoleOutput.Font = new Font("Consolas", 9);
            consoleOutput.AccessibleName = "Salida en vivo del solver. Los logs completos se conservan en disco.";
            consoleOutput.SetBounds(22, 222, 456, 220);
            consoleOutput.Visible = false;
            Controls.AddRange(new Control[] { consoleToggle, consoleOutput });
            timer.Tick += OnElapsedTick;
            OnElapsedTick(this, EventArgs.Empty);
            timer.Start();
            FormClosing += OnProgressClosing;
        }
        internal void EnableConsole()
        {
            if (finished || resourcesReleased) return;
            consoleEnabled = true;
            consoleToggle.Visible = true;
            ClientSize = new Size(500, 230);
        }
        private void OnConsoleToggle(object sender, EventArgs e)
        {
            if (!consoleEnabled || finished || resourcesReleased) return;
            consoleExpanded = !consoleExpanded;
            consoleOutput.Visible = consoleExpanded;
            consoleToggle.Text = consoleExpanded ? "▾ Ocultar consola del solver" : "▸ Consola del solver";
            ClientSize = new Size(500, consoleExpanded ? 465 : 230);
            if (Owner != null)
            {
                var screen = Screen.FromControl(Owner).WorkingArea;
                Location = new Point(Math.Max(screen.Left, Math.Min(screen.Right - Width, Owner.Left + (Owner.Width - Width) / 2)),
                    Math.Max(screen.Top, Math.Min(screen.Bottom - Height, Owner.Top + (Owner.Height - Height) / 2)));
            }
        }
        internal void AppendConsole(string text)
        {
            if (finished || resourcesReleased || string.IsNullOrEmpty(text)) return;
            if (text.Length > ConsoleLimit) text = text.Substring(text.Length - ConsoleLimit);
            int excess = consoleOutput.TextLength + text.Length - ConsoleLimit;
            if (excess > 0)
            {
                consoleOutput.Select(0, Math.Min(excess, consoleOutput.TextLength));
                consoleOutput.SelectedText = "";
            }
            consoleOutput.AppendText(text);
        }
        private void OnElapsedTick(object sender, EventArgs e)
        {
            elapsed.Text = "Tiempo transcurrido: " +
                ((int)watch.Elapsed.TotalHours).ToString("00") + ":" + watch.Elapsed.Minutes.ToString("00") + ":" + watch.Elapsed.Seconds.ToString("00");
        }
        private void OnProgressClosing(object sender, FormClosingEventArgs e)
        {
            if (!finished) e.Cancel = true;
        }
        private void OnCancelClick(object sender, EventArgs e)
        {
            if (cancellationRequested || cancelAction == null) return;
            cancellationRequested = true;
            cancel.Enabled = false;
            stage.Text = "Cancelando; esperando la finalización del proceso…";
            try { cancelAction(); }
            catch (Exception ex)
            {
                // A failed request is not proof that the worker stopped. Keep the
                // operation window/lock until its normal finally acknowledges exit.
                CancellationError = ex.ToString();
                stage.Text = "No se pudo confirmar la cancelación. Esperando al proceso…";
                stage.AccessibleDescription = CancellationError;
                EnableConsole();
                AppendConsole("[Error al solicitar cancelación] " + CancellationError + Environment.NewLine);
                if (!consoleExpanded) OnConsoleToggle(this, EventArgs.Empty);
            }
        }
        internal void UpdateStage(string text, Action cancellation = null)
        {
            if (finished || resourcesReleased) return;
            if (!cancellationRequested) stage.Text = text;
            cancelAction = cancellation;
            cancel.Visible = cancellation != null;
            cancel.Enabled = cancellation != null && !cancellationRequested;
        }
        internal void Finish()
        {
            if (finished) return;
            finished = true;
            timer.Stop();
            try { Close(); }
            finally { Dispose(); }
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && !resourcesReleased)
            {
                resourcesReleased = true;
                timer.Stop();
                timer.Tick -= OnElapsedTick;
                timer.Dispose();
                watch.Stop();
                cancel.Click -= OnCancelClick;
                consoleToggle.Click -= OnConsoleToggle;
                FormClosing -= OnProgressClosing;
                cancelAction = null;
            }
            base.Dispose(disposing);
        }
    }

    public partial class FrmMain
    {
        private AsterMaxOperationProgress _asterMaxProgress;
        private Control _asterMaxProgressRibbon;
        private bool _asterMaxProgressRibbonEnabled;
        private bool _asterMaxProgressOwnerEnabled;
        private void BeginAsterMaxProgress(string title, string stage)
        {
            if (_asterMaxProgress != null) throw new InvalidOperationException("Ya hay una operación en curso.");
            _asterMaxProgressOwnerEnabled = Enabled;
            _asterMaxProgressRibbon = Controls["asterMaxRibbon"];
            if (_asterMaxProgressRibbon != null)
            {
                _asterMaxProgressRibbonEnabled = _asterMaxProgressRibbon.Enabled;
                _asterMaxProgressRibbon.Enabled = false;
            }
            _asterMaxProgress = new AsterMaxOperationProgress(title);
            _asterMaxProgress.UpdateStage(stage);
            _asterMaxProgress.Show(this);
            Enabled = false; // Owned window remains interactive; blocks shortcuts and competing edits.
            tspbProgress.Visible = false;
            tsslCancel.Visible = false;
        }
        private void EndAsterMaxProgress()
        {
            if (_asterMaxProgress == null) return;
            var progress = _asterMaxProgress;
            _asterMaxProgress = null;
            try { progress.Finish(); }
            finally
            {
                if (!IsDisposed && !Disposing) Enabled = _asterMaxProgressOwnerEnabled;
                if (_asterMaxProgressRibbon != null && !_asterMaxProgressRibbon.IsDisposed)
                    _asterMaxProgressRibbon.Enabled = _asterMaxProgressRibbonEnabled;
                _asterMaxProgressRibbon = null;
            }
        }
        private static string AsterMaxSolveStage(AsterMaxSolveState state)
        {
            switch(state)
            {
                case AsterMaxSolveState.Running: return "Resolviendo con Code_Aster…";
                case AsterMaxSolveState.Postprocessing: return "Procesando y verificando los resultados…";
                case AsterMaxSolveState.Cancelling: return "Cancelando; esperando la finalización del proceso…";
                case AsterMaxSolveState.Cancelled: return "Cálculo cancelado.";
                case AsterMaxSolveState.Failed: return "El cálculo ha fallado; revisando el diagnóstico…";
                default: return "Verificando la transacción y los resultados…";
            }
        }
    }
}
