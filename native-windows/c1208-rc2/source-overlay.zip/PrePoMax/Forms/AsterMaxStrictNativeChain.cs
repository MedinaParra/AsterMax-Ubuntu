using System;using System.IO;using System.Linq;using System.Text;using System.Globalization;using System.Security.Cryptography;using System.Threading.Tasks;
using CaeGlobals;using CaeMesh;using CaeModel;using Newtonsoft.Json.Linq;
namespace PrePoMax {
 public static class AsterMaxStrictNativeFixture {
  public static string MeshHash(FeModel m){var s=new StringBuilder();foreach(var n in m.Mesh.Nodes.Values.OrderBy(x=>x.Id))s.AppendFormat(CultureInfo.InvariantCulture,"N {0} {1:R} {2:R} {3:R}\n",n.Id,n.X,n.Y,n.Z);foreach(var e in m.Mesh.Elements.Values.OrderBy(x=>x.Id))s.Append(e.Id).Append(':').Append(e.GetType().FullName).Append(':').Append(String.Join(",",e.NodeIds)).Append('\n');using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(s.ToString()))).Replace("-","").ToLowerInvariant();}
  // Explicit audit fixture only. Never called by normal solve or user model repair.
  public static JObject Configure(FeModel m){
   if(m==null||m.Mesh==null||m.Mesh.Nodes.Count==0||m.Mesh.Elements.Count==0||m.Mesh.Parts.Count!=1)throw new InvalidOperationException("Strict B01 requires one actual meshed body.");
   if(m.Constraints.Count!=0||m.ContactPairs.Count!=0)throw new InvalidOperationException("Strict B01 rejects existing connections.");
   if(m.Mesh.Elements.Values.Any(x=>!(x is LinearTetraElement)))throw new InvalidOperationException("Strict B01 requires native TETRA4 mesh; no replacement is allowed.");
   var ns=m.Mesh.Nodes.Values.ToArray();double[] lo={ns.Min(x=>x.X),ns.Min(x=>x.Y),ns.Min(x=>x.Z)},hi={ns.Max(x=>x.X),ns.Max(x=>x.Y),ns.Max(x=>x.Z)};
   for(int i=0;i<3;i++)if(Math.Abs(lo[i])>1e-6||Math.Abs(hi[i]-(i==0?100:10))>1e-6)throw new InvalidOperationException("Only explicit B01 0..100 x 0..10 x 0..10 mm is accepted.");
   string before=MeshHash(m);int[] fix=ns.Where(x=>Math.Abs(x.X)<1e-6).Select(x=>x.Id).ToArray(),load=ns.Where(x=>Math.Abs(x.X-100)<1e-6).Select(x=>x.Id).ToArray();if(fix.Length<3||load.Length<3)throw new InvalidOperationException("B01 end faces not resolved.");
   m.UnitSystem=new UnitSystem(UnitSystemType.MM_TON_S_C);m.Materials.Clear();var mat=new Material("B01_Steel");mat.AddProperty(new ElasticWithDensity(210000,.3,7.85e-9));m.Materials.Add(mat.Name,mat);
   m.Mesh.ElementSets["B01_ALL"]=new FeElementSet("B01_ALL",m.Mesh.Elements.Keys.ToArray());m.Sections.Clear();m.Sections.Add("B01_Section",new SolidSection("B01_Section",mat.Name,"B01_ALL",RegionTypeEnum.ElementSetName,1,false));
   m.Mesh.NodeSets["FIXED"]=new FeNodeSet("FIXED",fix);m.Mesh.NodeSets["LOAD"]=new FeNodeSet("LOAD",load);
   m.StepCollection.StepsList.Clear();var step=new StaticStep("B01_Static");step.AddBoundaryCondition(new FixedBC("Fixed","FIXED",RegionTypeEnum.NodeSetName,false));step.AddLoad(new CLoad("Explicit_total_10000N","LOAD",RegionTypeEnum.NodeSetName,10000.0/load.Length,0,0,false,false,0));m.StepCollection.AddStep(step,false);
   if(MeshHash(m)!=before)throw new InvalidOperationException("Native mesh changed while setting fixture BCs.");
   return new JObject{{"mesh_sha256",before},{"nodes",ns.Length},{"elements",m.Mesh.Elements.Count},{"fixed_nodes",fix.Length},{"loaded_nodes",load.Length},{"force_total_x_n",10000},{"force_per_node_x_n",10000.0/load.Length},{"distribution","uniform per selected endpoint node, not uniform traction"},{"mesh_replaced",false}};
  }
 }
 public partial class FrmMain {
  private static bool StrictNativeChain {get{return Environment.GetCommandLineArgs().Any(x=>x=="--astermax-strict-native-chain");}}
  private async Task ExecuteStrictNativeChain(string directory,FeModel model,JObject meshDiagnostic){
   var report=new JObject{{"status","RUNNING"},{"windows_native",Environment.OSVersion.Platform==PlatformID.Win32NT},{"mesh_diagnostic",meshDiagnostic},{"solver_status","NOT_RUN"}};
   string path=Path.Combine(directory,"strict-native-chain.json");
   try{
    if(Environment.OSVersion.Platform!=PlatformID.Win32NT)throw new InvalidOperationException("Strict full chain requires Windows; Linux/Mono is not equivalent.");
    if((bool?)meshDiagnostic["pass"]!=true)throw new InvalidOperationException("Native NetGen generation/import failed; refusing replacement mesh.");
    report["fixture"]=AsterMaxStrictNativeFixture.Configure(model);string hash=AsterMaxStrictNativeFixture.MeshHash(model);
    File.WriteAllText(path,report.ToString());RunAsterMaxNativeSolve();
    while(_asterMaxSolveInProgress)await Task.Delay(100);
    if(_asterMaxSolveLastError!=null)throw new InvalidOperationException("Native solver/postprocess failed.",_asterMaxSolveLastError);
    if(_asterMaxSolveTransaction==null||_asterMaxSolveTransaction.State!=AsterMaxSolveState.SolutionCurrent||_asterMaxLoadedResults==null)throw new InvalidOperationException("Verified results handoff not complete.");
    if(AsterMaxStrictNativeFixture.MeshHash(model)!=hash)throw new InvalidOperationException("Mesh changed during native solve.");
    report["solver_status"]="VERIFIED_HANDOFF";report["workspace"]=_asterMaxSolveTransaction.Workspace;report["mesh_sha256_after"]=hash;report["status"]="PASS";
   }catch(Exception ex){report["status"]="FAIL";report["diagnostic"]=ex.ToString();throw;}
   finally{File.WriteAllText(path,report.ToString());}
  }
 }
}
