using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;

namespace PrePoMax
{
    internal sealed class AsterMaxResultsBundle
    {
        public string SourceFile { get; private set; }
        public int NodeCount { get; private set; }
        public int ElementCount { get; private set; }
        public double[][] Coordinates { get; private set; }
        public double[][] Displacement { get; private set; }
        public int[][] Connectivity { get; private set; }
        public int[] CellTypes { get; private set; }
        public double[] TotalDeformation { get; private set; }
        public double[] EquivalentStress { get; private set; }
        public string LengthUnit { get; private set; }
        public string StressUnit { get; private set; }
        public string ResultModelFingerprintSha256 { get; private set; }
        public string SourceKind { get; private set; }
        public string SourceName { get; private set; }
        public string ElementType { get; private set; }
        public string BundleSha256 { get; private set; }
        public bool DerivedNodalStressDeclared { get; private set; }

        public static AsterMaxResultsBundle Load(string path)
        {
            JObject root = JObject.Parse(File.ReadAllText(path));
            if ((string)root["schema"] != "astermax-results-bundle/v0")
                throw new InvalidDataException("Unsupported AsterMax results schema.");
            if ((bool?)root["integrity"]?["fea_values_invented"] != false)
                throw new InvalidDataException("Results integrity contract failed: synthetic values are not accepted.");

            var b = new AsterMaxResultsBundle();
            b.SourceFile = path;
            b.NodeCount = (int)root["mesh"]["node_count"];
            b.ElementCount = (int)root["mesh"]["element_count"];
            b.LengthUnit = (string)root["units"]["length"];
            b.StressUnit = (string)root["units"]["stress"];
            b.ResultModelFingerprintSha256 = ((string)root["integrity"]?["model_fingerprint_sha256"] ?? "").ToLowerInvariant();
            b.SourceKind = (string)root["source"]?["kind"];
            b.SourceName = (string)root["source"]?["file"];
            b.ElementType = (string)root["mesh"]?["element_type"];
            b.DerivedNodalStressDeclared = (bool?)root["integrity"]?["derived_nodal_stress_average_declared"] == true;
            using (var sha = SHA256.Create())
                b.BundleSha256 = BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(path))).Replace("-", "").ToLowerInvariant();
            b.Coordinates = ReadJagged(root["arrays"]["coordinates"], 3);
            b.Displacement = ReadJagged(root["arrays"]["displacement"], 3);
            b.Connectivity = ReadConnectivity(root["arrays"]["connectivity"]);
            b.CellTypes = root["arrays"]["cell_types"] == null ? InferCellTypes(b.Connectivity) : ReadIntVector(root["arrays"]["cell_types"]);
            b.TotalDeformation = ReadVector(root["arrays"]["total_deformation"]);
            b.EquivalentStress = ReadVector(root["arrays"]["von_mises"]);
            b.Validate();
            return b;
        }

        private static double[] ReadVector(JToken token)
        {
            return token.Select(x => (double)x).ToArray();
        }

        private static double[][] ReadJagged(JToken token, int width)
        {
            var rows = token.Select(row => row.Select(x => (double)x).ToArray()).ToArray();
            if (rows.Any(row => row.Length != width)) throw new InvalidDataException("Unexpected vector width.");
            return rows;
        }
        private static int[][] ReadConnectivity(JToken token)
        {
            if(token==null) throw new InvalidDataException("Result mesh connectivity is missing.");
            var rows=token.Select(row=>row.Select(x=>(int)x).ToArray()).ToArray();
            if(rows.Any(row=>row.Length!=4 && row.Length!=8 && row.Length!=10))
                throw new InvalidDataException("Unsupported result connectivity width; expected TETRA4, HEXA8 or TETRA10.");
            return rows;
        }
        private static int[] ReadIntVector(JToken token)
        {
            return token==null ? new int[0] : token.Select(x=>(int)x).ToArray();
        }
        private static int[] InferCellTypes(int[][] connectivity)
        {
            return connectivity.Select(c=>c.Length==4?10:(c.Length==8?12:(c.Length==10?24:-1))).ToArray();
        }

        private void Validate()
        {
            if (NodeCount <= 0 || ElementCount <= 0) throw new InvalidDataException("Empty result mesh.");
            if (Coordinates.Length != NodeCount || Displacement.Length != NodeCount ||
                TotalDeformation.Length != NodeCount || EquivalentStress.Length != NodeCount || Connectivity.Length != ElementCount ||
                CellTypes == null || CellTypes.Length != ElementCount)
                throw new InvalidDataException("Result array/node count mismatch.");
            if (SourceKind != "REAL_CODE_ASTER_MED")
                throw new InvalidDataException("C9.74 provenance gate requires source.kind=REAL_CODE_ASTER_MED.");
            if (String.IsNullOrWhiteSpace(SourceName))
                throw new InvalidDataException("C9.74 provenance gate requires the original MED source filename.");
            if (ElementType != "HEXA8" && ElementType != "TETRA4" && ElementType != "TETRA10" && ElementType != "MIXED")
                throw new InvalidDataException("C10.10.1 provenance gate supports TETRA4, TETRA10, HEXA8 and validated mixed result meshes only.");
            if (!DerivedNodalStressDeclared)
                throw new InvalidDataException("C9.74 requires explicit declaration of nodal stress averaging provenance.");
            if (String.IsNullOrWhiteSpace(BundleSha256) || BundleSha256.Length != 64)
                throw new InvalidDataException("C9.74 could not fingerprint the result bundle.");
            if (String.IsNullOrWhiteSpace(ResultModelFingerprintSha256) || ResultModelFingerprintSha256.Length != 64 ||
                ResultModelFingerprintSha256.Any(c => !((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))))
                throw new InvalidDataException("C9.98 requires results bound to an AsterMax FeModel SHA-256 fingerprint.");
            if (LengthUnit != "mm" || StressUnit != "MPa")
                throw new InvalidDataException("C9.65 PMV accepts the verified mm / N / MPa contract only.");
            if (Coordinates.SelectMany(x => x).Any(x => Double.IsNaN(x) || Double.IsInfinity(x)) ||
                Displacement.SelectMany(x => x).Any(x => Double.IsNaN(x) || Double.IsInfinity(x)) ||
                TotalDeformation.Any(x => Double.IsNaN(x) || Double.IsInfinity(x)) ||
                EquivalentStress.Any(x => Double.IsNaN(x) || Double.IsInfinity(x)))
                throw new InvalidDataException("Non-finite FEA value detected.");
            for(int i=0;i<Connectivity.Length;i++)
            {
                int expected=CellTypes[i]==10?4:(CellTypes[i]==12?8:(CellTypes[i]==24?10:0));
                if(expected==0) throw new InvalidDataException("Unsupported VTK cell type in result bundle: "+CellTypes[i]);
                int[] cell=Connectivity[i];
                if(cell==null || cell.Length!=expected) throw new InvalidDataException("Result connectivity/cell-type mismatch at element "+(i+1)+".");
                if(cell.Any(id=>id<1 || id>NodeCount)) throw new InvalidDataException("Result connectivity contains a node id outside the result mesh.");
                if(cell.Distinct().Count()!=expected) throw new InvalidDataException("Result connectivity contains duplicate node ids.");
            }
        }

        public void RequireCurrentModel(CaeModel.FeModel model)
        {
            if (model == null)
                throw new InvalidDataException("No active FeModel is available for result identity validation.");
            var active = AsterMaxModelFingerprint.Extract(model);
            if (!String.Equals(ResultModelFingerprintSha256, active.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("STALE results rejected: result fingerprint does not match the active FeModel.");
            if (NodeCount != active.NodeCount || ElementCount != active.ElementCount)
                throw new InvalidDataException("STALE results rejected: result mesh counts do not match the active FeModel.");
        }
        public string[] AvailableFields()
        {
            return new[] { "Total Deformation", "Equivalent Stress", "Displacement X", "Displacement Y", "Displacement Z" };
        }

        public double[] GetScalarField(string field)
        {
            switch (field)
            {
                case "Total Deformation": return TotalDeformation;
                case "Equivalent Stress": return EquivalentStress;
                case "Displacement X": return Displacement.Select(v => v[0]).ToArray();
                case "Displacement Y": return Displacement.Select(v => v[1]).ToArray();
                case "Displacement Z": return Displacement.Select(v => v[2]).ToArray();
                default: throw new ArgumentOutOfRangeException("field", field, "Unknown result field.");
            }
        }

        public Tuple<double,double> GetRange(string field)
        {
            double[] values = GetScalarField(field);
            return Tuple.Create(values.Min(), values.Max());
        }

        public double ProbeNode(int zeroBasedNodeIndex, string field)
        {
            if (zeroBasedNodeIndex < 0 || zeroBasedNodeIndex >= NodeCount)
                throw new ArgumentOutOfRangeException("zeroBasedNodeIndex");
            return GetScalarField(field)[zeroBasedNodeIndex];
        }

        public double[][] GetDeformedCoordinates(double scale)
        {
            var result = new double[NodeCount][];
            for (int i = 0; i < NodeCount; i++)
                result[i] = new[] {
                    Coordinates[i][0] + scale * Displacement[i][0],
                    Coordinates[i][1] + scale * Displacement[i][1],
                    Coordinates[i][2] + scale * Displacement[i][2]
                };
            return result;
        }

        public string ProvenanceSummary()
        {
            return String.Format(CultureInfo.InvariantCulture,
                "{0} | {1} | {2} nodes / {3} {4} | mm/N/MPa | SHA256 {5}",
                SourceKind, SourceName, NodeCount, ElementCount, ElementType, BundleSha256);
        }

        public string Describe(string field)
        {
            var r = GetRange(field);
            string unit = field == "Equivalent Stress" ? StressUnit : LengthUnit;
            return String.Format(CultureInfo.InvariantCulture,
                "{0} | Nodes {1} | Min {2:G7} {4} | Max {3:G7} {4}", field, NodeCount, r.Item1, r.Item2, unit);
        }
    }

    internal sealed class AsterMaxAnalysisManifest
    {
        public string ManifestFile { get; private set; }
        public string AnalysisId { get; private set; }
        public string ManifestSha256 { get; private set; }
        public string CadFile { get; private set; }
        public string MeshFile { get; private set; }
        public string SolverInputFile { get; private set; }
        public string MedFile { get; private set; }
        public string ResultsBundleFile { get; private set; }
        public string MaterialName { get; private set; }
        public string CodeAsterVersion { get; private set; }
        public int BoundaryConditionCount { get; private set; }
        public int LoadCount { get; private set; }

        public static AsterMaxAnalysisManifest Load(string path)
        {
            JObject root = JObject.Parse(File.ReadAllText(path));
            if ((string)root["schema"] != "astermax-analysis-provenance/v0")
                throw new InvalidDataException("Unsupported AsterMax analysis provenance schema.");
            if ((bool?)root["integrity"]?["fea_values_invented"] != false)
                throw new InvalidDataException("Analysis provenance rejects synthetic FEA values.");
            if ((string)root["units"]?["length"] != "mm" ||
                (string)root["units"]?["force"] != "N" ||
                (string)root["units"]?["stress"] != "MPa")
                throw new InvalidDataException("C9.75 requires the verified mm / N / MPa unit contract.");

            var m = new AsterMaxAnalysisManifest();
            m.ManifestFile = Path.GetFullPath(path);
            m.AnalysisId = (string)root["analysis_id"];
            m.MaterialName = (string)root["material"]?["name"];
            m.CodeAsterVersion = (string)root["solver"]?["code_aster_version"];
            m.BoundaryConditionCount = root["boundary_conditions"] == null ? 0 : root["boundary_conditions"].Count();
            m.LoadCount = root["loads"] == null ? 0 : root["loads"].Count();
            if (String.IsNullOrWhiteSpace(m.AnalysisId)) throw new InvalidDataException("analysis_id is required.");
            if (String.IsNullOrWhiteSpace(m.MaterialName)) throw new InvalidDataException("material.name is required.");
            if (String.IsNullOrWhiteSpace(m.CodeAsterVersion)) throw new InvalidDataException("solver.code_aster_version is required.");
            if (m.BoundaryConditionCount < 1) throw new InvalidDataException("At least one boundary condition is required.");
            if (m.LoadCount < 1) throw new InvalidDataException("At least one load is required.");

            string dir = Path.GetDirectoryName(m.ManifestFile);
            m.CadFile = VerifyArtifact(dir, root["cad"], "STEP CAD", "file", "sha256");
            if ((string)root["cad"]?["declared_length_unit"] != "mm")
                throw new InvalidDataException("STEP CAD must be explicitly declared in mm.");
            m.MeshFile = VerifyArtifact(dir, root["mesh"], "mesh", "file", "sha256");
            m.SolverInputFile = VerifyArtifact(dir, root["solver"], "Code_Aster input", "input_file", "input_sha256");
            m.MedFile = VerifyArtifact(dir, root["results"], "Code_Aster MED", "med_file", "med_sha256");
            m.ResultsBundleFile = VerifyArtifact(dir, root["results"], "results bundle", "bundle_file", "bundle_sha256");

            if ((string)root["mesh"]?["element_type"] != "HEXA8")
                throw new InvalidDataException("C9.75 PMV provenance currently admits the validated HEXA8 route only.");
            if ((int?)root["mesh"]?["node_count"] <= 0 || (int?)root["mesh"]?["element_count"] <= 0)
                throw new InvalidDataException("Mesh provenance requires positive node and element counts.");

            using (var sha = SHA256.Create())
                m.ManifestSha256 = BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(m.ManifestFile))).Replace("-", "").ToLowerInvariant();
            return m;
        }

        private static string VerifyArtifact(string manifestDir, JToken section, string label, string fileKey, string hashKey)
        {
            string rel = (string)section?[fileKey];
            string expected = ((string)section?[hashKey] ?? "").ToLowerInvariant();
            if (String.IsNullOrWhiteSpace(rel) || expected.Length != 64)
                throw new InvalidDataException(label + " provenance is incomplete.");
            string full = Path.GetFullPath(Path.Combine(manifestDir, rel));
            if (!File.Exists(full)) throw new FileNotFoundException(label + " artifact missing.", full);
            string actual;
            using (var sha = SHA256.Create())
                actual = BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(full))).Replace("-", "").ToLowerInvariant();
            if (!String.Equals(actual, expected, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException(label + " SHA-256 mismatch.");
            return full;
        }

        public string AuditSummary()
        {
            return String.Format(CultureInfo.InvariantCulture,
                "{0} | STEP(mm) -> mesh -> {1} -> {2} BC / {3} loads -> Code_Aster {4} -> MED -> bundle | manifest SHA256 {5}",
                AnalysisId, MaterialName, BoundaryConditionCount, LoadCount, CodeAsterVersion, ManifestSha256);
        }
    }

    internal sealed class AsterMaxModelFingerprint
    {
        public string Canonical { get; private set; }
        public string Sha256 { get; private set; }
        public string UnitSystem { get; private set; }
        public int NodeCount { get; private set; }
        public int ElementCount { get; private set; }
        public int MaterialCount { get; private set; }
        public int StepCount { get; private set; }
        public int BoundaryConditionCount { get; private set; }
        public int LoadCount { get; private set; }

        public static AsterMaxModelFingerprint Extract(CaeModel.FeModel model)
        {
            if (model == null) throw new ArgumentNullException("model");
            if (model.UnitSystem == null) throw new InvalidDataException("Model unit system is missing.");
            string length = model.UnitSystem.LengthUnitAbbreviation;
            string force = model.UnitSystem.ForceUnitAbbreviation;
            string stress = model.UnitSystem.PressureUnitAbbreviation;
            if (!String.Equals(length, "mm", StringComparison.OrdinalIgnoreCase) ||
                !String.Equals(force, "N", StringComparison.OrdinalIgnoreCase) ||
                !String.Equals(stress, "MPa", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("C9.76 automatic fingerprint requires the mm / N / MPa model unit contract.");

            var f = new AsterMaxModelFingerprint();
            f.UnitSystem = model.UnitSystem.UnitSystemType.ToString();
            var lines = new List<string>();
            lines.Add("schema=astermax-model-fingerprint/v0");
            lines.Add("units=mm|N|MPa");
            lines.Add("unit_system=" + f.UnitSystem);

            if (model.Mesh == null) throw new InvalidDataException("Model mesh is missing.");
            f.NodeCount = model.Mesh.Nodes == null ? 0 : model.Mesh.Nodes.Count;
            f.ElementCount = model.Mesh.Elements == null ? 0 : model.Mesh.Elements.Count;
            lines.Add("mesh.nodes=" + f.NodeCount.ToString(CultureInfo.InvariantCulture));
            lines.Add("mesh.elements=" + f.ElementCount.ToString(CultureInfo.InvariantCulture));
            if (model.Mesh.Nodes != null)
            {
                foreach (var kv in model.Mesh.Nodes.OrderBy(x => x.Key))
                    lines.Add(String.Format(CultureInfo.InvariantCulture, "node|{0}|{1:R}|{2:R}|{3:R}", kv.Key, kv.Value.X, kv.Value.Y, kv.Value.Z));
            }
            if (model.Mesh.Elements != null)
            {
                foreach (var kv in model.Mesh.Elements.OrderBy(x => x.Key))
                    lines.Add("element|" + kv.Key.ToString(CultureInfo.InvariantCulture) + "|" + kv.Value.GetType().FullName + "|" + String.Join(",", kv.Value.NodeIds.Select(x => x.ToString(CultureInfo.InvariantCulture))));
            }

            // C10.41: mesh-group and surface membership are part of result identity.
            // A BC/load that keeps the same group name but changes membership must stale old results.
            if (model.Mesh.NodeSets != null)
            {
                lines.Add("mesh.nodesets=" + model.Mesh.NodeSets.Count.ToString(CultureInfo.InvariantCulture));
                foreach (var kv in model.Mesh.NodeSets.OrderBy(x => x.Key, StringComparer.Ordinal))
                {
                    int[] labels = kv.Value == null || kv.Value.Labels == null ? new int[0] : kv.Value.Labels.OrderBy(x => x).ToArray();
                    lines.Add("nodeset|" + Escape(kv.Key) + "|" +
                        String.Join(",", labels.Select(x => x.ToString(CultureInfo.InvariantCulture))));
                }
            }
            if (model.Mesh.ElementSets != null)
            {
                lines.Add("mesh.elementsets=" + model.Mesh.ElementSets.Count.ToString(CultureInfo.InvariantCulture));
                foreach (var kv in model.Mesh.ElementSets.OrderBy(x => x.Key, StringComparer.Ordinal))
                {
                    int[] labels = kv.Value == null || kv.Value.Labels == null ? new int[0] : kv.Value.Labels.OrderBy(x => x).ToArray();
                    lines.Add("elementset|" + Escape(kv.Key) + "|" +
                        String.Join(",", labels.Select(x => x.ToString(CultureInfo.InvariantCulture))));
                }
            }
            if (model.Mesh.Surfaces != null)
            {
                lines.Add("mesh.surfaces=" + model.Mesh.Surfaces.Count.ToString(CultureInfo.InvariantCulture));
                foreach (var kv in model.Mesh.Surfaces.OrderBy(x => x.Key, StringComparer.Ordinal))
                {
                    var surface = kv.Value;
                    if (surface == null) { lines.Add("surface|" + Escape(kv.Key) + "|<null>"); continue; }
                    lines.Add(String.Format(CultureInfo.InvariantCulture,
                        "surface|{0}|type={1}|created={2}|area={3:R}|nodeset={4}|source_nodeset={5}",
                        Escape(kv.Key), surface.Type, surface.CreatedFrom, surface.Area,
                        Escape(surface.NodeSetName), Escape(surface.CreatedFromNodeSetName)));
                    if (surface.FaceIds != null)
                        lines.Add("surface.faces|" + Escape(kv.Key) + "|" +
                            String.Join(",", surface.FaceIds.OrderBy(x => x).Select(x => x.ToString(CultureInfo.InvariantCulture))));
                    if (surface.ElementFaces != null)
                    {
                        foreach (var ef in surface.ElementFaces.OrderBy(x => x.Key.ToString(), StringComparer.Ordinal))
                            lines.Add("surface.elementface|" + Escape(kv.Key) + "|" + ef.Key + "|" + Escape(ef.Value));
                    }
                }
            }
            f.MaterialCount = model.Materials == null ? 0 : model.Materials.Count;
            lines.Add("materials=" + f.MaterialCount.ToString(CultureInfo.InvariantCulture));
            if (model.Materials != null)
            {
                foreach (var kv in model.Materials.OrderBy(x => x.Key, StringComparer.Ordinal))
                {
                    lines.Add("material|" + Escape(kv.Key) + "|" + kv.Value.GetType().FullName);
                    AppendSimpleProperties(lines, "material." + Escape(kv.Key), kv.Value);
                }
            }

            if (model.StepCollection != null && model.StepCollection.StepsList != null)
            {
                f.StepCount = model.StepCollection.StepsList.Count;
                foreach (var step in model.StepCollection.StepsList)
                {
                    lines.Add("step|" + Escape(step.Name) + "|" + step.GetType().FullName);
                    if (step.BoundaryConditions != null)
                    {
                        foreach (var kv in step.BoundaryConditions.OrderBy(x => x.Key, StringComparer.Ordinal))
                        {
                            f.BoundaryConditionCount++;
                            lines.Add("bc|" + Escape(step.Name) + "|" + Escape(kv.Key) + "|" + kv.Value.GetType().FullName);
                            AppendSimpleProperties(lines, "bc." + Escape(step.Name) + "." + Escape(kv.Key), kv.Value);
                        }
                    }
                    if (step.Loads != null)
                    {
                        foreach (var kv in step.Loads.OrderBy(x => x.Key, StringComparer.Ordinal))
                        {
                            f.LoadCount++;
                            lines.Add("load|" + Escape(step.Name) + "|" + Escape(kv.Key) + "|" + kv.Value.GetType().FullName);
                            AppendSimpleProperties(lines, "load." + Escape(step.Name) + "." + Escape(kv.Key), kv.Value);
                        }
                    }
                }
            }
            lines.Add("steps=" + f.StepCount.ToString(CultureInfo.InvariantCulture));
            lines.Add("boundary_conditions=" + f.BoundaryConditionCount.ToString(CultureInfo.InvariantCulture));
            lines.Add("loads=" + f.LoadCount.ToString(CultureInfo.InvariantCulture));

            lines.Add("mechanical_revision_schema=C10.41");
            if(model.Materials!=null)
                foreach(var kv in model.Materials.OrderBy(x=>x.Key,StringComparer.Ordinal))
                    lines.Add("material.properties|"+Escape(kv.Key)+"|"+
                        Newtonsoft.Json.JsonConvert.SerializeObject(kv.Value.Properties,Newtonsoft.Json.Formatting.None));
            if(model.Sections!=null)
                foreach(var kv in model.Sections.OrderBy(x=>x.Key,StringComparer.Ordinal))
                    AppendSimpleProperties(lines,"section."+Escape(kv.Key),kv.Value);
            if(model.ContactPairs!=null)
                foreach(var kv in model.ContactPairs.OrderBy(x=>x.Key,StringComparer.Ordinal))
                    AppendSimpleProperties(lines,"contact."+Escape(kv.Key),kv.Value);
            if(model.SurfaceInteractions!=null)
                foreach(var kv in model.SurfaceInteractions.OrderBy(x=>x.Key,StringComparer.Ordinal))
                    lines.Add("interaction.properties|"+Escape(kv.Key)+"|"+
                        Newtonsoft.Json.JsonConvert.SerializeObject(kv.Value.Properties,Newtonsoft.Json.Formatting.None));
            // C1208_CONSTRAINT_FINGERPRINT
            lines.Add("constraint_revision_schema=C12.08");
            lines.Add("constraints="+(model.Constraints==null?0:model.Constraints.Count).ToString(CultureInfo.InvariantCulture));
            if(model.Constraints!=null)
                foreach(var kv in model.Constraints.OrderBy(x=>x.Key,StringComparer.Ordinal))
                {
                    lines.Add("constraint|"+Escape(kv.Key)+"|"+(kv.Value==null?"<null>":kv.Value.GetType().FullName));
                    AppendSimpleProperties(lines,"constraint."+Escape(kv.Key),kv.Value);
                }
            f.Canonical = String.Join("\n", lines);
            using (var sha = SHA256.Create())
                f.Sha256 = BitConverter.ToString(sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(f.Canonical))).Replace("-", "").ToLowerInvariant();
            return f;
        }

        private static void AppendSimpleProperties(List<string> lines, string prefix, object obj)
        {
            if (obj == null) return;
            var props = obj.GetType().GetProperties(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public)
                           .Where(p => p.CanRead && p.GetIndexParameters().Length == 0)
                           .OrderBy(p => p.Name, StringComparer.Ordinal);
            foreach (var p in props)
            {
                object value;
                try { value = p.GetValue(obj, null); } catch { continue; }
                if (value == null) { lines.Add(prefix + "." + p.Name + "=<null>"); continue; }
                Type t = value.GetType();
                if (t.IsEnum || t == typeof(string) || t == typeof(bool) || t == typeof(byte) || t == typeof(short) || t == typeof(int) || t == typeof(long) || t == typeof(float) || t == typeof(double) || t == typeof(decimal))
                {
                    string text = value is IFormattable fmt ? fmt.ToString(null, CultureInfo.InvariantCulture) : value.ToString();
                    lines.Add(prefix + "." + p.Name + "=" + Escape(text));
                }
            }
        }

        private static string Escape(string value)
        {
            if (value == null) return "<null>";
            return value.Replace("\\", "\\\\").Replace("\n", "\\n").Replace("\r", "\\r").Replace("|", "\\|");
        }

        public string AuditSummary()
        {
            return String.Format(CultureInfo.InvariantCulture,
                "{0} | {1} nodes / {2} elements | {3} materials | {4} steps | {5} BC / {6} loads | SHA256 {7}",
                UnitSystem, NodeCount, ElementCount, MaterialCount, StepCount, BoundaryConditionCount, LoadCount, Sha256);
        }
    }

    internal sealed class AsterMaxPreSolveReadiness
    {
        public string Status { get; private set; }
        public string ModelFingerprintSha256 { get; private set; }
        public int NodeCount { get; private set; }
        public int ElementCount { get; private set; }
        public int UnsupportedElementCount { get; private set; }
        public int MissingNodeReferenceCount { get; private set; }
        public int DegenerateConnectivityCount { get; private set; }
        public int MaterialCount { get; private set; }
        public int StepCount { get; private set; }
        public int BoundaryConditionCount { get; private set; }
        public int LoadCount { get; private set; }
        public List<string> Issues { get; private set; }

        private AsterMaxPreSolveReadiness()
        {
            Issues = new List<string>();
            Status = "BLOCKED";
        }

        public static AsterMaxPreSolveReadiness Evaluate(CaeModel.FeModel model)
        {
            var r = new AsterMaxPreSolveReadiness();
            if (model == null) { r.Issues.Add("BLOCK:model_missing"); return r; }

            try
            {
                var fp = AsterMaxModelFingerprint.Extract(model);
                r.ModelFingerprintSha256 = fp.Sha256;
            }
            catch (Exception ex)
            {
                r.Issues.Add("BLOCK:unit_or_fingerprint_contract:" + ex.Message);
                return r;
            }

            if (model.Mesh == null)
            {
                r.Issues.Add("BLOCK:mesh_missing");
                return r;
            }

            r.NodeCount = model.Mesh.Nodes == null ? 0 : model.Mesh.Nodes.Count;
            r.ElementCount = model.Mesh.Elements == null ? 0 : model.Mesh.Elements.Count;
            if (r.NodeCount == 0) r.Issues.Add("BLOCK:mesh_has_no_nodes");
            if (r.ElementCount == 0) r.Issues.Add("BLOCK:mesh_has_no_elements");

            if (model.Mesh.Elements != null)
            {
                foreach (var kv in model.Mesh.Elements)
                {
                    var e = kv.Value;
                    int expectedNodeCount = 0;
                    if (e is CaeMesh.LinearHexaElement) expectedNodeCount = 8;
                    else if (e is CaeMesh.LinearTetraElement) expectedNodeCount = 4;
                    else if (e is CaeMesh.ParabolicTetraElement) expectedNodeCount = 10;
                    else
                    {
                        r.UnsupportedElementCount++;
                        continue;
                    }
                    if (e.NodeIds == null || e.NodeIds.Length != expectedNodeCount)
                    {
                        r.DegenerateConnectivityCount++;
                        continue;
                    }
                    if (e.NodeIds.Distinct().Count() != e.NodeIds.Length)
                        r.DegenerateConnectivityCount++;
                    foreach (int nodeId in e.NodeIds)
                        if (model.Mesh.Nodes == null || !model.Mesh.Nodes.ContainsKey(nodeId))
                            r.MissingNodeReferenceCount++;
                }
            }
            if (r.UnsupportedElementCount > 0)
                r.Issues.Add("BLOCK:unsupported_elements_for_code_aster_c1004=" + r.UnsupportedElementCount.ToString(CultureInfo.InvariantCulture));
            if (r.MissingNodeReferenceCount > 0)
                r.Issues.Add("BLOCK:element_node_references_missing=" + r.MissingNodeReferenceCount.ToString(CultureInfo.InvariantCulture));
            if (r.DegenerateConnectivityCount > 0)
                r.Issues.Add("BLOCK:degenerate_element_connectivity=" + r.DegenerateConnectivityCount.ToString(CultureInfo.InvariantCulture));

            r.MaterialCount = model.Materials == null ? 0 : model.Materials.Count;
            if (r.MaterialCount == 0) r.Issues.Add("BLOCK:no_material_defined");

            if (model.StepCollection != null && model.StepCollection.StepsList != null)
            {
                r.StepCount = model.StepCollection.StepsList.Count;
                foreach (var step in model.StepCollection.StepsList)
                {
                    if (step.BoundaryConditions != null) r.BoundaryConditionCount += step.BoundaryConditions.Count;
                    if (step.Loads != null) r.LoadCount += step.Loads.Count;
                }
            }
            if (r.StepCount == 0) r.Issues.Add("BLOCK:no_analysis_step");
            if (r.BoundaryConditionCount == 0) r.Issues.Add("BLOCK:no_boundary_conditions");
            if (r.LoadCount == 0) r.Issues.Add("BLOCK:no_loads");

            // C9.77 deliberately does not invent geometric quality metrics. Jacobian/aspect/skewness
            // become separate gates only after validated algorithms exist for each supported element family.
            r.Status = r.Issues.Any(x => x.StartsWith("BLOCK:", StringComparison.Ordinal)) ? "BLOCKED" :
                       (r.Issues.Count > 0 ? "WARNING" : "READY");
            return r;
        }

        public string AuditSummary()
        {
            return String.Format(CultureInfo.InvariantCulture,
                "{0} | {1} nodes / {2} supported volume elements | {3} materials | {4} steps | {5} BC / {6} loads | fingerprint {7} | issues {8}",
                Status, NodeCount, ElementCount, MaterialCount, StepCount, BoundaryConditionCount, LoadCount,
                String.IsNullOrEmpty(ModelFingerprintSha256) ? "none" : ModelFingerprintSha256.Substring(0, 12), Issues.Count);
        }
    }

    internal sealed class AsterMaxAssignmentQualityGate
    {
        public string Status { get; private set; }
        public int SectionCount { get; private set; }
        public int AssignedElementCount { get; private set; }
        public int UnassignedElementCount { get; private set; }
        public int MultiplyAssignedElementCount { get; private set; }
        public int MissingMaterialReferenceCount { get; private set; }
        public int MissingSectionRegionCount { get; private set; }
        public int NonPositiveCenterJacobianCount { get; private set; }
        public double MinimumCenterJacobian { get; private set; }
        public List<string> Issues { get; private set; }

        private AsterMaxAssignmentQualityGate()
        {
            Status = "BLOCKED";
            Issues = new List<string>();
            MinimumCenterJacobian = Double.PositiveInfinity;
        }

        public static AsterMaxAssignmentQualityGate Evaluate(CaeModel.FeModel model)
        {
            var r = new AsterMaxAssignmentQualityGate();
            if (model == null || model.Mesh == null || model.Mesh.Elements == null)
            {
                r.Issues.Add("BLOCK:model_or_mesh_missing");
                return r;
            }

            var assignmentCounts = new Dictionary<int, int>();
            if (model.Sections != null)
            {
                r.SectionCount = model.Sections.Count;
                foreach (var kv in model.Sections)
                {
                    var section = kv.Value;
                    if (section == null) continue;
                    if (String.IsNullOrWhiteSpace(section.MaterialName) || model.Materials == null || !model.Materials.ContainsKey(section.MaterialName))
                    {
                        r.MissingMaterialReferenceCount++;
                        continue;
                    }
                    int[] regionElementIds = null;
                    if (section.RegionType == CaeGlobals.RegionTypeEnum.ElementSetName)
                    {
                        if (model.Mesh.ElementSets == null || String.IsNullOrWhiteSpace(section.RegionName) ||
                            !model.Mesh.ElementSets.ContainsKey(section.RegionName) ||
                            model.Mesh.ElementSets[section.RegionName] == null)
                        {
                            r.MissingSectionRegionCount++;
                            continue;
                        }
                        regionElementIds = model.Mesh.ElementSets[section.RegionName].Labels;
                    }
                    else if (section.RegionType == CaeGlobals.RegionTypeEnum.PartName)
                    {
                        if (model.Mesh.Parts == null || String.IsNullOrWhiteSpace(section.RegionName) ||
                            !model.Mesh.Parts.ContainsKey(section.RegionName) ||
                            model.Mesh.Parts[section.RegionName] == null)
                        {
                            r.MissingSectionRegionCount++;
                            continue;
                        }
                        regionElementIds = model.Mesh.Parts[section.RegionName].Labels;
                    }
                    else
                    {
                        r.MissingSectionRegionCount++;
                        continue;
                    }
                    if (regionElementIds == null || regionElementIds.Length == 0)
                    {
                        r.MissingSectionRegionCount++;
                        continue;
                    }
                    foreach (int id in regionElementIds)
                    {
                        if (!model.Mesh.Elements.ContainsKey(id))
                        {
                            r.MissingSectionRegionCount++;
                            continue;
                        }
                        int count;
                        assignmentCounts.TryGetValue(id, out count);
                        assignmentCounts[id] = count + 1;
                    }
                }
            }

            r.AssignedElementCount = assignmentCounts.Count;
            r.MultiplyAssignedElementCount = assignmentCounts.Count(x => x.Value > 1);
            r.UnassignedElementCount = model.Mesh.Elements.Keys.Count(id => !assignmentCounts.ContainsKey(id));
            if (r.SectionCount == 0) r.Issues.Add("BLOCK:no_sections_defined");
            if (r.MissingMaterialReferenceCount > 0) r.Issues.Add("BLOCK:section_material_reference_missing=" + r.MissingMaterialReferenceCount.ToString(CultureInfo.InvariantCulture));
            if (r.MissingSectionRegionCount > 0) r.Issues.Add("BLOCK:section_region_invalid=" + r.MissingSectionRegionCount.ToString(CultureInfo.InvariantCulture));
            if (r.UnassignedElementCount > 0) r.Issues.Add("BLOCK:elements_without_section=" + r.UnassignedElementCount.ToString(CultureInfo.InvariantCulture));
            if (r.MultiplyAssignedElementCount > 0) r.Issues.Add("BLOCK:elements_with_multiple_sections=" + r.MultiplyAssignedElementCount.ToString(CultureInfo.InvariantCulture));

            foreach (var kv in model.Mesh.Elements)
            {
                var hex = kv.Value as CaeMesh.LinearHexaElement;
                if (hex == null || hex.NodeIds == null || hex.NodeIds.Length != 8) continue;
                bool nodesPresent = true;
                var nodes = new CaeMesh.FeNode[8];
                for (int i = 0; i < 8; i++)
                {
                    if (model.Mesh.Nodes == null || !model.Mesh.Nodes.TryGetValue(hex.NodeIds[i], out nodes[i]))
                    {
                        nodesPresent = false;
                        break;
                    }
                }
                if (!nodesPresent) continue;
                double det = CenterJacobianDeterminant(nodes);
                if (det < r.MinimumCenterJacobian) r.MinimumCenterJacobian = det;
                if (!(det > 0.0)) r.NonPositiveCenterJacobianCount++;
            }
            if (Double.IsPositiveInfinity(r.MinimumCenterJacobian)) r.MinimumCenterJacobian = Double.NaN;
            if (r.NonPositiveCenterJacobianCount > 0)
                r.Issues.Add("BLOCK:hexa8_nonpositive_center_jacobian=" + r.NonPositiveCenterJacobianCount.ToString(CultureInfo.InvariantCulture));

            r.Status = r.Issues.Any(x => x.StartsWith("BLOCK:", StringComparison.Ordinal)) ? "BLOCKED" : "READY";
            return r;
        }

        public static double CenterJacobianDeterminant(CaeMesh.FeNode[] n)
        {
            if (n == null || n.Length != 8) throw new ArgumentException("HEXA8 requires exactly eight nodes.");
            int[,] natural = new int[,] {
                {-1,-1,-1},{ 1,-1,-1},{ 1, 1,-1},{-1, 1,-1},
                {-1,-1, 1},{ 1,-1, 1},{ 1, 1, 1},{-1, 1, 1}
            };
            double[,] j = new double[3,3];
            for (int i = 0; i < 8; i++)
            {
                double dXi   = natural[i,0] / 8.0;
                double dEta  = natural[i,1] / 8.0;
                double dZeta = natural[i,2] / 8.0;
                j[0,0] += n[i].X*dXi;   j[0,1] += n[i].X*dEta;   j[0,2] += n[i].X*dZeta;
                j[1,0] += n[i].Y*dXi;   j[1,1] += n[i].Y*dEta;   j[1,2] += n[i].Y*dZeta;
                j[2,0] += n[i].Z*dXi;   j[2,1] += n[i].Z*dEta;   j[2,2] += n[i].Z*dZeta;
            }
            return j[0,0]*(j[1,1]*j[2,2]-j[1,2]*j[2,1])
                 - j[0,1]*(j[1,0]*j[2,2]-j[1,2]*j[2,0])
                 + j[0,2]*(j[1,0]*j[2,1]-j[1,1]*j[2,0]);
        }

        public string AuditSummary()
        {
            return String.Format(CultureInfo.InvariantCulture,
                "{0} | {1} sections | {2} assigned / {3} unassigned | min HEXA8 center detJ {4:R} | nonpositive {5} | issues {6}",
                Status, SectionCount, AssignedElementCount, UnassignedElementCount, MinimumCenterJacobian,
                NonPositiveCenterJacobianCount, Issues.Count);
        }
    }

    internal static class AsterMaxModelFidelityGate
    {
        public static bool Verify(CaeModel.FeModel model, string expectedSha256)
        {
            if (model == null) throw new ArgumentNullException("model");
            if (String.IsNullOrWhiteSpace(expectedSha256)) throw new ArgumentException("Expected fingerprint is required.", "expectedSha256");
            var current=AsterMaxModelFingerprint.Extract(model);
            return String.Equals(current.Sha256, expectedSha256.Trim(), StringComparison.OrdinalIgnoreCase);
        }

        public static string Require(CaeModel.FeModel model, string expectedSha256)
        {
            var current=AsterMaxModelFingerprint.Extract(model);
            if (!String.Equals(current.Sha256, expectedSha256 == null ? null : expectedSha256.Trim(), StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("MODEL FIDELITY BLOCKED: FeModel changed after the verified fingerprint was captured. Re-run readiness/export before Solve.");
            return current.Sha256;
        }
    }

    public partial class FrmMain
    {
        private AsterMaxResultsBundle _asterMaxLoadedResults;

        private void OpenAsterMaxResultsBundle()
        {
            try
            {
                using (var dlg = new OpenFileDialog())
                {
                    dlg.Title = "Load real Code_Aster results bundle";
                    dlg.Filter = "AsterMax Results Bundle (*.json)|*.json|All files (*.*)|*.*";
                    if (dlg.ShowDialog(this) != DialogResult.OK) return;
                    _asterMaxLoadedResults = AsterMaxResultsBundle.Load(dlg.FileName);
                    _asterMaxLoadedResults.RequireCurrentModel(_controller == null ? null : _controller.Model);
                    var fields = _asterMaxLoadedResults.AvailableFields();
                    MessageBox.Show(this,
                        _asterMaxLoadedResults.Describe(fields[0]) + Environment.NewLine +
                        _asterMaxLoadedResults.Describe(fields[1]) + Environment.NewLine + Environment.NewLine +
                        "Bundle accepted. Native VTK actor binding is the next visualization gate.",
                        "AsterMax Results Workspace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                CaeGlobals.MessageBoxes.ShowError("AsterMax results bundle rejected: " + ex.Message);
            }
        }
    }
}













