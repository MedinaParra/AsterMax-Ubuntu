using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace PrePoMax
{
    internal sealed partial class AsterMaxResultsViewportForm
    {
        public event Action<string> ResultFieldChanged;
        public Action ValidateModel;
        private bool _axRendering;
        public bool AuditMode { get; set; }
        public string LastRenderError { get; private set; }
        public bool LastRenderSkipped { get; private set; }
        public string LastRenderSkipReason { get; private set; }
        public int RenderRevision { get; private set; }
        public string SelectedResultField { get { return (string)_field.SelectedItem; } }
        public bool ContoursVisible { get { return _showContours.Checked; } }
        public bool DeformationVisible { get { return _showDeformed.Checked; } }
        public bool MeshEdgesVisible { get { return _showEdges.Checked; } }

        public Control DetachResultDetails()
        {
            var details = _legend.Parent;
            Controls.Remove(details);
            _legend.Visible = false; // The native VTK scalar bar remains the color authority.
            details.Dock = DockStyle.Fill;
            return details;
        }

        public void SelectResultField(string field)
        {
            if (!_field.Items.Contains(field)) throw new ArgumentException("Result field is unavailable: " + field);
            if (SelectedResultField != field) _field.SelectedItem = field;
            else if (_view == null) RenderScene();
        }

        public void ExecuteResultCommand(string command)
        {
            ValidateModel?.Invoke();
            switch (command)
            {
                case "Contours": _showContours.Checked = !_showContours.Checked; return;
                case "Deformed": _showDeformed.Checked = !_showDeformed.Checked; return;
                case "Original":
                    if (_showDeformed.Checked) _showDeformed.Checked = false;
                    else if (_view == null) RenderScene();
                    return;
                case "Edges": _showEdges.Checked = !_showEdges.Checked; return;
            }
            if (_view == null) RenderScene();
            if (_view == null) throw new InvalidOperationException("The result viewport is unavailable: " + LastRenderError);
            switch (command)
            {
                case "Fit": _view.AdjustCameraDistanceAndClipping(); break;
                case "Front": _view.SetFrontBackView(false, true); break;
                case "Top": _view.SetTopBottomView(false, true); break;
                case "Right": _view.SetLeftRightView(false, false); break;
                case "Isometric": _view.SetIsometricView(false, true); break;
                default: throw new ArgumentException("Unknown result command: " + command);
            }
        }
    }

    public partial class FrmMain
    {
        private AsterMaxResultsViewportForm _axEmbeddedResults;
        private AsterMaxResultsBundle _axEmbeddedBundle;
        private Panel _axResultDetailsHost;
        private Control _axResultDetails;
        private TextBox _axSolutionInformation;
        private bool _axSelectingResult;
        private bool _axRefreshingResults;
        private bool _axContactInspectMode;
        private vtkControl.vtkEdgesVisibility _axContactPreviousEdges;
        private bool _asterMaxPreviousResultsRetained;
        private bool _asterMaxCloseAfterSolveCancel;
        private long _asterMaxModelSessionRevision;

        private void InitializeAsterMaxIntegratedResults()
        {
            _modelTree.AsterMaxResultRequested += field => InvokeAsterMaxCommand("Result selection", () => ShowAsterMaxIntegratedResult(field));
            _modelTree.AsterMaxModelViewRequested += ShowAsterMaxModelWorkspace;
            _modelTree.AsterMaxModelTreeChanged += RefreshAsterMaxResultAvailability;
            _modelTree.AsterMaxContactPairSelected += ShowAsterMaxContactPair;
            FormClosing += AsterMaxFormClosingDuringSolve;
            Disposed += (s,e) => ResetAsterMaxIntegratedResults();
        }

        private void AsterMaxFormClosingDuringSolve(object sender, FormClosingEventArgs e)
        {
            if(!_asterMaxSolveInProgress) return;
            e.Cancel=true;
            _asterMaxCloseAfterSolveCancel=true;
            tsslState.Text="AsterMax Solve: cancelling before close";
            if(_asterMaxSolveTransaction!=null)
                _asterMaxSolveTransaction.RequestCancel();
        }
        private void RefreshAsterMaxResultAvailability()
        {
            if (_axRefreshingResults || _modelTree == null) return;
            _axRefreshingResults = true;
            try
            {
                if (_asterMaxLoadedResults == null)
                {
                    _modelTree.SetAsterMaxResultFields(new string[0],
                        _asterMaxSolveInProgress ? "Solving..." : "Not solved", false);
                    return;
                }
                try
                {
                    _asterMaxLoadedResults.RequireCurrentModel(_controller == null ? null : _controller.Model);
                    string currentLabel=_asterMaxSolveInProgress ? "Previous solution - new solve running" :
                        (_asterMaxPreviousResultsRetained ? "Previous successful solution retained" : "Current");
                    _modelTree.SetAsterMaxResultFields(_asterMaxLoadedResults.AvailableFields(),currentLabel,!_asterMaxSolveInProgress);
                }
                catch (Exception ex) when (ex is InvalidDataException || ex is InvalidOperationException)
                {
                    ShowAsterMaxModelWorkspace();
                    _modelTree.SetAsterMaxResultFields(_asterMaxLoadedResults.AvailableFields(), "Stale - solve again", false);
                    tsslState.Text = "Results are out of date: " + ex.Message;
                }
            }
            finally { _axRefreshingResults = false; }
        }

        private void ShowAsterMaxIntegratedResult(string field)
        {
            if (_axSelectingResult) return;
            _axSelectingResult = true;
            try
            {
                if (field == "__information__") { ShowAsterMaxSolutionInformation(); return; }
                if (_asterMaxLoadedResults == null)
                {
                    using (var dialog = new OpenFileDialog { Title="Load Code_Aster results for this model", Filter="AsterMax Results (*.json)|*.json" })
                    {
                        if (dialog.ShowDialog(this) != DialogResult.OK) return;
                        var candidate = AsterMaxResultsBundle.Load(dialog.FileName);
                        candidate.RequireCurrentModel(_controller == null ? null : _controller.Model);
                        _asterMaxLoadedResults = candidate;
                        _asterMaxPreviousResultsRetained = false;
                    }
                }
                _asterMaxLoadedResults.RequireCurrentModel(_controller == null ? null : _controller.Model);
                if (_axEmbeddedResults == null || _axEmbeddedResults.IsDisposed || !Object.ReferenceEquals(_axEmbeddedBundle, _asterMaxLoadedResults))
                {
                    DisposeAsterMaxResultView();
                    var bundle = _asterMaxLoadedResults;
                    _axEmbeddedBundle = bundle;
                    _axEmbeddedResults = new AsterMaxResultsViewportForm(bundle) {
                        Name="asterMaxIntegratedResults", TopLevel=false, FormBorderStyle=FormBorderStyle.None,
                        ShowInTaskbar=false, Dock=DockStyle.Fill, AuditMode=_asterMaxUiAuditMode };
                    _axEmbeddedResults.ValidateModel = () => bundle.RequireCurrentModel(_controller == null ? null : _controller.Model);
                    _axEmbeddedResults.ResultFieldChanged += selected => {
                        if (!_axSelectingResult) _modelTree.SelectAsterMaxResultField(selected);
                    };
                    splitContainer2.Panel1.Controls.Add(_axEmbeddedResults);
                    _axResultDetails = _axEmbeddedResults.DetachResultDetails();
                    _axResultDetailsHost = new Panel { Name="asterMaxResultDetails", Dock=DockStyle.Bottom, Height=250, BackColor=Color.White };
                    _axResultDetailsHost.Controls.Add(_axResultDetails);
                    splitContainer1.Panel1.Controls.Add(_axResultDetailsHost);
                    _axResultDetailsHost.SendToBack();
                    _modelTree.BringToFront();
                }
                if (_axSolutionInformation != null) _axSolutionInformation.Hide();
                panelControl.Hide();
                _axEmbeddedResults.Show();
                _axEmbeddedResults.BringToFront();
                _axResultDetailsHost.Show();
                _axEmbeddedResults.SelectResultField(String.IsNullOrEmpty(field) ? _axEmbeddedResults.SelectedResultField : field);
                if (_axEmbeddedResults.LastRenderSkipped)
                    throw new InvalidOperationException("Results render did not run: " + _axEmbeddedResults.LastRenderSkipReason);
                if (_axEmbeddedResults.LastRenderError != null) throw new InvalidOperationException(_axEmbeddedResults.LastRenderError);
                RefreshAsterMaxResultAvailability();
                _modelTree.RefreshAsterMaxOutline();
                _modelTree.SelectAsterMaxResultField(_axEmbeddedResults.SelectedResultField);
                var ribbon = Controls["asterMaxRibbon"] as TabControl;
                if (ribbon != null) foreach (TabPage page in ribbon.TabPages) if (page.Text == "Results") ribbon.SelectedTab = page;
                tsslState.Text = "Results: " + _axEmbeddedResults.SelectedResultField;
            }
            catch
            {
                ShowAsterMaxModelWorkspace();
                RefreshAsterMaxResultAvailability();
                throw;
            }
            finally { _axSelectingResult = false; }
        }

        private void ShowAsterMaxSolutionInformation()
        {
            ShowAsterMaxModelWorkspace();
            if (_axSolutionInformation == null)
            {
                _axSolutionInformation = new TextBox { Name="asterMaxSolutionInformation", Dock=DockStyle.Fill,
                    Multiline=true, ReadOnly=true, ScrollBars=ScrollBars.Both, Font=new Font("Consolas",10), BackColor=Color.White };
                splitContainer2.Panel1.Controls.Add(_axSolutionInformation);
            }
            string text = "Información de la solución\r\n\r\n";
            if (_asterMaxSolveTransaction != null)
            {
                text += _asterMaxSolveTransaction.State + "\r\n" + _asterMaxSolveTransaction.Message + "\r\n\r\n";
                // C1208_VISIBLE_BONDED_AND_LOADS
                string bondedAndLoads=AsterMaxNativeSolveTransaction.DescribeBondedAndLoads(_asterMaxSolveTransaction.Workspace);
                if(!String.IsNullOrWhiteSpace(bondedAndLoads)) text+="\r\n"+bondedAndLoads+"\r\n\r\n";
                // C1207_VISIBLE_CONTACT_ORIENTATION
                string contactOrientation=AsterMaxNativeSolveTransaction.DescribeContactOrientation(_asterMaxSolveTransaction.Workspace);
                if(!String.IsNullOrWhiteSpace(contactOrientation)) text+="\r\n"+contactOrientation+"\r\n\r\n";
                text += "Workspace: " + _asterMaxSolveTransaction.Workspace + "\r\n";
                if (File.Exists(_asterMaxSolveTransaction.MessFile))
                    text += String.Join("\r\n", File.ReadLines(_asterMaxSolveTransaction.MessFile).Reverse().Take(100).Reverse());
            }
            else text += "No solver run recorded in this session.\r\n";
            if (_asterMaxLoadedResults != null)
            {
                text += "\r\nBundle: " + _asterMaxLoadedResults.SourceFile;
                if (_asterMaxPreviousResultsRetained)
                    text += "\r\nStatus: previous successful result retained after a later Solve did not complete successfully.";
                try
                {
                    text += "\r\n\r\n" + AsterMaxMechanicalQualification.Evaluate(_asterMaxLoadedResults).Describe();
                }
                catch(Exception ex)
                {
                    text += "\r\n\r\nMechanical Qualification: unavailable\r\n" + ex.Message;
                }
            }
            _axSolutionInformation.Text = text;
            panelControl.Hide();
            _axSolutionInformation.Show();
            _axSolutionInformation.BringToFront();
        }

        private void ShowAsterMaxModelWorkspace()
        {
            AsterMaxExitContactInspection();
            if (_axEmbeddedResults != null && !_axEmbeddedResults.IsDisposed) _axEmbeddedResults.Hide();
            if (_axResultDetailsHost != null) _axResultDetailsHost.Hide();
            if (_axSolutionInformation != null) _axSolutionInformation.Hide();
            if (panelControl != null && !panelControl.IsDisposed) panelControl.Show();
        }

        private void ShowAsterMaxContactPair(string contactPairName)
        {
            if (_controller == null || _vtk == null || String.IsNullOrWhiteSpace(contactPairName)) return;

            if (_axEmbeddedResults != null && !_axEmbeddedResults.IsDisposed) _axEmbeddedResults.Hide();
            if (_axResultDetailsHost != null) _axResultDetailsHost.Hide();
            if (_axSolutionInformation != null) _axSolutionInformation.Hide();
            if (panelControl != null && !panelControl.IsDisposed) panelControl.Show();

            var cp=_controller.GetContactPair(contactPairName);
            if(cp==null) return;

            cp.MasterColor=Color.Red;
            cp.SlaveColor=Color.RoyalBlue;

            if(!_axContactInspectMode)
            {
                _axContactPreviousEdges=_vtk.EdgesVisibility;
                _axContactInspectMode=true;
            }

            _modelTree.SetGeometryTab();
            ModelTree_ViewEvent(UserControls.ViewType.Geometry);
            _controller.DrawGeometry(false);

            _vtk.SetAllActorOpacity(0.18);
            _vtk.EdgesVisibility=vtkControl.vtkEdgesVisibility.NoEdges;
            _controller.ClearSelectionHistory();
            _controller.HighlightContactPairs(new[]{contactPairName});
            _vtk.SetZoomToFit(false);
        }

        private void AsterMaxExitContactInspection()
        {
            if(!_axContactInspectMode || _vtk==null || _vtk.IsDisposed) return;
            _axContactInspectMode=false;
            _vtk.SetAllActorOpacity(1.0);
            _vtk.EdgesVisibility=_axContactPreviousEdges;
            if(_controller!=null) _controller.ClearSelectionHistory();
        }
        private void DisposeAsterMaxResultView()
        {
            if (_axEmbeddedResults != null) { _axEmbeddedResults.Dispose(); _axEmbeddedResults=null; }
            if (_axResultDetailsHost != null) { _axResultDetailsHost.Dispose(); _axResultDetailsHost=null; }
            _axResultDetails=null;
            _axEmbeddedBundle=null;
        }

        private void ResetAsterMaxIntegratedResults()
        {
            System.Threading.Interlocked.Increment(ref _asterMaxModelSessionRevision);
            ShowAsterMaxModelWorkspace();
            DisposeAsterMaxResultView();
            _asterMaxLoadedResults=null;
            _asterMaxPreviousResultsRetained=false;
            _asterMaxCloseAfterSolveCancel=false;
            _asterMaxSolveTransaction=null;
            if (_axSolutionInformation != null) { _axSolutionInformation.Dispose(); _axSolutionInformation=null; }
            if (_modelTree != null && !_modelTree.IsDisposed) _modelTree.SetAsterMaxResultFields(new string[0], "Not solved", false);
        }

        private bool RouteAsterMaxIntegratedCommand(string caption)
        {
            switch (caption)
            {
                case "Explorador": caption = "Results Explorer"; break;
                case "Viewport FEA": caption = "FEA Viewport"; break;
                case "Contornos": caption = "Contours"; break;
                case "Deformada": caption = "Deformed"; break;
                case "Ajustar": caption = "Fit"; break;
                case "Frontal": caption = "Front"; break;
                case "Superior": caption = "Top"; break;
                case "Derecha": caption = "Right"; break;
                case "Isométrica": case "Isometrica": caption = "Isometric"; break;
                case "Aristas": caption = "Edges"; break;
                case "Guardar": caption = "Save"; break;
                case "Auditoría": case "Auditoria": caption = "Auditoria"; break;
            }
            if (caption == "Results Explorer" || caption == "FEA Viewport") { ShowAsterMaxIntegratedResult(null); return true; }
            bool resultOnly = caption == "Contours" || caption == "Deformed" || caption == "Original";
            bool camera = new[]{"Fit","Front","Top","Right","Isometric","Edges"}.Contains(caption);
            if (resultOnly && (_axEmbeddedResults == null || !_axEmbeddedResults.Visible)) ShowAsterMaxIntegratedResult(null);
            if ((resultOnly || camera) && _axEmbeddedResults != null && _axEmbeddedResults.Visible)
            {
                _axEmbeddedResults.ExecuteResultCommand(caption);
                return true;
            }
            if (resultOnly) return true; // Loading was cancelled; do not invoke the inherited result command.
            if (!camera && caption != "Result selection" && caption != "Save" && caption != "Auditoria") ShowAsterMaxModelWorkspace();
            return false;
        }
    }
}






