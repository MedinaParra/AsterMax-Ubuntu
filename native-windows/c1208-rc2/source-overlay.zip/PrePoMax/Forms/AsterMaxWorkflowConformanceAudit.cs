using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using CaeGlobals;
using CaeMesh;
using CaeModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UserControls;

namespace PrePoMax
{
    public partial class FrmMain
    {
        private static string AsterMaxC1020WorkflowDirectoryFromCommandLine()
        {
            const string prefix = "--astermax-c1020-workflow=";
            string argument = Environment.GetCommandLineArgs()
                .FirstOrDefault(x => x.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
            return argument == null ? null : argument.Substring(prefix.Length).Trim('"');
        }

        private void StartAsterMaxC1020WorkflowConformanceAudit()
        {
            string directory = AsterMaxC1020WorkflowDirectoryFromCommandLine();
            if (String.IsNullOrWhiteSpace(directory)) return;
            _asterMaxUiAuditMode = true;
            int attempts = 0;
            var timer = new Timer { Interval = 1000 };
            timer.Tick += async (s, e) =>
            {
                attempts++;
                Dictionary<string, AsterMaxSectionState> states = null;
                try { states = BuildAsterMaxSectionStates(); } catch { }
                bool geometryReady = states != null && states.ContainsKey("geometry") && states["geometry"].State >= 2;
                if (!geometryReady && attempts < 60) return;
                timer.Stop();
                timer.Dispose();
                Directory.CreateDirectory(directory);
                try
                {
                    if (!geometryReady)
                        throw new InvalidOperationException("B01 STEP was not observable in the native GUI after 60 seconds.");
                    await ExecuteAsterMaxC1020WorkflowConformanceAudit(directory);
                    if (!StrictNativeChain) C1020AttachCrossCuttingToSession(directory);
                    C1020RequestAuditExit(directory, 0);
                }
                catch (Exception ex)
                {
                    string sessionPath = Path.Combine(directory, "workflow-conformance-session.json");
                    JObject failure = null;
                    if (File.Exists(sessionPath))
                    {
                        try { failure = JObject.Parse(File.ReadAllText(sessionPath)); }
                        catch { failure = null; }
                    }
                    if (failure == null)
                    {
                        failure = new JObject {
                            ["release"] = "C10.20.8",
                            ["partial"] = true,
                            ["rows"] = new JArray()
                        };
                    }
                    failure["pass"] = false;
                    failure["error"] = ex.ToString();
                    failure["historical_pending_closed"] = false;
                    File.WriteAllText(sessionPath, failure.ToString(Formatting.Indented));
                    C1020RequestAuditExit(directory, 1);
                }
            };
            timer.Start();
        }

        private string _c10209AuditShutdownDirectory;

        private void C10209TraceShutdown(string directory, string eventName, FormClosingEventArgs closingArgs = null)
        {
            if (String.IsNullOrWhiteSpace(directory)) return;
            try
            {
                int runningJobs = 0;
                if (_controller != null && _controller.Jobs != null)
                    foreach (var entry in _controller.Jobs)
                        if (entry.Value != null && String.Equals(entry.Value.JobStatus.ToString(), "Running", StringComparison.OrdinalIgnoreCase))
                            runningJobs++;

                string forms = String.Join(";",
                    Application.OpenForms.Cast<Form>().Select(form =>
                        (form.Name ?? "") + ":" + (form.Text ?? "").Replace("|", "/") +
                        ":visible=" + form.Visible + ":modal=" + form.Modal + ":enabled=" + form.Enabled));

                string line = String.Join("|", new [] {
                    DateTime.UtcNow.ToString("O"),
                    eventName,
                    "thread=" + System.Threading.Thread.CurrentThread.ManagedThreadId,
                    "invoke_required=" + InvokeRequired,
                    "audit_mode=" + _asterMaxUiAuditMode,
                    "exit_code=" + Environment.ExitCode,
                    "status=" + (tsslState == null ? "<null>" : (tsslState.Text ?? "").Replace("|", "/")),
                    "ready=" + (Globals.ReadyText ?? "").Replace("|", "/"),
                    "model_changed=" + (_controller == null ? "<null>" : _controller.ModelChanged.ToString()),
                    "saving_file=" + (_controller == null ? "<null>" : _controller.SavingFile.ToString()),
                    "running_jobs=" + runningJobs,
                    "solve_in_progress=" + _asterMaxSolveInProgress,
                    "solve_state=" + (_asterMaxSolveTransaction == null ? "<null>" : _asterMaxSolveTransaction.State.ToString()),
                    "solve_ui_thread=" + _asterMaxSolveUiThreadId,
                    "solve_worker_thread=" + _asterMaxSolveWorkerThreadId,
                    "keyboard_hook_present=" + (_keyboardHook != null),
                    "vtk_present=" + (_vtk != null),
                    "results_present=" + (_axEmbeddedResults != null),
                    "results_visible=" + (_axEmbeddedResults != null && _axEmbeddedResults.Visible),
                    "active_form=" + (Form.ActiveForm == null ? "<null>" : (Form.ActiveForm.Text ?? "").Replace("|", "/")),
                    "closing_cancel=" + (closingArgs == null ? "<null>" : closingArgs.Cancel.ToString()),
                    "close_reason=" + (closingArgs == null ? "<null>" : closingArgs.CloseReason.ToString()),
                    "forms=" + forms
                });
                File.AppendAllText(Path.Combine(directory, "audit-shutdown-trace.log"), line + Environment.NewLine);
            }
            catch (Exception ex)
            {
                try { File.AppendAllText(Path.Combine(directory, "audit-shutdown-trace-errors.log"), ex + Environment.NewLine); }
                catch { }
            }
        }

        private void C10209TraceUnhandled(string directory, string source, Exception exception)
        {
            try
            {
                File.AppendAllText(Path.Combine(directory, "audit-unhandled-exception.log"),
                    DateTime.UtcNow.ToString("O") + "|" + source + "|" +
                    (exception == null ? "<non-Exception>" : exception.ToString()) + Environment.NewLine);
            }
            catch { }
            C10209TraceShutdown(directory, "unhandled." + source);
        }
        private void C1020RequestAuditExit(string directory, int exitCode)
        {
            _c10209AuditShutdownDirectory = directory;
            C10209TraceShutdown(directory, "C1020RequestAuditExit.enter");
            try
            {
                File.WriteAllText(Path.Combine(directory, "audit-exit-request.json"),
                    new JObject {
                        ["requested_exit_code"] = exitCode,
                        ["requested_utc"] = DateTime.UtcNow.ToString("O"),
                        ["deferred_until_callback_unwinds"] = true
                    }.ToString(Formatting.Indented));
            }
            catch { }

            Environment.ExitCode = exitCode;
            C10209TraceShutdown(directory, "C1020RequestAuditExit.before_begininvoke");
            Application.ThreadException += (sender,args) =>
                C10209TraceUnhandled(directory, "Application.ThreadException", args == null ? null : args.Exception);
            AppDomain.CurrentDomain.UnhandledException += (sender,args) =>
                C10209TraceUnhandled(directory, "AppDomain.UnhandledException", args == null ? null : args.ExceptionObject as Exception);
            FormClosed += (sender,args) => C10209TraceShutdown(directory, "FormClosed");
            Application.ApplicationExit += (sender,args) => C10209TraceShutdown(directory, "ApplicationExit");
            BeginInvoke(new Action(() =>
            {
                C10209TraceShutdown(directory, "C1020RequestAuditExit.begininvoke_delegate.enter");
                try
                {
                    _asterMaxUiAuditMode = false;
                    if (_controller != null) _controller.ModelChanged = false;
                    C10209TraceShutdown(directory, "C1020RequestAuditExit.before_close");
                    Close();
                    C10209TraceShutdown(directory, "C1020RequestAuditExit.after_close_return");
                }
                catch (Exception ex)
                {
                    try
                    {
                        File.WriteAllText(Path.Combine(directory, "audit-close-error.txt"), ex.ToString());
                    }
                    catch { }
                    if (Environment.ExitCode == 0) Environment.ExitCode = 2;
                    Application.ExitThread();
                }
                finally
                {
                    C10209TraceShutdown(directory, "C1020RequestAuditExit.begininvoke_delegate.exit");
                }
            }));
            C10209TraceShutdown(directory, "C1020RequestAuditExit.exit");
        }
        private async Task ExecuteAsterMaxC1020WorkflowConformanceAudit(string directory)
        {
            var rows = new JArray();
            var commandSmoke = new JArray();
            var previousStates = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            C1020RevealOutlineNode("ax-model");
            C1020CaptureStage(directory, rows, previousStates, 1, "geometry", "Geometry", "geometry",
                () => C1020State("geometry") >= 2,
                "Imported B01 STEP visible; geometry workflow state >= 2.");

            FeModel model = _controller.Model;
            C10208RecordCommandSmoke(directory, commandSmoke,
                C10208SmokeEditorCommand("Model", "Materials", _frmMaterial, () => model.Materials.Count));
            if (model.Materials.Count == 0)
            {
                var material = new Material("Steel");
                material.AddProperty(new Elastic(new[] { new[] { 210000.0, 0.3, 20.0 } }));
                model.Materials.Add(material.Name, material);
            }
            RegenerateTree();
            _modelTree.RefreshAsterMaxOutline();
            C1020SelectOutlineNodeByText("Materials");
            C1020CaptureStage(directory, rows, previousStates, 2, "materials", "Materials", "materials",
                () => C1020State("materials") == 2,
                "One active valid linear-elastic steel material; materials state == 2.");

            C1020RevealOutlineNode("ax-coordinates");
            C1020CaptureStage(directory, rows, previousStates, 3, "coordinate-systems", "Coordinate Systems", "ax-coordinates",
                () => C1020State("ax-coordinates") >= 1 && C1020OutlineContainsText("Global Cartesian"),
                "Global Cartesian node observable; coordinate-systems state >= 1.");

            C1020RevealOutlineNode("ax-connections");
            C1020CaptureStage(directory, rows, previousStates, 4, "connections", "Connections", "ax-connections",
                () => C1020State("ax-connections") >= 1,
                "Connections branch observable for continuous single-body B01; no contact required.");

            C10208RecordCommandSmoke(directory, commandSmoke,
                C10208SmokeEditorCommand("Mesh", "Mesh Controls", _frmMeshingParameters,
                    () => _controller.GetMeshingParameters().Length));
            if (StrictNativeChain)
            {
                var parts = _controller.GetGeometryPartsWithoutSubParts();
                if (parts == null || parts.Length != 1) throw new InvalidOperationException("Strict B01 needs one imported body.");
                var parameters = _controller.GetPartDefaultMeshingParameters(parts[0].Name);
                parameters.Name = "Strict_B01_TETRA4";
                parameters.SecondOrder = false;
                parameters.MaxH = 2.0;
                parameters.MinH = 0.5;
                parameters.CreationIds = new[] { FeMesh.GetGeometryId(0, (int)GeometryType.Part, parts[0].PartId) };
                model.Geometry.MeshingParameters.Clear();
                model.Geometry.MeshingParameters.Add(parameters.Name, parameters);
            }
            JObject nativeMeshDiagnostic = await C10208ExerciseRealGenerateMesh(directory, model);
            C10208RecordCommandSmoke(directory, commandSmoke, nativeMeshDiagnostic);
            if (StrictNativeChain)
            {
                await ExecuteStrictNativeChain(directory, model, nativeMeshDiagnostic);
                return; // never enter the legacy synthetic replacement path
            }
            C10208RecordCommandSmoke(directory, commandSmoke,
                C10208SmokeEditorCommand("Materiales", "Asignar seccion", _frmSection, () => model.Sections.Count));

            // The real Generate Mesh smoke proves the native command path. Replace that
            // non-deterministic tetra mesh with the controlled HE8 B01 solver fixture.
            C1020PopulateB01Mesh(model);
            RegenerateTree();
            _modelTree.RefreshAsterMaxOutline();
            C1020RevealOutlineNode("ax-mesh");
            C1020CaptureStage(directory, rows, previousStates, 5, "mesh", "Mesh", "ax-mesh",
                () => C1020State("ax-mesh") == 2 && C1020State("assignments") == 2,
                "B01 native mesh and material assignment complete; ax-mesh == 2 and assignments == 2.");

            C1020PopulateB01NamedSelections(model);
            RegenerateTree();
            _modelTree.RefreshAsterMaxOutline();
            C1020RevealOutlineNode("ax-selections");
            C1020CaptureStage(directory, rows, previousStates, 6, "named-selections", "Named Selections", "ax-selections",
                () => C1020State("ax-selections") >= 1 &&
                      model.Mesh.NodeSets.ContainsKey("FIXED") && model.Mesh.NodeSets.ContainsKey("LOAD"),
                "FIXED and LOAD native node sets observable; named-selection state >= 1.");

            C10208RecordCommandSmoke(directory, commandSmoke,
                C10208SmokeEditorCommand("Environment", "Analysis Step", _frmStep,
                    () => model.StepCollection.StepsList.Count));
            C1020PopulateB01StaticStructural(model);
            RegenerateTree();
            _modelTree.RefreshAsterMaxOutline();
            C10208RecordCommandSmoke(directory, commandSmoke,
                C10208SmokeEditorCommand("Environment", "Supports", _frmBoundaryCondition,
                    () => model.StepCollection.StepsList.Sum(s => s.BoundaryConditions.Count)));
            C10208RecordCommandSmoke(directory, commandSmoke,
                C10208SmokeEditorCommand("Environment", "Loads", _frmLoad,
                    () => model.StepCollection.StepsList.Sum(s => s.Loads.Count)));
            C1020RevealOutlineNode("ax-analysis");
            C1020CaptureStage(directory, rows, previousStates, 7, "static-structural", "Static Structural", "ax-analysis",
                () => C1020State("ax-analysis") == 2 && C1020State("supports") == 2 &&
                      C1020State("loads") == 2 && C1020State("ax-model") == 2,
                "One active linear static study with fixed support and 10000 N total axial load (4 x 2500 N CLoad per node); model state == 2.");

            string pmxPath = Path.Combine(directory, "B01-C10.20.8.pmx");
            JObject pmxCycles = C1020ExercisePmxCycles(pmxPath, 3);
            File.WriteAllText(Path.Combine(directory, "pmx-save-reopen.json"), pmxCycles.ToString(Formatting.Indented));
            if (!(bool)pmxCycles["pass"])
                throw new InvalidOperationException("PMX save/reopen conformance failed: " + (string)pmxCycles["reason"]);

            model = _controller.Model;
            C1020RevealOutlineNode("ax-solution");
            C1020ClickRibbonButton("Solve");
            RunAsterMaxNativeSolve(); // second request must be rejected while the first solve is active
            C1020WaitForSolveCompletion(600);
            Application.DoEvents();
            C1020CaptureStage(directory, rows, previousStates, 8, "solution", "Solution", "ax-solution",
                () => _asterMaxSolveTransaction != null &&
                      String.Equals(_asterMaxSolveTransaction.State.ToString(), "SolutionCurrent", StringComparison.Ordinal) &&
                      _asterMaxLoadedResults != null,
                "Native Solve command completed with SolutionCurrent and a real results bundle loaded.");

            string resultField = _asterMaxLoadedResults.AvailableFields()
                .FirstOrDefault(x => x.IndexOf("Equivalent", StringComparison.OrdinalIgnoreCase) >= 0) ??
                _asterMaxLoadedResults.AvailableFields().FirstOrDefault();
            if (String.IsNullOrWhiteSpace(resultField))
                throw new InvalidOperationException("No real result field is available after native solve.");
            _modelTree.SelectAsterMaxResultField(resultField);
            Application.DoEvents();
            foreach (string command in new[] { "Contours", "Deformed" })
                C10208RecordCommandSmoke(directory, commandSmoke, C10208SmokeResultCommand("Results", command));
            foreach (string command in new[] { "Fit", "Isometric" })
                C10208RecordCommandSmoke(directory, commandSmoke, C10208SmokeResultCommand("View", command));
            C1020CaptureStage(directory, rows, previousStates, 9, "results", "Results", "results",
                () => C1020ResultState() == 2 && _axEmbeddedResults != null && _axEmbeddedResults.Visible &&
                      _axEmbeddedResults.LastRenderError == null && !_axEmbeddedResults.LastRenderSkipped,
                "A real result field is rendered in the integrated native viewport without stale/skipped render state.");
            string solvedProject=Path.Combine(directory,"B01-C10.41-solved.pmx");
            _controller.SaveToPmx(solvedProject);
            if(!File.Exists(AsterMaxProjectResultsStore.ManifestPath(solvedProject)))
                throw new IOException("Solved project result sidecar was not saved.");
            File.WriteAllText(Path.Combine(directory,"solved-project-save.json"),new JObject {
                ["status"]="PASS", ["project"]=solvedProject,
                ["bundle_sha256"]=AsterMaxProjectResultsStore.Hash(_asterMaxLoadedResults.SourceFile),
                ["model_fingerprint_sha256"]=_asterMaxLoadedResults.ResultModelFingerprintSha256
            }.ToString());

            File.WriteAllText(Path.Combine(directory, "workflow-conformance-session.json"),
                new JObject {
                    ["release"] = "C10.20.8",
                    ["pass"] = rows.All(x => String.Equals((string)x["status"], "PASS", StringComparison.Ordinal)),
                    ["historical_pending_closed"] = false,
                    ["reference_fixture"] = "B01_PARAMETRIC_STEP_100x10x10_mm",
                    ["solver"] = "native Windows Code_Aster",
                    ["fea_values_invented"] = false,
                    ["command_execution_smoke"] = commandSmoke,
                    ["rows"] = rows,
                    ["pmx_cycles"] = pmxCycles,
                    ["note"] = "Raw mandatory-stage session only. Cross-cutting checks are added by Phase 1.3 before the historical pending can be considered closed."
                }.ToString(Formatting.Indented));
        }

        private void C1020WaitForSolveCompletion(int timeoutSeconds)
        {
            DateTime deadline=DateTime.UtcNow.AddSeconds(timeoutSeconds);
            while(_asterMaxSolveInProgress && DateTime.UtcNow<deadline)
            {
                Application.DoEvents();
                System.Threading.Thread.Sleep(25);
            }
            if(_asterMaxSolveInProgress)
                throw new TimeoutException("Native background Solve did not complete within "+timeoutSeconds+" seconds.");
            if(_asterMaxSolveLastError!=null)
                throw new InvalidOperationException("Native background Solve failed.",_asterMaxSolveLastError);
        }
        private int C1020State(string key)
        {
            var states = BuildAsterMaxSectionStates();
            AsterMaxSectionState state;
            return states.TryGetValue(key, out state) ? state.State : 0;
        }

        private int C1020ResultState()
        {
            if (_asterMaxLoadedResults == null || _asterMaxSolveTransaction == null) return 0;
            if (!String.Equals(_asterMaxSolveTransaction.State.ToString(), "SolutionCurrent", StringComparison.Ordinal)) return 1;
            if (_axEmbeddedResults == null || !_axEmbeddedResults.Visible ||
                _axEmbeddedResults.LastRenderError != null || _axEmbeddedResults.LastRenderSkipped) return 1;
            return 2;
        }

        private JObject C1020StateSnapshot()
        {
            var result = new JObject();
            foreach (var entry in BuildAsterMaxSectionStates())
                result[entry.Key] = new JObject { ["state"] = entry.Value.State, ["message"] = entry.Value.Message };
            int resultsState = C1020ResultState();
            result["results"] = new JObject {
                ["state"] = resultsState,
                ["message"] = resultsState == 2 ? "Current integrated real results are rendered." :
                    _asterMaxLoadedResults == null ? "No results bundle loaded." : "Results exist but are not current/rendered."
            };
            return result;
        }

        private void C1020CaptureStage(string directory, JArray rows, Dictionary<string, int> previousStates,
                                       int index, string id, string label, string stateKey,
                                       Func<bool> postcondition, string expected)
        {
            string prefix = String.Format("stage-{0:00}-{1}", index, id);
            string screenshot = Path.Combine(directory, prefix + ".png");
            string treePath = Path.Combine(directory, prefix + "-tree.json");
            string statePath = Path.Combine(directory, prefix + "-state.json");
            string transitionPath = Path.Combine(directory, prefix + "-transition.json");
            int before;
            if (!previousStates.TryGetValue(stateKey, out before)) before = -1;
            bool predicate = false;
            string error = null;
            try { predicate = postcondition(); } catch (Exception ex) { error = ex.Message; }

            JObject states = C1020StateSnapshot();
            int after = stateKey == "results" ? C1020ResultState() :
                states[stateKey] == null ? 0 : (int)states[stateKey]["state"];
            previousStates[stateKey] = after;

            File.WriteAllText(treePath, C1020SerializeOutline().ToString(Formatting.Indented));
            File.WriteAllText(statePath, states.ToString(Formatting.Indented));
            File.WriteAllText(transitionPath, new JObject {
                ["stage"] = id, ["expected"] = expected, ["before"] = before, ["after"] = after,
                ["postcondition_observed"] = predicate, ["error"] = error
            }.ToString(Formatting.Indented));
            try
            {
                using (var bitmap = new Bitmap(Math.Max(1, Width), Math.Max(1, Height)))
                {
                    DrawToBitmap(bitmap, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
                    bitmap.Save(screenshot, ImageFormat.Png);
                }
            }
            catch (Exception ex) { error = (error == null ? "" : error + "; ") + "screenshot: " + ex.Message; }

            bool evidence = File.Exists(screenshot) && File.Exists(treePath) && File.Exists(statePath) && File.Exists(transitionPath);
            string status = !evidence ? "NOT_EXERCISED" : predicate ? "PASS" : "FAIL";
            rows.Add(new JObject {
                ["stage"] = id, ["label"] = label, ["status"] = status,
                ["workflow_state_key"] = stateKey, ["before"] = before, ["after"] = after,
                ["expected"] = expected, ["error"] = error,
                ["evidence"] = new JArray(Path.GetFileName(screenshot), Path.GetFileName(treePath),
                    Path.GetFileName(statePath), Path.GetFileName(transitionPath))
            });
            File.WriteAllText(Path.Combine(directory, "workflow-conformance-session.json"),
                new JObject {
                    ["release"] = "C10.20.8",
                    ["pass"] = false,
                    ["partial"] = true,
                    ["historical_pending_closed"] = false,
                    ["reference_fixture"] = "B01_PARAMETRIC_STEP_100x10x10_mm",
                    ["fea_values_invented"] = false,
                    ["rows"] = rows
                }.ToString(Formatting.Indented));            if (status == "FAIL") throw new InvalidOperationException("C10.20 stage failed: " + id + ". " + expected);
        }

        private JObject C1020SerializeOutline()
        {
            TreeView tree = C1020FindControl<TreeView>(this, x => x.Name == "asterMaxOutline");
            var root = new JObject { ["control_found"] = tree != null, ["nodes"] = new JArray() };
            if (tree == null) return root;
            root["selected"] = tree.SelectedNode == null ? null : tree.SelectedNode.Name;
            var nodes = (JArray)root["nodes"];
            foreach (TreeNode node in tree.Nodes) nodes.Add(C1020NodeToJson(node));
            return root;
        }

        private static JObject C1020NodeToJson(TreeNode node)
        {
            var children = new JArray();
            foreach (TreeNode child in node.Nodes) children.Add(C1020NodeToJson(child));
            return new JObject {
                ["name"] = node.Name, ["text"] = node.Text, ["state_image_key"] = node.StateImageKey,
                ["expanded"] = node.IsExpanded, ["children"] = children
            };
        }

        private static T C1020FindControl<T>(Control root, Func<T, bool> predicate) where T : Control
        {
            T self = root as T;
            if (self != null && predicate(self)) return self;
            foreach (Control child in root.Controls)
            {
                T found = C1020FindControl<T>(child, predicate);
                if (found != null) return found;
            }
            return null;
        }

        private TreeNode C1020FindOutlineNode(string name)
        {
            TreeView tree = C1020FindControl<TreeView>(this, x => x.Name == "asterMaxOutline");
            if (tree == null) return null;
            TreeNode[] found = tree.Nodes.Find(name, true);
            return found.Length == 0 ? null : found[0];
        }

        private void C1020RevealOutlineNode(string name)
        {
            _modelTree.RefreshAsterMaxOutline();
            TreeView tree = C1020FindControl<TreeView>(this, x => x.Name == "asterMaxOutline");
            TreeNode node = C1020FindOutlineNode(name);
            if (tree == null || node == null)
                throw new InvalidOperationException("AsterMax Outline node missing: " + name);
            for (TreeNode parent = node.Parent; parent != null; parent = parent.Parent) parent.Expand();
            node.EnsureVisible();
            Application.DoEvents();
        }
        private void C1020SelectOutlineNode(string name)
        {
            _modelTree.RefreshAsterMaxOutline();
            TreeView tree = C1020FindControl<TreeView>(this, x => x.Name == "asterMaxOutline");
            TreeNode node = C1020FindOutlineNode(name);
            if (tree != null && node != null) { tree.SelectedNode = node; node.EnsureVisible(); Application.DoEvents(); }
        }

        private void C1020SelectOutlineNodeByText(string text)
        {
            _modelTree.RefreshAsterMaxOutline();
            TreeView tree = C1020FindControl<TreeView>(this, x => x.Name == "asterMaxOutline");
            if (tree == null) return;
            TreeNode node = C1020FindNodeByText(tree.Nodes, text);
            if (node != null) { tree.SelectedNode = node; node.EnsureVisible(); Application.DoEvents(); }
        }

        private static TreeNode C1020FindNodeByText(TreeNodeCollection nodes, string text)
        {
            foreach (TreeNode node in nodes)
            {
                if (String.Equals(AsterMaxSpanishChile.Translate(node.Text), AsterMaxSpanishChile.Translate(text), StringComparison.OrdinalIgnoreCase)) return node;
                TreeNode nested = C1020FindNodeByText(node.Nodes, text);
                if (nested != null) return nested;
            }
            return null;
        }

        private static TreeNode C1020FindNodeContainingText(TreeNodeCollection nodes, string text)
        {
            foreach (TreeNode node in nodes)
            {
                if (AsterMaxSpanishChile.Translate(node.Text ?? "").IndexOf(AsterMaxSpanishChile.Translate(text), StringComparison.OrdinalIgnoreCase) >= 0) return node;
                TreeNode nested = C1020FindNodeContainingText(node.Nodes, text);
                if (nested != null) return nested;
            }
            return null;
        }

        private bool C1020OutlineContainsText(string text)
        {
            TreeView tree = C1020FindControl<TreeView>(this, x => x.Name == "asterMaxOutline");
            return tree != null && C1020FindNodeContainingText(tree.Nodes, text) != null;
        }

        private void C10208RecordCommandSmoke(string directory,JArray rows,JObject row)
        {
            rows.Add(row);
            File.WriteAllText(Path.Combine(directory,"command-execution-smoke.json"),
                new JObject {
                    ["release"]="C10.20.8",
                    ["pass"]=rows.All(x => (bool?)x["pass"] == true),
                    ["commands"]=rows,
                    ["fea_values_invented"]=false
                }.ToString(Formatting.Indented));
            if((bool?)row["pass"]!=true)
                throw new InvalidOperationException("Functional command smoke failed: "+(string)row["command"]+
                    " | "+(string)row["evidence"]);
        }

        private JObject C10208SmokeEditorCommand(string tab,string caption,Form editor,Func<int> mutationCount)
        {
            if(editor==null) return new JObject {
                ["tab"]=tab,["command"]=caption,["pass"]=false,["evidence"]="Native editor form is null."
            };
            CloseAllForms();
            Application.DoEvents();
            int before=mutationCount();
            C10208ClickRibbonButton(tab,caption);
            DateTime deadline=DateTime.UtcNow.AddSeconds(5);
            while(!editor.Visible && DateTime.UtcNow<deadline)
            {
                Application.DoEvents();
                System.Threading.Thread.Sleep(25);
            }
            bool opened=editor.Visible;
            string title=editor.Text;
            CloseAllForms();
            Application.DoEvents();
            bool hidden=!editor.Visible;
            int after=mutationCount();
            bool pass=opened && hidden && before==after;
            return new JObject {
                ["tab"]=tab,["command"]=caption,["pass"]=pass,
                ["opened_native_editor"]=opened,["editor_hidden_without_accept"]=hidden,
                ["editor_type"]=editor.GetType().FullName,["editor_title"]=title,
                ["model_count_before"]=before,["model_count_after"]=after,
                ["evidence"]=pass ? "Native editor opened and was dismissed without mutating the fixture." :
                    "Editor did not open/hide correctly or the model changed during a non-destructive smoke."
            };
        }

        private async Task<JObject> C10208ExerciseRealGenerateMesh(string directory,FeModel model)
        {
            CloseAllForms();
            Application.DoEvents();
            _controller.CurrentView=ViewGeometryModelResults.Geometry;

            var candidates=_controller.GetGeometryPartsWithoutSubParts();
            string[] candidateNames=candidates==null ? new string[0] : candidates.Select(x => x.Name).ToArray();
            string[] candidateTypes=candidates==null ? new string[0] : candidates.Select(x => x.GetType().FullName).ToArray();
            int geometryParts=model.Geometry==null?0:model.Geometry.Parts.Count;
            int meshingParameterCount=_controller.GetMeshingParameters()==null?0:_controller.GetMeshingParameters().Length;
            int nodesBefore=model.Mesh==null?0:model.Mesh.Nodes.Count;
            int elementsBefore=model.Mesh==null?0:model.Mesh.Elements.Count;
            string baseDirectory=AppDomain.CurrentDomain.BaseDirectory;
            string netgenExe=Path.Combine(baseDirectory,"NetGen","NetGenMesher.exe");
            string workDirectory=null;
            try { workDirectory=_controller.Settings.GetWorkDirectory(); } catch { }

            File.WriteAllText(Path.Combine(directory,"mesh-command-preflight.json"),
                new JObject {
                    ["geometry_parts"]=geometryParts,
                    ["mesh_candidate_count"]=candidateNames.Length,
                    ["mesh_candidate_names"]=new JArray(candidateNames),
                    ["mesh_candidate_types"]=new JArray(candidateTypes),
                    ["meshing_parameter_count"]=meshingParameterCount,
                    ["base_directory"]=baseDirectory,
                    ["work_directory"]=workDirectory,
                    ["work_directory_present"]=!String.IsNullOrWhiteSpace(workDirectory) && Directory.Exists(workDirectory),
                    ["netgen_exe"]=netgenExe,
                    ["netgen_exe_present"]=File.Exists(netgenExe),
                    ["fea_values_invented"]=false
                }.ToString(Formatting.Indented));

            _controller.AsterMaxResetMeshAudit();
            var monotonic=System.Diagnostics.Stopwatch.StartNew();
            C10208ClickRibbonButton("Mesh","Generate Mesh");
            bool terminalObserved=await Task.Run(() => _controller.AsterMaxWaitMeshAudit(180000));

            // The controller terminal signal precedes CreatePartMeshes' UI continuation.
            // Let that continuation run its finally/SetStateReady before later commands.
            long readyDeadline=monotonic.ElapsedMilliseconds+5000;
            while(terminalObserved && IsStateWorking() && monotonic.ElapsedMilliseconds<readyDeadline)
                await Task.Delay(25);
            bool uiReadyObserved=terminalObserved && !IsStateWorking();
            monotonic.Stop();

            bool deadlineExpired=!terminalObserved;
            int ribbonNodesAfter=model.Mesh==null?0:model.Mesh.Nodes.Count;
            int ribbonElementsAfter=model.Mesh==null?0:model.Mesh.Elements.Count;
            bool ribbonProducedMesh=ribbonNodesAfter>nodesBefore && ribbonElementsAfter>elementsBefore;
            string terminalJobStatus=_controller.AsterMaxLastMeshJobStatus;
            int? processExitCode=_controller.AsterMaxLastMeshExitCode;
            int? brepExitCode=_controller.AsterMaxLastBrepExitCode;
            string route=_controller.AsterMaxLastMeshRoute;
            bool generationSucceeded=_controller.AsterMaxLastMeshGenerationSucceeded;
            bool importSucceeded=_controller.AsterMaxLastMeshImportSucceeded;
            string terminalError=_controller.AsterMaxLastMeshError;
            bool generationFailure=terminalObserved && !generationSucceeded;
            bool importFailure=terminalObserved && generationSucceeded && !importSucceeded;

            bool pass=geometryParts==1 && candidateNames.Length==1 && terminalObserved && !deadlineExpired &&
                      generationSucceeded && importSucceeded && ribbonProducedMesh && uiReadyObserved;
            JObject result=new JObject {
                ["tab"]="Mesh",["command"]="Generate Mesh",["pass"]=pass,
                ["geometry_parts"]=geometryParts,
                ["mesh_candidate_count"]=candidateNames.Length,
                ["mesh_candidate_names"]=new JArray(candidateNames),
                ["mesh_candidate_types"]=new JArray(candidateTypes),
                ["meshing_parameter_count"]=meshingParameterCount,
                ["deadline_expired"]=deadlineExpired,
                ["terminal_signal_observed"]=terminalObserved,
                ["ui_ready_observed"]=uiReadyObserved,
                ["ui_thread_released_during_wait"]=true,
                ["terminal_job_status"]=terminalJobStatus,
                ["process_exit_code"]=processExitCode,
                ["brep_process_exit_code"]=brepExitCode,
                ["mesh_route"]=route,
                ["duration_ms"]=monotonic.Elapsed.TotalMilliseconds,
                ["controller_duration_ms"]=_controller.AsterMaxLastMeshDurationMs,
                ["generation_succeeded"]=generationSucceeded,
                ["import_succeeded"]=importSucceeded,
                ["generation_failure"]=generationFailure,
                ["import_failure"]=importFailure,
                ["terminal_error"]=terminalError,
                ["nodes_before"]=nodesBefore,
                ["nodes_after"]=ribbonNodesAfter,
                ["elements_before"]=elementsBefore,
                ["elements_after"]=ribbonElementsAfter,
                ["mesh_created"]=ribbonProducedMesh,
                ["base_directory"]=baseDirectory,
                ["work_directory"]=workDirectory,
                ["work_directory_present"]=!String.IsNullOrWhiteSpace(workDirectory) && Directory.Exists(workDirectory),
                ["netgen_exe"]=netgenExe,
                ["netgen_exe_present"]=File.Exists(netgenExe),
                ["execution"]="REAL_NATIVE_GENERATE_MESH_RIBBON_COMMAND",
                ["synchronization"]="ASYNC_CONTROLLER_TERMINAL_SIGNAL",
                ["fixture_replacement_follows"]=!StrictNativeChain,
                ["evidence"]=pass ?
                    (StrictNativeChain ? "Native NetGen mesh retained for the strict solver/postprocess chain." : "Generate Mesh produced and imported a non-empty native mesh. This command smoke is distinct from the deterministic HE8 solver fixture that follows.") :
                    "Generate Mesh did not reach a verified terminal generation/import state; see explicit deadline/job/exit/route fields."
            };
            File.WriteAllText(Path.Combine(directory,"mesh-command-diagnostic.json"),result.ToString(Formatting.Indented));
            return result;
        }
        private JObject C10208SmokeResultCommand(string tab,string caption)
        {
            Exception failure=null;
            try
            {
                C10208ClickRibbonButton(tab,caption);
                Application.DoEvents();
            }
            catch(Exception ex){ failure=ex; }
            bool viewport=_axEmbeddedResults!=null && _axEmbeddedResults.Visible;
            bool renderOk=viewport && _axEmbeddedResults.LastRenderError==null && !_axEmbeddedResults.LastRenderSkipped;
            bool pass=failure==null && renderOk;
            return new JObject {
                ["tab"]=tab,["command"]=caption,["pass"]=pass,
                ["integrated_viewport_visible"]=viewport,["render_ok"]=renderOk,
                ["error"]=failure==null?null:failure.Message,
                ["evidence"]=pass ? "Command executed against the live integrated results viewport." :
                    "Result/view command failed or left the integrated renderer invalid."
            };
        }

        private static string C1033CommandLabel(string text)
        {
            switch(text)
            {
                case "Materials": return "Material";
                case "Mesh Controls": return "Controles";
                case "Analysis Step": return "Paso";
                case "Supports": return "Apoyo";
                case "Loads": return "Carga";
                case "Solve": return "Ejecutar";
                case "Fit": return "Ajustar";
                case "Isometric": return "Isométrica";
                default: return AsterMaxSpanishChile.Translate(text);
            }
        }
        private void C10208ClickRibbonButton(string tab,string caption)
        {
            var ribbon=Controls["asterMaxRibbon"] as TabControl;
            if(ribbon==null) throw new InvalidOperationException("AsterMax ribbon is missing.");
            TabPage page=ribbon.TabPages.Cast<TabPage>()
                .FirstOrDefault(x => String.Equals(x.Text,AsterMaxSpanishChile.Translate(tab),StringComparison.Ordinal));
            if(page==null) throw new InvalidOperationException("Ribbon tab not found: "+tab);
            Button button=AxButtons(page)
                .FirstOrDefault(x => String.Equals(x.Text,C1033CommandLabel(caption),StringComparison.Ordinal));
            if(button==null) throw new InvalidOperationException("Ribbon command not found: "+tab+"/"+caption);
            ribbon.SelectedTab=page;
            Application.DoEvents();
            button.PerformClick();
            Application.DoEvents();
        }
        private void C1020ClickRibbonButton(string caption)
        {
            var ribbon = Controls["asterMaxRibbon"] as TabControl;
            if (ribbon == null) throw new InvalidOperationException("AsterMax ribbon is missing.");
            foreach (TabPage page in ribbon.TabPages)
            {
                foreach (Button button in AxButtons(page))
                {
                    if (!String.Equals(button.Text, C1033CommandLabel(caption), StringComparison.Ordinal)) continue;
                    ribbon.SelectedTab = page;
                    Application.DoEvents();
                    button.PerformClick();
                    Application.DoEvents();
                    return;
                }
            }
            throw new InvalidOperationException("Ribbon command not found: " + caption);
        }

        private static int C1020NodeId(int plane, int corner)
        {
            return plane * 4 + corner + 1;
        }

        private static void C1020PopulateB01Mesh(FeModel model)
        {
            if (model.Mesh == null) throw new InvalidOperationException("Imported model has no native Mesh container.");
            model.Mesh.Nodes.Clear();
            model.Mesh.Elements.Clear();
            model.Mesh.Parts.Clear();
            model.Mesh.ElementSets.Clear();
            model.Mesh.NodeSets.Clear();
            int segments = 10;
            for (int i = 0; i <= segments; i++)
            {
                double x = 10.0 * i;
                model.Mesh.Nodes.Add(C1020NodeId(i, 0), new FeNode(C1020NodeId(i, 0), x, 0, 0));
                model.Mesh.Nodes.Add(C1020NodeId(i, 1), new FeNode(C1020NodeId(i, 1), x, 10, 0));
                model.Mesh.Nodes.Add(C1020NodeId(i, 2), new FeNode(C1020NodeId(i, 2), x, 0, 10));
                model.Mesh.Nodes.Add(C1020NodeId(i, 3), new FeNode(C1020NodeId(i, 3), x, 10, 10));
            }
            var elementIds = new List<int>();
            for (int i = 0; i < segments; i++)
            {
                int id = i + 1;
                int[] nodes = {
                    C1020NodeId(i,0), C1020NodeId(i+1,0), C1020NodeId(i+1,1), C1020NodeId(i,1),
                    C1020NodeId(i,2), C1020NodeId(i+1,2), C1020NodeId(i+1,3), C1020NodeId(i,3)
                };
                model.Mesh.Elements.Add(id, new LinearHexaElement(id, nodes));
                elementIds.Add(id);
            }
            int[] allNodes = model.Mesh.Nodes.Keys.OrderBy(x => x).ToArray();
            model.Mesh.Parts.Add("B01_Bar", new MeshPart("B01_Bar", 1, allNodes, elementIds.ToArray(), new[] { typeof(LinearHexaElement) }));
            model.Mesh.ElementSets.Add("ALL", new FeElementSet("ALL", elementIds.ToArray()));
            model.Sections.Clear();
            model.Sections.Add("B01_Steel", new SolidSection("B01_Steel", model.Materials.Keys.First(), "B01_Bar", RegionTypeEnum.PartName, 1, false));
        }

        private static void C1020PopulateB01NamedSelections(FeModel model)
        {
            int[] fixedNodes = Enumerable.Range(0, 4).Select(c => C1020NodeId(0, c)).ToArray();
            int[] loadNodes = Enumerable.Range(0, 4).Select(c => C1020NodeId(10, c)).ToArray();
            model.Mesh.NodeSets.Remove("FIXED");
            model.Mesh.NodeSets.Remove("LOAD");
            model.Mesh.NodeSets.Add("FIXED", new FeNodeSet("FIXED", fixedNodes));
            model.Mesh.NodeSets.Add("LOAD", new FeNodeSet("LOAD", loadNodes));
        }

        private static void C1020PopulateB01StaticStructural(FeModel model)
        {
            model.StepCollection.StepsList.Clear();
            var step = new StaticStep("Static_Structural");
            step.AddBoundaryCondition(new FixedBC("Fixed_Support", "FIXED", RegionTypeEnum.NodeSetName, false));
            step.AddLoad(new CLoad("Axial_Force", "LOAD", RegionTypeEnum.NodeSetName, 2500, 0, 0, false, false, 0));
            model.StepCollection.AddStep(step, false);
        }

        private JObject C1020ExercisePmxCycles(string path, int cycles)
        {
            var evidence = new JArray();
            try
            {
                MethodInfo save = typeof(Controller).GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                    .FirstOrDefault(m => m.Name == "SaveToPmx" && m.GetParameters().Length == 1 &&
                                         m.GetParameters()[0].ParameterType == typeof(string));
                MethodInfo open = typeof(Controller).GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                    .FirstOrDefault(m => m.Name == "Open" && m.GetParameters().Length == 1 &&
                                         m.GetParameters()[0].ParameterType == typeof(string));
                if (save == null || open == null)
                    return new JObject { ["pass"] = false, ["reason"] = "Controller SaveToPmx/Open(string) reflection target not found.", ["cycles"] = evidence };

                for (int i = 1; i <= cycles; i++)
                {
                    save.Invoke(_controller, new object[] { path });
                    if (!File.Exists(path)) throw new IOException("PMX file was not written.");
                    // Cycle 2 also checks recovery of the branded header written by older releases.
                    if (i == 2)
                    {
                        byte[] header = new byte[32];
                        System.Text.Encoding.ASCII.GetBytes("AsterMax Mechanical C10.10.1").CopyTo(header, 0);
                        using (var stream = new FileStream(path, FileMode.Open, FileAccess.Write))
                            stream.Write(header, 0, header.Length);
                    }
                    object result = open.Invoke(_controller, new object[] { path });
                    Task task = result as Task;
                    if (task != null) task.GetAwaiter().GetResult();
                    RegenerateTree();
                    _modelTree.RefreshAsterMaxOutline();
                    var states = BuildAsterMaxSectionStates();
                    bool survived = states["ax-model"].State == 2 && _controller.Model.Mesh.Nodes.Count == 44 &&
                                    _controller.Model.Mesh.Elements.Count == 10 &&
                                    _controller.Model.Mesh.NodeSets.ContainsKey("FIXED") &&
                                    _controller.Model.Mesh.NodeSets.ContainsKey("LOAD");
                    evidence.Add(new JObject {
                        ["cycle"] = i, ["file_bytes"] = new FileInfo(path).Length,
                        ["model_state"] = states["ax-model"].State,
                        ["nodes"] = _controller.Model.Mesh.Nodes.Count,
                        ["elements"] = _controller.Model.Mesh.Elements.Count,
                        ["survived"] = survived
                    });
                    if (!survived) return new JObject { ["pass"] = false, ["reason"] = "Model changed after PMX reopen.", ["cycles"] = evidence };
                }
                FeModel originalModel = _controller.Model;
                string corrupt = Path.Combine(Path.GetDirectoryName(path), "invalid.pmx");
                File.WriteAllBytes(corrupt, new byte[] { 1, 2, 3, 4 });
                bool rejected = false;
                try { open.Invoke(_controller, new object[] { corrupt }); }
                catch (TargetInvocationException) { rejected = true; }
                bool preserved = rejected && Object.ReferenceEquals(originalModel, _controller.Model) &&
                                 _controller.Model.Mesh.Nodes.Count == 44;
                if (!preserved) throw new InvalidOperationException("Invalid PMX replaced the active model.");
                return new JObject { ["pass"] = true, ["reason"] = "Three PMX cycles, legacy header recovery and invalid-file model preservation passed.",
                    ["invalid_file_preserved_model"] = preserved, ["legacy_header_reopened"] = true, ["cycles"] = evidence };
            }
            catch (TargetInvocationException ex)
            {
                Exception inner = ex.InnerException ?? ex;
                return new JObject { ["pass"] = false, ["reason"] = inner.ToString(), ["cycles"] = evidence };
            }
            catch (Exception ex)
            {
                return new JObject { ["pass"] = false, ["reason"] = ex.ToString(), ["cycles"] = evidence };
            }
        }
    }
}








