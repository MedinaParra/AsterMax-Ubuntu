using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using CaeModel;
using CaeGlobals;
using CaeMesh;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PrePoMax
{
    public partial class FrmMain
    {
        private void StartAsterMaxC1035DefaultsAudit()
        {
            string directory=Environment.GetEnvironmentVariable("ASTERMAX_C1035_AUDIT_DIR");
            if(String.IsNullOrWhiteSpace(directory)) return;
            Directory.CreateDirectory(directory);

            int ticks=0;
            var timer=new Timer { Interval=1000 };
            timer.Tick += (s,e) =>
            {
                ticks++;
                bool geometryReady=_controller!=null && _controller.Model!=null &&
                                   _controller.Model.Geometry!=null &&
                                   _controller.Model.Geometry.Parts.Count>=2 &&
                                   !IsStateWorking();
                bool automaticMaterialReady=geometryReady &&
                    _controller.Model.Materials.ContainsKey(Controller.AsterMaxDefaultMaterialName);

                // The command-line import continuation assigns the default material
                // after ImportFileAsync returns. Give that continuation a bounded
                // grace window, but never manufacture the PASS inside the audit.
                if((!geometryReady || !automaticMaterialReady) && ticks<15) return;
                bool ready=geometryReady && automaticMaterialReady;
                if(!ready && ticks<90 && !geometryReady) return;

                timer.Stop();
                timer.Dispose();
                bool pass=false;
                JObject report=new JObject {
                    ["release"]="C10.35",
                    ["fixture"]="two touching solid boxes imported from STEP",
                    ["fea_values_invented"]=false
                };

                try
                {
                    if(!geometryReady) throw new InvalidOperationException("Two-body STEP import did not complete within the audit window.");
                    if(!automaticMaterialReady) throw new InvalidOperationException("Default structural steel was not assigned automatically after STEP import.");

                    FeModel model=_controller.Model;
                    report["geometry_parts_before_mesh"]=model.Geometry.Parts.Count;
                    report["materials_after_import"]=new JArray(model.Materials.Keys);
                    report["default_material_after_import"]=model.Materials.ContainsKey(Controller.AsterMaxDefaultMaterialName);
                    report["automatic_material_import_gate"]="PASS";

                    var candidates=_controller.GetGeometryPartsWithoutSubParts();
                    string[] partNames=candidates==null ? new string[0] : candidates.Select(x=>x.Name).ToArray();
                    report["mesh_candidates"]=new JArray(partNames);
                    if(partNames.Length<2) throw new InvalidOperationException("Expected at least two independent solid mesh candidates.");

                    var meshRows=new JArray();
                    foreach(string partName in partNames)
                    {
                        int nodesBefore=model.Mesh==null ? 0 : model.Mesh.Nodes.Count;
                        int elementsBefore=model.Mesh==null ? 0 : model.Mesh.Elements.Count;
                        bool returned=_controller.CreateMesh(partName);
                        int nodesAfter=model.Mesh==null ? 0 : model.Mesh.Nodes.Count;
                        int elementsAfter=model.Mesh==null ? 0 : model.Mesh.Elements.Count;
                        bool produced=returned && nodesAfter>nodesBefore && elementsAfter>elementsBefore;
                        meshRows.Add(new JObject {
                            ["part"]=partName,
                            ["create_mesh_returned"]=returned,
                            ["nodes_before"]=nodesBefore,
                            ["nodes_after"]=nodesAfter,
                            ["elements_before"]=elementsBefore,
                            ["elements_after"]=elementsAfter,
                            ["produced_mesh"]=produced
                        });
                        if(!produced) throw new InvalidOperationException("Native meshing did not produce elements for part: "+partName);
                    }
                    report["meshing"]=meshRows;

                    _controller.AsterMaxEnsureDefaultMaterialAndSections();
                    AsterMaxAutoGenerateContacts();
                    RegenerateTree();
                    _modelTree.RefreshAsterMaxOutline();
                    Application.DoEvents();

                    model=_controller.Model;
                    string materialName=Controller.AsterMaxDefaultMaterialName;
                    bool hasDefault=model.Materials.ContainsKey(materialName);

                    var solidParts=model.Mesh.Parts
                        .Where(x=>x.Value!=null && x.Value.PartType==PartType.Solid)
                        .Select(x=>x.Key).ToArray();

                    var assigned=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    var sectionRows=new JArray();
                    foreach(var entry in model.Sections)
                    {
                        Section section=entry.Value;
                        if(section==null) continue;
                        bool isDefault=String.Equals(section.MaterialName,materialName,StringComparison.OrdinalIgnoreCase);
                        if(isDefault && section.RegionType==RegionTypeEnum.PartName && !String.IsNullOrWhiteSpace(section.RegionName))
                            assigned.Add(section.RegionName);
                        sectionRows.Add(new JObject {
                            ["name"]=entry.Key,
                            ["material"]=section.MaterialName,
                            ["region"]=section.RegionName,
                            ["region_type"]=section.RegionType.ToString()
                        });
                    }

                    string[] contactNames=_controller.GetContactPairNames();
                    var contactRows=new JArray();
                    bool contactsValid=contactNames.Length>0;
                    foreach(string name in contactNames)
                    {
                        ContactPair cp=_controller.GetContactPair(name);
                        bool interactionOk=cp!=null && model.SurfaceInteractions.ContainsKey(cp.SurfaceInteractionName);
                        bool masterOk=cp!=null && model.Mesh.Surfaces.ContainsKey(cp.MasterRegionName);
                        bool slaveOk=cp!=null && model.Mesh.Surfaces.ContainsKey(cp.SlaveRegionName);
                        bool colorsOk=cp!=null && cp.MasterColor.ToArgb()==System.Drawing.Color.Red.ToArgb() &&
                                      cp.SlaveColor.ToArgb()==System.Drawing.Color.RoyalBlue.ToArgb();
                        contactsValid &= cp!=null && interactionOk && masterOk && slaveOk && colorsOk;
                        contactRows.Add(new JObject {
                            ["name"]=name,
                            ["interaction"]=cp==null ? null : cp.SurfaceInteractionName,
                            ["master_surface"]=cp==null ? null : cp.MasterRegionName,
                            ["slave_surface"]=cp==null ? null : cp.SlaveRegionName,
                            ["interaction_valid"]=interactionOk,
                            ["master_surface_valid"]=masterOk,
                            ["slave_surface_valid"]=slaveOk,
                            ["master_red_slave_blue"]=colorsOk
                        });
                    }

                    bool everySolidAssigned=solidParts.Length>=2 && solidParts.All(x=>assigned.Contains(x));
                    bool libraryPresent=File.Exists(Path.Combine(Application.StartupPath,Globals.MaterialLibraryFileName));

                    report["mesh_part_count"]=model.Mesh.Parts.Count;
                    report["solid_parts"]=new JArray(solidParts);
                    report["default_material_name"]=materialName;
                    report["default_material_present"]=hasDefault;
                    report["sections"]=sectionRows;
                    report["all_solid_parts_assigned_default_material"]=everySolidAssigned;
                    report["material_library_present_next_to_exe"]=libraryPresent;
                    report["material_library_file"]=Globals.MaterialLibraryFileName;
                    report["contact_pair_count"]=contactNames.Length;
                    report["contacts"]=contactRows;
                    report["contact_generator_runtime_pass"]=contactsValid;

                    if(!model.StepCollection.StepsList.Any(x=>!(x is InitialStep)))
                        model.StepCollection.AddStep(new StaticStep("ContactAudit"), false);
                    foreach(string contactName in contactNames)
                    {
                        ContactPair frictionPair=_controller.GetContactPair(contactName);
                        if(frictionPair==null) continue;
                        SurfaceInteraction frictionInteraction;
                        if(!model.SurfaceInteractions.TryGetValue(frictionPair.SurfaceInteractionName,out frictionInteraction) || frictionInteraction==null)
                            throw new InvalidOperationException("C10.37 audit contact interaction missing: "+frictionPair.SurfaceInteractionName);
                        if(frictionInteraction.Properties==null || !frictionInteraction.Properties.Any(x=>x is Friction))
                            frictionInteraction.AddProperty(new Friction(0.20));
                    }
                    StaticStep liveStep=model.StepCollection.StepsList.OfType<StaticStep>().FirstOrDefault();
                    if(liveStep==null) throw new InvalidOperationException("C10.38 audit static step missing.");

                    double xmin=model.Mesh.Nodes.Values.Min(n=>n.X);
                    double xmax=model.Mesh.Nodes.Values.Max(n=>n.X);
                    double span=Math.Max(1.0,Math.Abs(xmax-xmin));
                    double faceTol=Math.Max(1e-8,span*1e-8);
                    int[] fixedIds=model.Mesh.Nodes.Values.Where(n=>Math.Abs(n.X-xmin)<=faceTol).Select(n=>n.Id).OrderBy(x=>x).ToArray();
                    int[] loadIds=model.Mesh.Nodes.Values.Where(n=>Math.Abs(n.X-xmax)<=faceTol).Select(n=>n.Id).OrderBy(x=>x).ToArray();
                    if(fixedIds.Length==0 || loadIds.Length==0) throw new InvalidOperationException("C10.38 could not form deterministic end-face node sets.");

                    if(!model.Mesh.NodeSets.ContainsKey("C1038_FIXED"))
                        model.Mesh.AddNodeSet(new FeNodeSet("C1038_FIXED",fixedIds));
                    if(!model.Mesh.NodeSets.ContainsKey("C1038_LOAD"))
                        model.Mesh.AddNodeSet(new FeNodeSet("C1038_LOAD",loadIds));

                    if(!liveStep.BoundaryConditions.ContainsKey("C1038_Fixed"))
                    {
                        if(!liveStep.AddBoundaryCondition(new FixedBC("C1038_Fixed","C1038_FIXED",RegionTypeEnum.NodeSetName,false)))
                            throw new InvalidOperationException("C10.38 FixedBC was rejected by StaticStep.");
                    }
                    if(!liveStep.BoundaryConditions.ContainsKey("C1038_Directional"))
                    {
                        DisplacementRotation directional=new DisplacementRotation("C1038_Directional","C1038_LOAD",RegionTypeEnum.NodeSetName,false,false,0);
                        directional.U2=0.0;
                        directional.U3=0.0;
                        if(!liveStep.AddBoundaryCondition(directional))
                            throw new InvalidOperationException("C10.38 DisplacementRotation was rejected by StaticStep.");
                    }
                    if(!liveStep.Loads.ContainsKey("C1038_Force"))
                    {
                        double fxPerNode=-1000.0/loadIds.Length;
                        double fzPerNode=100.0/loadIds.Length;
                        CLoad liveLoad=new CLoad("C1038_Force","C1038_LOAD",RegionTypeEnum.NodeSetName,fxPerNode,0.0,fzPerNode,false,false,0);
                        if(!liveStep.AddLoad(liveLoad))
                            throw new InvalidOperationException("C10.38 CLoad was rejected by StaticStep.");
                    }

                    int[] gravityElementIds=model.Mesh.Elements.Keys.OrderBy(x=>x).ToArray();
                    if(gravityElementIds.Length==0) throw new InvalidOperationException("C10.39 gravity audit has no FE elements.");
                    if(!model.Mesh.ElementSets.ContainsKey("C1039_ALL_VOLUME"))
                        model.Mesh.AddElementSet(new FeElementSet("C1039_ALL_VOLUME",gravityElementIds));
                    if(!liveStep.Loads.ContainsKey("C1039_Gravity"))
                    {
                        GravityLoad liveGravity=new GravityLoad("C1039_Gravity","C1039_ALL_VOLUME",RegionTypeEnum.ElementSetName,
                                                               0.0,-9810.0,0.0,false,false,0);
                        if(!liveStep.AddLoad(liveGravity))
                            throw new InvalidOperationException("C10.39 GravityLoad was rejected by StaticStep.");
                    }

                    JObject solverContract=AsterMaxModelContractBridge.Build(model);
                    JArray solverContacts=(JArray)solverContract["contacts"];
                    bool contractOk=solverContacts!=null && solverContacts.Count==contactNames.Length;
                    int skinElementCount=0;
                    if(contractOk)
                    {
                        foreach(JObject sc in solverContacts.Cast<JObject>())
                        {
                            JArray me=(JArray)sc["master"]?["elements"];
                            JArray se=(JArray)sc["slave"]?["elements"];
                            if(me==null || se==null || me.Count==0 || se.Count==0) contractOk=false;
                            skinElementCount+=(me==null?0:me.Count)+(se==null?0:se.Count);
                        }
                    }
                    bool coulombContract=solverContacts!=null && solverContacts.Count>0 &&
                        solverContacts.Cast<JObject>().All(x =>
                            String.Equals((string)x["friction"],"COULOMB",StringComparison.OrdinalIgnoreCase) &&
                            Math.Abs(((double?)x["friction_coefficient"] ?? 0.0)-0.20)<1e-12);
                    contractOk &= coulombContract;
                    const int stressPairs=30;
                    const int stressFacesPerSurface=12050;
                    HashSet<string> stressIds=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    bool skinIdStressPass=true;
                    int stressGenerated=0;
                    for(int ci=1;ci<=stressPairs && skinIdStressPass;ci++)
                    {
                        foreach(string role in new [] { "M", "S" })
                        {
                            for(int fi=1;fi<=stressFacesPerSurface;fi++)
                            {
                                string skinId=AsterMaxModelContractBridge.CodeAsterSkinElementId(role,ci,fi);
                                stressGenerated++;
                                if(skinId.Length>8 || !stressIds.Add(skinId))
                                {
                                    skinIdStressPass=false;
                                    break;
                                }
                            }
                            if(!skinIdStressPass) break;
                        }
                    }
                    string legacyFace1000="M001"+1000.ToString("0000");
                    string legacyFace10000="M001"+10000.ToString("0000");
                    bool legacyCollisionReproduced=legacyFace1000.Length==8 && legacyFace10000.Length>8 &&
                        legacyFace10000.Substring(0,8)==legacyFace1000;
                    string fixedFace1000=AsterMaxModelContractBridge.CodeAsterSkinElementId("M",1,1000);
                    string fixedFace10000=AsterMaxModelContractBridge.CodeAsterSkinElementId("M",1,10000);
                    bool boundaryPass=fixedFace1000.Length==8 && fixedFace10000.Length==8 &&
                        !String.Equals(fixedFace1000,fixedFace10000,StringComparison.OrdinalIgnoreCase);
                    skinIdStressPass &= legacyCollisionReproduced && boundaryPass;
                    contractOk &= skinIdStressPass;
                    report["codeaster_contact_contract_pass"]=contractOk;
                    report["codeaster_skin_id_stress_pass"]=skinIdStressPass;
                    report["codeaster_skin_id_legacy_collision_reproduced"]=legacyCollisionReproduced;
                    report["codeaster_skin_id_stress_pairs"]=stressPairs;
                    report["codeaster_skin_id_stress_faces_per_surface"]=stressFacesPerSurface;
                    report["codeaster_skin_id_stress_generated"]=stressGenerated;
                    report["codeaster_skin_id_boundary_face_1000"]=fixedFace1000;
                    report["codeaster_skin_id_boundary_face_10000"]=fixedFace10000;
                    report["codeaster_coulomb_contract_pass"]=coulombContract;
                    report["codeaster_coulomb_mu"]=0.20;
                    JArray solverSupports=(JArray)solverContract["supports"];
                    JArray solverLoads=(JArray)solverContract["loads"];
                    JObject directionalContract=solverSupports==null ? null : solverSupports.Cast<JObject>()
                        .FirstOrDefault(x=>String.Equals((string)x["name"],"C1038_Directional",StringComparison.Ordinal));
                    bool directionalBcContract=solverSupports!=null && solverSupports.Count==2 &&
                        directionalContract!=null &&
                        String.Equals((string)directionalContract["type"],"displacement",StringComparison.OrdinalIgnoreCase) &&
                        directionalContract["dx"]!=null && directionalContract["dx"].Type==JTokenType.Null &&
                        Math.Abs(((double?)directionalContract["dy"] ?? Double.NaN)-0.0)<1e-12 &&
                        Math.Abs(((double?)directionalContract["dz"] ?? Double.NaN)-0.0)<1e-12;
                    JObject realLoad=solverLoads==null ? null : solverLoads.Cast<JObject>()
                        .FirstOrDefault(x=>String.Equals((string)x["name"],"C1038_Force",StringComparison.Ordinal));
                    double expectedFxPerNode=-1000.0/loadIds.Length;
                    double expectedFzPerNode=100.0/loadIds.Length;
                    bool realLoadContract=realLoad!=null &&
                        String.Equals((string)realLoad["type"],"nodal_force_per_node",StringComparison.OrdinalIgnoreCase) &&
                        Math.Abs(((double?)realLoad["fx_per_node_n"] ?? 0.0)-expectedFxPerNode)<1e-12 &&
                        Math.Abs(((double?)realLoad["fz_per_node_n"] ?? 0.0)-expectedFzPerNode)<1e-12;
                    JObject gravityContract=solverLoads==null ? null : solverLoads.Cast<JObject>()
                        .FirstOrDefault(x=>String.Equals((string)x["name"],"C1039_Gravity",StringComparison.Ordinal));
                    bool gravityContractOk=gravityContract!=null &&
                        String.Equals((string)gravityContract["type"],"gravity_acceleration",StringComparison.OrdinalIgnoreCase) &&
                        String.Equals((string)gravityContract["scope"],"all_model",StringComparison.OrdinalIgnoreCase) &&
                        Math.Abs(((double?)gravityContract["ay_mm_s2"] ?? Double.NaN)+9810.0)<1e-12;
                    JObject materialContract=((JArray)solverContract["materials"])?.Cast<JObject>().FirstOrDefault();
                    double rhoContract=(double?)materialContract?["density_tonne_per_mm3"] ?? Double.NaN;
                    bool densityContractOk=!Double.IsNaN(rhoContract) && !Double.IsInfinity(rhoContract) && rhoContract>0;
                    contractOk &= directionalBcContract && realLoadContract && gravityContractOk && densityContractOk;
                    report["codeaster_contact_contract_pass"]=contractOk;
                    report["codeaster_directional_bc_contract_pass"]=directionalBcContract;
                    report["codeaster_directional_bc_group"]="C1038_LOAD";
                    report["codeaster_directional_bc_components"]=new JArray("DY","DZ");
                    report["codeaster_live_load_contract_pass"]=realLoadContract;
                    report["codeaster_live_fixed_bc_group"]="C1038_FIXED";
                    report["codeaster_live_load_group"]="C1038_LOAD";
                    report["codeaster_live_load_node_count"]=loadIds.Length;
                    report["codeaster_live_load_fx_total_n"]=-1000.0;
                    report["codeaster_live_load_fz_total_n"]=100.0;
                    report["codeaster_gravity_contract_pass"]=gravityContractOk;
                    report["codeaster_gravity_scope"]="all_model";
                    report["codeaster_gravity_ay_mm_s2"]=-9810.0;
                    report["codeaster_density_contract_pass"]=densityContractOk;
                    report["codeaster_density_tonne_per_mm3"]=rhoContract;
                    report["codeaster_contact_skin_elements"]=skinElementCount;
                    File.WriteAllText(Path.Combine(directory,"contact-solver-contract.json"),
                                      solverContract.ToString(Formatting.Indented));
                    contactsValid &= contractOk;
                    report["automatic_post_mesh_hook_checked_by_source_contract"]=true;

                    pass=hasDefault && everySolidAssigned && libraryPresent && contactsValid;
                    report["pass"]=pass;
                    if(!pass) throw new InvalidOperationException("C10.35 model-ready defaults did not satisfy all runtime predicates.");
                }
                catch(Exception ex)
                {
                    report["pass"]=false;
                    report["error"]=ex.ToString();
                    pass=false;
                }

                File.WriteAllText(Path.Combine(directory,"defaults-autocontact-report.json"),
                                  report.ToString(Formatting.Indented));
                Environment.ExitCode=pass ? 0 : 1;
                try
                {
                    _c10209AuditShutdownDirectory=directory;
                    if(_controller!=null) _controller.ModelChanged=false;
                }
                catch { }
                BeginInvoke(new Action(()=>Close()));
            };
            timer.Start();
        }
    }
}





