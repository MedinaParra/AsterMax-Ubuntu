using System;
using System.IO;
using Newtonsoft.Json.Linq;
namespace PrePoMax {
    // Mechanical law, not the legacy contact discretization selector.
    public static class AsterMaxContactLaw {
        public const string Support = "Code_Aster: Hard → CONTINUE unilateral; Coulomb sólo sin StickSlope explícito. Tied (K y StickSlope finitos), Linear, Exponential y Tabular no implementados. Bonded ideal: Conexiones → Idealmente unido (Bonded/Tie), elección física distinta; no conversión automática.";
        private static void Identifier(JToken token,int maximum,string field) {
            if(token==null || token.Type!=JTokenType.String) throw new InvalidDataException("Identificador de contacto no textual: "+field);
            string value=(string)token;
            if(value.Length<1 || value.Length>maximum || !Letter(value[0])) throw new InvalidDataException("Identificador de contacto inválido: "+field);
            foreach(char c in value) if(!Letter(c) && !(c>='0' && c<='9') && c!='_') throw new InvalidDataException("Identificador de contacto inválido: "+field);
        }
        private static bool Letter(char c) { return (c>='A' && c<='Z') || (c>='a' && c<='z'); }
        private static void SurfaceIdentifiers(JObject contact) {
            foreach(string role in new[]{"master","slave"}) {
                var surface=contact[role] as JObject;
                if(surface==null) throw new InvalidDataException("Superficie de contacto ausente: "+role);
                Identifier(surface["group"],24,role+".group");
                var faces=surface["elements"] as JArray;
                if(faces==null) throw new InvalidDataException("Caras de contacto ausentes: "+role);
                foreach(JToken item in faces) {
                    var face=item as JObject;
                    if(face==null) throw new InvalidDataException("Cara de contacto inválida.");
                    Identifier(face["id"],8,role+".face.id");
                    var nodes=face["nodes"] as JArray;
                    if(nodes==null) throw new InvalidDataException("Nodos de cara ausentes.");
                    foreach(JToken node in nodes) Identifier(node,8,role+".face.node");
                }
            }
        }
        public static void ValidateGeometry(JObject contact) { SurfaceIdentifiers(contact); }
        public static void Validate(JObject contact) {
            string name=(string)contact["name"] ?? "<sin nombre>";
            string prefix="Contacto '"+name+"', interacción '"+(string)contact["surface_interaction"]+"': ";
            foreach(string key in new[]{"normal_law","formulation","friction","contact_init","law_schema","solver_route","normal_stiffness_usage"})
                if(contact[key]==null || contact[key].Type!=JTokenType.String)
                    throw new InvalidDataException(prefix+"campo de ley ausente o no textual: "+key);
            string law=(string)contact["normal_law"];
            if(law!="Hard") throw new InvalidDataException(prefix+"ley "+(law??"no declarada")+" no exportable. "+Support+" No se ha emitido el script ni ejecutado Code_Aster.");
            if((string)contact["formulation"]!="CONTINUE") throw new InvalidDataException(prefix+"formulación no soportada.");
            if((string)contact["law_schema"]!="astermax-contact-law/v1" ||
               (string)contact["solver_route"]!="DEFI_CONTACT_CONTINUE_HARD" ||
               (string)contact["normal_stiffness_usage"]!="INACTIVE_FOR_HARD")
                throw new InvalidDataException(prefix+"metadatos de ley incompatibles con Hard/CONTINUE soportado.");
            // Code_Aster 16.9 defi_contact.py b_pair_std/b_pair_mortar; not an XFEM/DISCRETE policy.
            string initial=(string)contact["contact_init"];
            if(initial!="INTERPENETRE" && initial!="OUI" && initial!="NON")
                throw new InvalidDataException(prefix+"contact_init debe ser INTERPENETRE, OUI o NON.");
            JToken slope=contact["friction_stick_slope"];
            if(slope!=null && slope.Type!=JTokenType.Null) throw new InvalidDataException(prefix+"StickSlope explícito no implementado; no se ignora ni se sustituye por Coulomb ideal.");
            string friction=(string)contact["friction"];
            JToken mu=contact["friction_coefficient"];
            if(mu==null || (mu.Type!=JTokenType.Float && mu.Type!=JTokenType.Integer)) throw new InvalidDataException(prefix+"coeficiente de fricción numérico requerido.");
            double value=(double)mu;
            if(Double.IsNaN(value)||Double.IsInfinity(value) || (friction=="COULOMB" ? value<=0 : friction!="SANS" || value!=0))
                throw new InvalidDataException(prefix+"ley/coeficiente de fricción inválido.");
        }
        public static void ValidateAll(JToken token) {
            if(token==null) return;
            var contacts=token as JArray;
            if(contacts==null) throw new InvalidDataException("contacts debe ser una lista.");
            foreach(JToken c in contacts) {
                if(!(c is JObject)) throw new InvalidDataException("Contacto inválido.");
                Validate((JObject)c);
                SurfaceIdentifiers((JObject)c);
            }
        }
    }
}
