using System;
using System.IO;
using System.Windows.Forms;
using CaeGlobals;
namespace PrePoMax
{
    public partial class FrmMain
    {
        private void ExportAsterMaxCodeAsterDeck()
        {
            try
            {
                if (_controller == null || _controller.Model == null)
                {
                    MessageBoxes.ShowError("No active AsterMax model is available.");
                    return;
                }
                using (FolderBrowserDialog dlg = new FolderBrowserDialog())
                {
                    dlg.Description = "Select folder for native Code_Aster input deck";
                    if (dlg.ShowDialog(this) != DialogResult.OK) return;
                    AsterMaxCodeAsterNativeExporter.Export(_controller.Model, dlg.SelectedPath, "astermax-model");
                    tsslState.Text = "Native Code_Aster deck exported (.mail/.comm)";
                }
            }
            catch (Exception ex) { ExceptionTools.Show(this, ex); }
        }
        private void ExportAsterMaxModelContract()
        {
            try
            {
                if (_controller == null || _controller.Model == null) { MessageBoxes.ShowError("No active AsterMax model is available."); return; }
                using (SaveFileDialog dlg = new SaveFileDialog())
                {
                    dlg.Title = "Export AsterMax Solver Contract";
                    dlg.Filter = "AsterMax model contract (*.astermax.json)|*.astermax.json|JSON (*.json)|*.json";
                    dlg.FileName = "astermax-model.astermax.json";
                    if (dlg.ShowDialog(this) != DialogResult.OK) return;
                    AsterMaxModelContractBridge.Export(_controller.Model, dlg.FileName);
                    tsslState.Text = "Solver contract exported: " + Path.GetFileName(dlg.FileName);
                }
            }
            catch (Exception ex) { ExceptionTools.Show(this, ex); }
        }
    }
}


