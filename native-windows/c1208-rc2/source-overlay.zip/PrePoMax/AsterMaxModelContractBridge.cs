using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CaeGlobals;
using CaeMesh;
using CaeModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PrePoMax
{
    public static class AsterMaxModelContractBridge
    {
        public const string Schema = "astermax-model-contract/v0";
        public const string NativeBridgeVersion = "C12.08-bonded-mpc-v1";

        public static JObject Build(FeModel model)
        {
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (model.Mesh == null) throw new InvalidOperationException("Model has no FE mesh.");
            if (model.Mesh.Nodes == null || model.Mesh.Nodes.Count == 0) throw new InvalidOperationException("Model mesh contains no nodes.");
            if (model.Mesh.Elements == null || model.Mesh.Elements.Count == 0) throw new InvalidOperationException("Model mesh contains no elements.");

            if (model.UnitSystem == null || model.UnitSystem.UnitSystemType != UnitSystemType.MM_TON_S_C)
                throw new NotSupportedException("C9.60 native Code_Aster bridge currently requires mm-ton-s-C, equivalent to mm-N-MPa mechanical units.");

            // ASTERMAX_C1208_BONDED_CONSTRAINTS
            // Only the existing, explicit welded Tie is added. Other constraint
            // kinds and nonbonded contact laws retain their previous semantics.
            if (model.Constraints.Values.Any(x => x.Active && !(x is Tie)) || model.InitialConditions.Values.Any(x => x.Active) ||
                model.StepCollection.StepsList.Any(s => s.DefinedFields.Values.Any(x => x.Active)))
                throw new NotSupportedException("C12.08 admite uniones soldadas Tie; otras restricciones activas, condiciones iniciales y campos definidos no están soportados por este puente Code_Aster.");
            JObject root = new JObject();
            root["schema"] = Schema;
            root["bridge"] = NativeBridgeVersion;
            root["name"] = String.IsNullOrWhiteSpace(model.Name) ? "AsterMax Model" : model.Name;
            root["unit_system"] = "MM_N_S_MPA";
            root["source"] = new JObject { ["kind"] = "live_astermax_femodel", ["fea_results_included"] = false, ["solver_execution_claimed"] = false };

            JObject mesh = new JObject();
            JArray nodes = new JArray();
            foreach (var entry in model.Mesh.Nodes.OrderBy(e => e.Key))
            {
                FeNode n = entry.Value;
                nodes.Add(new JObject { ["id"] = "N" + n.Id, ["x"] = n.X, ["y"] = n.Y, ["z"] = n.Z });
            }
            mesh["nodes"] = nodes;

            JArray elements = new JArray();
            HashSet<string> elementTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in model.Mesh.Elements.OrderBy(e => e.Key))
            {
                FeElement e = entry.Value;
                string type = GetElementType(e);
                elementTypes.Add(type);
                JArray connectivity = new JArray();
                foreach (int nodeId in e.NodeIds) connectivity.Add("N" + nodeId);
                elements.Add(new JObject { ["id"] = "E" + e.Id, ["type"] = type, ["nodes"] = connectivity });
            }
            mesh["element_type"] = elementTypes.Count == 1 ? elementTypes.First() : "MIXED";
            mesh["elements"] = elements;

            JObject nodeGroups = new JObject();
            foreach (var entry in model.Mesh.NodeSets)
            {
                JArray ids = new JArray();
                if (entry.Value.Labels != null) foreach (int id in entry.Value.Labels.OrderBy(i => i)) ids.Add("N" + id);
                nodeGroups[entry.Key] = ids;
            }
            mesh["node_groups"] = nodeGroups;
            root["mesh"] = mesh;

            JArray materials = new JArray();
            foreach (var entry in model.Materials)
            {
                Material m = entry.Value;
                Elastic elastic = m.GetProperty<Elastic>() as Elastic;
                ElasticWithDensity elasticDensity = m.GetProperty<ElasticWithDensity>() as ElasticWithDensity;
                Density density = m.GetProperty<Density>() as Density;
                JObject item = new JObject { ["name"] = m.Name };
                if (elastic != null && elastic.YoungsPoissonsTemp != null && elastic.YoungsPoissonsTemp.Length > 0)
                {
                    item["young_modulus_mpa"] = elastic.YoungsPoissonsTemp[0][0];
                    item["poisson"] = elastic.YoungsPoissonsTemp[0][1];
                    item["constitutive_model"] = "isotropic_linear_elastic";
                }
                else if (elasticDensity != null)
                {
                    item["young_modulus_mpa"] = elasticDensity.YoungsModulus;
                    item["poisson"] = elasticDensity.PoissonsRatio;
                    item["constitutive_model"] = "isotropic_linear_elastic";
                }
                else item["unsupported_for_code_aster_adapter_v0"] = true;
                double densityValue = Double.NaN;
                if (density != null && density.DensityTemp != null && density.DensityTemp.Length > 0 &&
                    density.DensityTemp[0] != null && density.DensityTemp[0].Length > 0)
                    densityValue = density.DensityTemp[0][0];
                else if (elasticDensity != null)
                    densityValue = elasticDensity.Density;
                if (!Double.IsNaN(densityValue) && !Double.IsInfinity(densityValue) && densityValue > 0)
                    item["density_tonne_per_mm3"] = densityValue;                materials.Add(item);
            }
            root["materials"] = materials;

            JArray supports = new JArray();
            JArray loads = new JArray();
            int stepCount = 0;
            foreach (Step step in model.StepCollection.StepsList)
            {
                if (step is InitialStep) continue;
                if (step.GetType() != typeof(StaticStep) || step.Nlgeom || !step.Active || !step.Valid)
                    throw new NotSupportedException("Code_Aster bridge currently supports one active linear static study only. Selected: " + step.GetType().Name);
                stepCount++;
                foreach (var bcEntry in step.BoundaryConditions)
                {
                    if (!bcEntry.Value.Active || !bcEntry.Value.Valid)
                        throw new NotSupportedException("Apoyo inactivo o inválido: " + bcEntry.Key);
                    FixedBC fixedBc = bcEntry.Value as FixedBC;
                    if (fixedBc != null)
                    {
                        string group = RegionToNodeGroup(model, fixedBc.RegionName, fixedBc.RegionType, nodeGroups);
                        supports.Add(new JObject { ["name"] = fixedBc.Name, ["type"] = "fixed", ["group"] = group, ["dx"] = 0.0, ["dy"] = 0.0, ["dz"] = 0.0 });
                    }
                    else
                    {
                        DisplacementRotation displacementBc = bcEntry.Value as DisplacementRotation;
                        if(displacementBc != null)
                        {
                            if(!double.IsNaN(displacementBc.UR1) || !double.IsNaN(displacementBc.UR2) || !double.IsNaN(displacementBc.UR3))
                                throw new NotSupportedException("C10.38 solid Code_Aster bridge supports translational displacement DOFs only. Rotational DOFs are not valid for 3D continuum nodes: " + displacementBc.Name);
                            if(double.IsNaN(displacementBc.U1) && double.IsNaN(displacementBc.U2) && double.IsNaN(displacementBc.U3))
                                throw new InvalidOperationException("C10.38 directional displacement has no constrained translation: " + displacementBc.Name);
                            string group = RegionToNodeGroup(model, displacementBc.RegionName, displacementBc.RegionType, nodeGroups);
                            supports.Add(new JObject
                            {
                                ["name"] = displacementBc.Name,
                                ["type"] = "displacement",
                                ["group"] = group,
                                ["dx"] = TranslationToken(displacementBc.U1, "U1", displacementBc.Name),
                                ["dy"] = TranslationToken(displacementBc.U2, "U2", displacementBc.Name),
                                ["dz"] = TranslationToken(displacementBc.U3, "U3", displacementBc.Name)
                            });
                        }
                        else supports.Add(new JObject { ["name"] = bcEntry.Value.Name, ["type"] = bcEntry.Value.GetType().Name, ["unsupported_for_code_aster_adapter_v0"] = true });
                    }
                }
                foreach (var loadEntry in step.Loads)
                {
                    if (!loadEntry.Value.Active || !loadEntry.Value.Valid)
                        throw new NotSupportedException("Carga inactiva o inválida: " + loadEntry.Key);
                    CLoad cload = loadEntry.Value as CLoad;
                    if (cload != null)
                    {
                        string group = RegionToNodeGroup(model, cload.RegionName, cload.RegionType, nodeGroups);
                        bool total = cload is UniformTotalCLoad;
                        var force = new JObject {
                            ["name"] = cload.Name,
                            ["type"] = total ? "nodal_force_total" : "nodal_force_per_node",
                            ["group"] = group
                        };
                        string suffix = total ? "_total_n" : "_per_node_n";
                        force["fx"+suffix] = cload.F1; force["fy"+suffix] = cload.F2; force["fz"+suffix] = cload.F3;
                        if(total) force["distribution"] = "UNIFORM_PER_SELECTED_NODE";
                        loads.Add(force);
                    }
                    else
                    {
                        GravityLoad gravityLoad = loadEntry.Value as GravityLoad;
                        if (gravityLoad != null)
                        {
                            if (gravityLoad.RegionType != RegionTypeEnum.ElementSetName)
                                throw new NotSupportedException("C10.39 gravity requires ElementSetName scope for certified coverage.");
                            if (!model.Mesh.ElementSets.ContainsKey(gravityLoad.RegionName))
                                throw new InvalidOperationException("C10.39 gravity element set is missing: " + gravityLoad.RegionName);
                            FeElementSet gravitySet = model.Mesh.ElementSets[gravityLoad.RegionName];
                            HashSet<int> gravityIds = new HashSet<int>(gravitySet.Labels ?? new int[0]);
                            if (gravityIds.Count != model.Mesh.Elements.Count || model.Mesh.Elements.Keys.Any(id => !gravityIds.Contains(id)))
                                throw new NotSupportedException("C10.39 certifies gravity only over the complete FE model.");
                            double gmag=Math.Sqrt(gravityLoad.F1*gravityLoad.F1+gravityLoad.F2*gravityLoad.F2+gravityLoad.F3*gravityLoad.F3);
                            if(Double.IsNaN(gmag) || Double.IsInfinity(gmag) || gmag<=0)
                                throw new InvalidOperationException("C10.39 gravity vector must be finite and non-zero.");
                            loads.Add(new JObject {
                                ["name"]=gravityLoad.Name,
                                ["type"]="gravity_acceleration",
                                ["scope"]="all_model",
                                ["source_element_set"]=gravityLoad.RegionName,
                                ["ax_mm_s2"]=gravityLoad.F1,
                                ["ay_mm_s2"]=gravityLoad.F2,
                                ["az_mm_s2"]=gravityLoad.F3
                            });
                        }
                        else loads.Add(new JObject { ["name"] = loadEntry.Value.Name, ["type"] = loadEntry.Value.GetType().Name, ["unsupported_for_code_aster_adapter_v0"] = true });
                    }
                }
            }
            if (stepCount != 1) throw new NotSupportedException("C9.60 native bridge v0 requires exactly one non-initial analysis step.");
            root["analysis"] = new JObject { ["type"] = "static_structural", ["step_count"] = stepCount };
            root["supports"] = supports;
            root["loads"] = loads;
            JArray contacts = new JArray();
            int contactIndex = 0;
            foreach (var cpEntry in model.ContactPairs)
            {
                ContactPair cp = cpEntry.Value;
                // ASTERMAX_C1207_ACTIVE_CONTACTS
                if (cp == null || !cp.Active) continue;
                if (!cp.Valid)
                    throw new InvalidOperationException("El contacto activo '" + cp.Name + "' no es válido. Revise sus superficies antes de resolver.");
                contactIndex++;
                if (cp.MasterRegionType != RegionTypeEnum.SurfaceName || cp.SlaveRegionType != RegionTypeEnum.SurfaceName)
                    throw new NotSupportedException("C10.36 Code_Aster contact export requires named master/slave surfaces.");

                SurfaceInteraction interaction;
                if (!model.SurfaceInteractions.TryGetValue(cp.SurfaceInteractionName, out interaction) || interaction == null)
                    throw new InvalidOperationException("Contact interaction is missing: " + cp.SurfaceInteractionName);
                // C1208_CONTACT_LAW: never infer the law from the ContactPair class.
                var behaviors=interaction.Properties == null ? new SurfaceBehavior[0] : interaction.Properties.OfType<SurfaceBehavior>().ToArray();
                if(behaviors.Length!=1 || interaction.Properties.Any(p=>!(p is SurfaceBehavior) && !(p is Friction)) || interaction.Properties.OfType<Friction>().Count()>1)
                    throw new InvalidOperationException("Contacto '"+cp.Name+"': interacción incompleta, duplicada o no soportada. "+AsterMaxContactLaw.Support);
                SurfaceBehavior behavior=behaviors[0];
                Friction friction = interaction.Properties == null
                    ? null
                    : interaction.Properties.OfType<Friction>().FirstOrDefault();

string suffix = contactIndex.ToString("000");


                JObject contactLaw = new JObject
                {
                    ["name"] = cp.Name,
                    ["surface_interaction"] = cp.SurfaceInteractionName,
                    ["normal_law"] = behavior.PressureOverclosureType.ToString(),
                    ["normal_stiffness_k"] = behavior.K,
                    ["normal_stiffness_usage"] = behavior.PressureOverclosureType == PressureOverclosureEnum.Hard ? "INACTIVE_FOR_HARD" : "UNSUPPORTED",
                    ["solver_route"] = "DEFI_CONTACT_CONTINUE_HARD",
                    ["method"] = cp.Method.ToString(),
                    ["small_sliding"] = cp.SmallSliding,
                    ["adjust"] = cp.Adjust,
                    ["formulation"] = "CONTINUE",
                    ["friction"] = friction == null ? "SANS" : "COULOMB",
                    ["friction_coefficient"] = friction == null ? 0.0 : friction.Coefficient,
                    ["friction_stick_slope"] = friction == null || Double.IsNaN(friction.StickSlope)
                        ? JValue.CreateNull()
                        : new JValue(friction.StickSlope),
                    ["contact_init"] = "INTERPENETRE",
                    ["law_schema"] = "astermax-contact-law/v1"
                };
                AsterMaxContactLaw.Validate(contactLaw);
                contactLaw["master"]=BuildCodeAsterContactSurface(model, cp.MasterRegionName, "AM_M" + suffix, "M", contactIndex);
                contactLaw["slave"]=BuildCodeAsterContactSurface(model, cp.SlaveRegionName, "AM_S" + suffix, "S", contactIndex);
                contacts.Add(contactLaw);
            }
            JArray bondedTies = new JArray();
            int bondedIndex = contactIndex;
            foreach (var constraintEntry in model.Constraints)
            {
                Constraint constraint = constraintEntry.Value;
                if (constraint == null || !constraint.Active) continue;
                Tie tie = constraint as Tie;
                if (tie == null)
                    throw new NotSupportedException("Restricción activa no soportada: " + constraint.Name);
                if (!tie.Valid)
                    throw new InvalidOperationException("La unión soldada activa '" + tie.Name + "' no es válida. Revise sus superficies.");
                if (tie.MasterRegionType != RegionTypeEnum.SurfaceName || tie.SlaveRegionType != RegionTypeEnum.SurfaceName)
                    throw new NotSupportedException("La unión soldada '" + tie.Name + "' requiere superficies maestra y esclava con nombre.");
                if (Double.IsNaN(tie.PositionTolerance) || Double.IsInfinity(tie.PositionTolerance) || tie.PositionTolerance <= 0)
                    throw new InvalidOperationException("La unión soldada '" + tie.Name + "' requiere una tolerancia de posición explícita, finita y positiva en mm.");
                if (tie.Adjust)
                    throw new NotSupportedException("La unión soldada '" + tie.Name + "' requiere Adjust=false. C12.08 conserva las coordenadas y acopla el hueco mediante MPC afines.");
                bondedIndex++;
                string bondedSuffix = bondedIndex.ToString("000");
                bondedTies.Add(new JObject
                {
                    ["name"] = tie.Name,
                    ["position_tolerance_mm"] = tie.PositionTolerance,
                    ["adjust"] = false,
                    ["master"] = BuildCodeAsterContactSurface(model, tie.MasterRegionName, "AM_BM" + bondedSuffix, "M", bondedIndex),
                    ["slave"] = BuildCodeAsterContactSurface(model, tie.SlaveRegionName, "AM_BS" + bondedSuffix, "S", bondedIndex)
                });
            }
            root["bonded_ties"] = bondedTies;
            root["contacts"] = contacts;            root["postprocess"] = new JObject { ["displacement_probe_group"] = loads.Cast<JObject>().Where(x => x["group"] != null).Select(x => (string)x["group"]).FirstOrDefault() };
            return root;
        }

        // CI proof path: constructs a real FeModel using the same CaeModel/CaeMesh classes used by the GUI,
        // then passes it through Build(). The returned JSON is a model-definition artifact, never an FEA result.
        public static void ExportDeterministicSmoke(string fileName)
        {
            FeModel model = new FeModel("C9.60 Native Bridge Smoke");
            model.UnitSystem = new UnitSystem(UnitSystemType.MM_TON_S_C);
            model.Mesh.Nodes.Add(1, new FeNode(1, 0, 0, 0));
            model.Mesh.Nodes.Add(2, new FeNode(2, 100, 0, 0));
            model.Mesh.Nodes.Add(3, new FeNode(3, 100, 10, 0));
            model.Mesh.Nodes.Add(4, new FeNode(4, 0, 10, 0));
            model.Mesh.Nodes.Add(5, new FeNode(5, 0, 0, 10));
            model.Mesh.Nodes.Add(6, new FeNode(6, 100, 0, 10));
            model.Mesh.Nodes.Add(7, new FeNode(7, 100, 10, 10));
            model.Mesh.Nodes.Add(8, new FeNode(8, 0, 10, 10));
            model.Mesh.Elements.Add(1, new LinearHexaElement(1, new int[] { 1,2,3,4,5,6,7,8 }));
            model.Mesh.NodeSets.Add("FIXED", new FeNodeSet("FIXED", new int[] { 1,4,5,8 }));
            model.Mesh.NodeSets.Add("LOAD", new FeNodeSet("LOAD", new int[] { 2,3,6,7 }));

            Material steel = new Material("StructuralSteel");
            steel.AddProperty(new ElasticWithDensity(210000.0, 0.30, 7.85E-9));
            model.Materials.Add(steel.Name, steel);

            // NamedClass identifiers reject spaces; UI may display a friendlier label separately.
            StaticStep step = new StaticStep("StaticStructural");
            if(!step.AddBoundaryCondition(new FixedBC("FixedSupport", "FIXED", RegionTypeEnum.NodeSetName, false)))
                throw new InvalidOperationException("StaticStep rejected FixedBC in C9.60 smoke model.");
            if(!step.AddLoad(new CLoad("AxialForce", "LOAD", RegionTypeEnum.NodeSetName, 2500.0, 0.0, 0.0, false, false, 0.0)))
                throw new InvalidOperationException("StaticStep rejected CLoad in C9.60 smoke model.");
            model.StepCollection.AddStep(step, false);

            Export(model, fileName);
        }
        public static void Export(FeModel model, string fileName)
        {
            JObject contract = Build(model);
            File.WriteAllText(fileName, contract.ToString(Formatting.Indented), new System.Text.UTF8Encoding(false));
        }

        internal static string CodeAsterSkinElementId(string role, int contactIndex, int localFaceIndex)
        {
            if (!String.Equals(role, "M", StringComparison.Ordinal) &&
                !String.Equals(role, "S", StringComparison.Ordinal))
                throw new ArgumentException("C10.40 contact skin role must be M or S.", nameof(role));
            return role + CodeAsterBase36(contactIndex, 2, "contact index") +
                   CodeAsterBase36(localFaceIndex, 5, "local face index");
        }

        private static string CodeAsterBase36(int value, int width, string label)
        {
            if (value < 1) throw new ArgumentOutOfRangeException(label, "C10.40 Code_Aster identifiers are 1-based.");
            const string digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] chars = new char[width];
            int remaining = value;
            for (int i = width - 1; i >= 0; i--)
            {
                chars[i] = digits[remaining % 36];
                remaining /= 36;
            }
            if (remaining != 0)
                throw new NotSupportedException("C10.40 " + label + " exceeds the fixed Code_Aster 8-character identifier namespace.");
            return new string(chars);
        }
        private static JObject BuildCodeAsterContactSurface(FeModel model, string surfaceName, string groupName, string role, int contactIndex)
        {
            if (String.IsNullOrWhiteSpace(surfaceName) || !model.Mesh.Surfaces.ContainsKey(surfaceName))
                throw new InvalidOperationException("Contact surface not found: " + (surfaceName ?? "<null>"));
            FeSurface surface = model.Mesh.Surfaces[surfaceName];
            if (surface.Type != FeSurfaceType.Element)
                throw new NotSupportedException("C10.36 requires element-based contact surfaces: " + surfaceName);
            if (surface.ElementFaces == null || surface.ElementFaces.Count == 0)
                throw new InvalidOperationException("Contact surface has no element faces: " + surfaceName);

            JArray skin = new JArray();
            int localId = 0;
            foreach (var faceEntry in surface.ElementFaces.OrderBy(x => x.Key.ToString(), StringComparer.Ordinal))
            {
                string elementSetName = faceEntry.Value;
                if (String.IsNullOrWhiteSpace(elementSetName) || !model.Mesh.ElementSets.ContainsKey(elementSetName))
                    throw new InvalidOperationException("Contact surface element set is missing: " + elementSetName);
                FeElementSet set = model.Mesh.ElementSets[elementSetName];
                if (set.Labels == null || set.Labels.Length == 0)
                    throw new InvalidOperationException("Contact surface element set is empty: " + elementSetName);

                foreach (int elementId in set.Labels.OrderBy(x => x))
                {
                    if (!model.Mesh.Elements.ContainsKey(elementId))
                        throw new InvalidOperationException("Contact source element is missing: " + elementId);
                    FeElement volume = model.Mesh.Elements[elementId];
                    int[] nodeIds = volume.GetVtkCellFromFaceName(faceEntry.Key);
                    string faceType;
                    if (nodeIds.Length == 3) faceType = "TRIA3";
                    else if (nodeIds.Length == 4) faceType = "QUAD4";
                    else if (nodeIds.Length == 6) faceType = "TRIA6";
                    else if (nodeIds.Length == 8) faceType = "QUAD8";
                    else throw new NotSupportedException("Unsupported Code_Aster contact face node count: " + nodeIds.Length);

                    localId++;
                    string syntheticId = CodeAsterSkinElementId(role, contactIndex, localId);
                    skin.Add(new JObject
                    {
                        ["id"] = syntheticId,
                        ["type"] = faceType,
                        ["source_element_id"] = "E" + elementId,
                        ["source_face"] = faceEntry.Key.ToString(),
                        ["nodes"] = new JArray(nodeIds.Select(x => "N" + x))
                    });
                }
            }
            if (skin.Count == 0) throw new InvalidOperationException("Contact surface produced no skin elements: " + surfaceName);
            return new JObject
            {
                ["source_surface"] = surfaceName,
                ["group"] = groupName,
                ["elements"] = skin
            };
        }
        private static JToken TranslationToken(double value, string component, string bcName)
        {
            if(double.IsNaN(value)) return JValue.CreateNull();
            if(double.IsPositiveInfinity(value)) return new JValue(0.0);
            if(double.IsInfinity(value))
                throw new InvalidOperationException("C10.38 invalid displacement value " + component + " in " + bcName);
            return new JValue(value);
        }
        private static string GetElementType(FeElement e)
        {
            if (e is LinearHexaElement) return "HEXA8";
            if (e is LinearTetraElement) return "TETRA4";
            if (e is ParabolicTetraElement) return "TETRA10";
            return e.GetType().Name;
        }

        private static string RegionToNodeGroup(FeModel model, string regionName, RegionTypeEnum regionType, JObject nodeGroups)
        {
            if (regionType == RegionTypeEnum.NodeSetName)
            {
                if (nodeGroups[regionName] == null) throw new InvalidOperationException("Node group not found: " + regionName);
                var set = model.Mesh.NodeSets[regionName];
                if (set.Labels == null || set.Labels.Length == 0 || set.Labels.Any(id => !model.Mesh.Nodes.ContainsKey(id)))
                    throw new InvalidOperationException("El grupo de nodos está vacío o contiene nodos inexistentes: " + regionName);
                return regionName;
            }
            throw new NotSupportedException("C9.60 native bridge v0 currently requires node-set scoping for fixed BCs and nodal loads. Region: " + regionName + " / " + regionType);
        }
    }
}










